#include "../../../../../../qtmqtt/src/mqtt/qmqttconnectionproperties_p.h"
