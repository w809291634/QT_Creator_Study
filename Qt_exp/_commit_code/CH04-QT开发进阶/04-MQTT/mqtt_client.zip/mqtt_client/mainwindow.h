﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#if defined(_MSC_VER) && (_MSC_VER >= 1600)
# pragma execution_character_set("utf-8")
#endif

#include <QtCore>
#include <QMainWindow>
//info
#include <QNetworkInterface>
#include <QHostInfo>
#include <QHostAddress>
#include <QTcpServer>

#include "QtMqtt/qmqttclient.h"

#define FIRST_IP_ARRDESS                {"192.168.100",\
                                        "192.168.31"}       // 服务器端 想监听的 优先地址

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // 功能函数
    void init_mqtt_client();
    void init_mqtt_client_ui();
    void getLocalIP();

    // 更新信息
    void client_pingResponse();
    void client_stateChanged(QMqttClient::ClientState state);
    void client_errorChanged(QMqttClient::ClientError error);
    void client_messageReceived(
            const QByteArray &message,
            const QMqttTopicName &topic);
    void history_listWidget_additem(QString & info);
    void client_connected();
    void client_disconnected();
    void client_sub_list_update();

    // 槽函数
    void on_pub_btn_clicked();
    void on_sub_btn_clicked();
    void on_buttonPing_clicked();
    void on_buttonConnect_clicked();
    void on_buttonDisconnect_clicked();
    void on_history_clear_btn_clicked();
    void on_sub_list_delete_clicked();

private:
    Ui::MainWindow *ui;
    QMqttClient *m_client;
    QList<QMqttSubscription*> mqtt_sub_list;
};

#endif // MAINWINDOW_H
