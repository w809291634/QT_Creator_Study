﻿#include "mythread.h"

Q_Thread::Q_Thread(QObject * parent):
    QThread(parent)
{

}

Q_Thread::~Q_Thread()
{
    qDebug()<<QString("%1 exit").arg(this->objectName());
}

void Q_Thread::run(){
    if(callback!=nullptr){
        // 执行回调函数
        callback(parameter);
    }
    // 执行 事件循环 接收quit会退出
    QThread::exec();
    // 延迟删除
    this->deleteLater();
}

void Q_Thread::RegeditCallBack(_CALLBACK fun,void* para)/*注册回调函数*/
{
    callback = fun;
    parameter = para;
}
