#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("智能监控");


    /** 子线程1 **/
    O_Thread_1.reset(new O_Thread("thread1"));
    // 绑定成员函数
    auto Fun1 = bind(&MainWindow::camera_handle,
                    this, placeholders::_1);
    // 传入 参数
    char data[]="O_Thread_1_parameter";
    O_Thread_1->RegeditCallBack(Fun1,data);
    connect(O_Thread_1.data(),SIGNAL(message(const QString&)),
            this,SLOT(update_info(const QString&)));

    // 新建 VideoCapture 类
    m_cap =new cv::VideoCapture();

    // 创建所有的模型类
    m_persondet = new Persondet();
    m_posedet = new Posedet();
    m_detector = new Detector(320,false);
    facerec_init();

    // 初始化模型
    if(m_persondet->init(NCNN_MODEL_PATH+string("persondet"))==0 &&
            m_posedet->init(NCNN_MODEL_PATH+string("pose_detection"))==0 &&
            m_detector->init(NCNN_MODEL_PATH+string("face_detection"))==0 &&
            m_facerec->init(NCNN_MODEL_PATH+string("face_recognition"))==0)
    {
        // 用于刷新摄像头数据
        O_Thread_1->start();

        // 用于刷新摄像头数据
        m_Camera_Timer = new QTimer(this);
        connect(m_Camera_Timer, SIGNAL(timeout()), this, SLOT(camera_handleTimeout()));
        m_Camera_Timer->start(CAMERA_TIMER_TIMEOUT);

        // 初始化UI
        app_init_ui();
    }else{
        app_error_ui();
    }
}

MainWindow::~MainWindow()
{
    delete ui;

    m_cap->release();
    delete m_cap;
    delete m_persondet;
    delete m_posedet;
    delete m_detector;
    delete m_facerec;
}

/** ncnn 功能函数函数 **/
// cv::Mat 转换为 QImage
QImage MainWindow::QCVMat2QImage(const cv::Mat& mat)
{
    const unsigned char* data = mat.data;

    int width = mat.cols;
    int height = mat.rows;
    int bytesPerLine = static_cast<int>(mat.step);
    switch(mat.type())
    {
        //8 bit , ARGB
        case CV_8UC4:
        {
            QImage image(data, width, height, bytesPerLine, QImage::Format_ARGB32);
            return image;
        }

        //8 bit BGR
        case CV_8UC3:
        {
            QImage image(data, width, height, bytesPerLine, QImage::Format_RGB888);
            //swap blue and red channel
            return image.rgbSwapped();
        }

        //8 bit Gray shale
        case CV_8UC1:
        {
            QImage image(data, width, height, bytesPerLine, QImage::Format_Grayscale8);
            return image;
        }

        //
        default:
        {
            //Unsupported format
            qWarning()<<"Unsupported cv::Mat type:"<<mat.type()
                     <<", Empty QImage will be returned!";
            return QImage();
        }
    }
}

/* 行人检测 */
void MainWindow::persondet(cv::Mat& frame)
{
    high_resolution_clock::time_point t1 = high_resolution_clock::now();
    m_persondet->detect(frame);
    high_resolution_clock::time_point t2 = high_resolution_clock::now();

    duration<double,std::milli> duration_ms(t2-t1);
    ui->statusBar->showMessage(QString("推理用时:%1ms").arg(duration_ms.count()));
}

/* 姿态检测 */
void MainWindow::posedet(cv::Mat& frame)
{
    high_resolution_clock::time_point t1 = high_resolution_clock::now();
    m_posedet->detect(frame);
    high_resolution_clock::time_point t2 = high_resolution_clock::now();

    duration<double,std::milli> duration_ms(t2-t1);
    ui->statusBar->showMessage(QString("推理用时:%1ms").arg(duration_ms.count()));
}

/* 人脸检测 */
void MainWindow::facedet(cv::Mat& frame)
{
    high_resolution_clock::time_point t1 = high_resolution_clock::now();
    float scale = 1.f;
    std::vector<bbox> boxes;
    m_detector->Detect(frame, boxes);

    // draw image
    for (unsigned int j = 0; j < boxes.size(); ++j) {
        cv::rectangle(frame, cv::Point(boxes[j].x1/scale, boxes[j].y1/scale), cv::Point(boxes[j].x2/scale, boxes[j].y2/scale), cv::Scalar(0, 0, 255), 2);
        char str[80];
        sprintf(str, "%f", boxes[j].s);

        cv::putText(frame, str, cv::Point((boxes[j].x1/scale), boxes[j].y1/scale), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 255));
        cv::circle(frame, cv::Point(boxes[j].point[0]._x / scale, boxes[j].point[0]._y / scale), 1, cv::Scalar(0, 0, 225), 4);
        cv::circle(frame, cv::Point(boxes[j].point[1]._x / scale, boxes[j].point[1]._y / scale), 1, cv::Scalar(0, 255, 225), 4);
        cv::circle(frame, cv::Point(boxes[j].point[2]._x / scale, boxes[j].point[2]._y / scale), 1, cv::Scalar(255, 0, 225), 4);
        cv::circle(frame, cv::Point(boxes[j].point[3]._x / scale, boxes[j].point[3]._y / scale), 1, cv::Scalar(0, 255, 0), 4);
        cv::circle(frame, cv::Point(boxes[j].point[4]._x / scale, boxes[j].point[4]._y / scale), 1, cv::Scalar(255, 0, 0), 4);
    }
    high_resolution_clock::time_point t2 = high_resolution_clock::now();
    duration<double,std::milli> duration_ms(t2-t1);
    ui->statusBar->showMessage(QString("推理用时:%1ms").arg(duration_ms.count()));
}

/* 人脸识别 */
// 人脸识别初始化
void MainWindow::facerec_init(std::string feature_path)
{
    m_facerec = new Facerec();

    // 默认在执行文件当前路径中读取features.txt特征文件
    m_feature_path = feature_path;
    bool read_flag = read_feats(m_feature_path, m_face_feats);
    if (read_flag == false)
    {
        qDebug() << "No person registered.";
    }
}

// 读取特征
int MainWindow::read_feats(const std::string &path, std::vector<FaceFeature> &feats)
{
    std::ifstream infile;
    infile.open(path);
    // string output;
    if (infile.is_open()) {
//        int index = 0;
        while (!infile.eof()) {
            FaceFeature feat;
            // infile >> feats[index].name;
            infile >> feat.name;
            for (int i = 0; i < 128; ++i){
                infile >> feat.face_feature[i];
            }
            feats.push_back(feat);
            // cout << output << endl;
        }
        infile.close();
        return true;
    }else{
        infile.close();
        return false;
    }
}

// 写入特征
int MainWindow::write_feat(const std::string &path, FaceFeature &feat)
{
    std::ofstream outfile;//创建文件
    outfile.open(path, std::ofstream::app);

    // string output;
    if (outfile.is_open()) {
        outfile << feat.name;
        for (int i = 0; i < 128; ++i){
            outfile << " " << feat.face_feature[i];
        }
        outfile << endl;
    }
    outfile.close();

    return 0;
}

// 人脸识别
void MainWindow::facerec(cv::Mat& frame)
{
    high_resolution_clock::time_point t1 = high_resolution_clock::now();
    // 识别人脸
    std::vector<BboxFace> face_out = m_facerec->recognize(frame, m_face_feats);
    // 进行注册人脸
    if (face_out.size() > 0 && !m_reg_name.empty())
    {
        qDebug()<< "注册姓名:" << QString::fromStdString(m_reg_name);
        FaceFeature new_feat;
        new_feat.name = m_reg_name;
        memcpy(new_feat.face_feature, face_out[0].rec.data, 128 * sizeof(float));
        write_feat(m_feature_path, new_feat);
        m_face_feats.push_back(new_feat);
        m_reg_name="";
    }
    high_resolution_clock::time_point t2 = high_resolution_clock::now();

    duration<double,std::milli> duration_ms(t2-t1);
    ui->statusBar->showMessage(QString("推理用时:%1ms").arg(duration_ms.count()));
}

/** 状态更新 **/
// APP初始化UI
void MainWindow::app_init_ui()
{
#if defined __ARM_ARCH
    ui->camera_cbox->addItem("/dev/video0");
    ui->camera_cbox->setEditable(true);
#elif defined __x86_64
    // 读取所有摄像头信息(arm端不适配)
    QList<QCameraInfo> infos = QCameraInfo::availableCameras();
    foreach(QCameraInfo info, infos){
        qDebug()<<info.description()<<info.deviceName();
        ui->camera_cbox->addItem(info.deviceName());
    }
#endif

    ui->ai_person_detection_btn->setCheckable(true);
    ui->ai_pose_detection_btn->setCheckable(true);
    ui->ai_face_detection_btn->setCheckable(true);
    ui->ai_face_recognition_btn->setCheckable(true);

    // 解决 QLabel 无法缩放的问题
    ui->camera_view_label->setSizePolicy(QSizePolicy::Ignored,QSizePolicy::Ignored);
    // 显示为摄像头关闭状态
    camera_close_status();
}

// APP初始化错误状态的UI
void MainWindow::app_error_ui()
{
    camera_close_status();
    ui->camera_view_label->setText("启动错误，请检查模型文件路径，请退出");

    ui->openCamera_btn->setEnabled(false);
    ui->closeCamera_btn->setEnabled(false);
}

// 摄像头打开状态
void MainWindow::camera_open_status()
{
    // 设置摄像头按钮
    ui->openCamera_btn->setEnabled(false);
    ui->closeCamera_btn->setEnabled(true);
    // 设置ai按钮
    ui->ai_person_detection_btn->setEnabled(true);
    ui->ai_pose_detection_btn->setEnabled(true);
    ui->ai_face_detection_btn->setEnabled(true);
    ui->ai_face_recognition_btn->setEnabled(true);
    ui->statusBar->showMessage("摄像头打开");
}

// 摄像头关闭状态
void MainWindow::camera_close_status()
{
    // 设置摄像头按钮
    ui->openCamera_btn->setEnabled(true);
    ui->closeCamera_btn->setEnabled(false);
    ui->camera_view_label->setText("请打开摄像头");
    // 所有 ai 按钮失能
    ui->ai_person_detection_btn->setEnabled(false);
    ui->ai_pose_detection_btn->setEnabled(false);
    ui->ai_face_detection_btn->setEnabled(false);
    ui->ai_face_recognition_btn->setEnabled(false);
    ui->ai_face_register_btn->setEnabled(false);
    // 设置AI按钮没有打开
    ui->ai_person_detection_btn->setChecked(false);
    ui->ai_pose_detection_btn->setChecked(false);
    ui->ai_face_detection_btn->setChecked(false);
    ui->ai_face_recognition_btn->setChecked(false);
    // 设置 ai 标志位
    m_flag=0;
    ui->statusBar->showMessage("摄像头关闭");
}

void MainWindow::camera_handleTimeout()
{
    if(!m_frame.empty()){
        QMutexLocker locker(&Mutex);
        QImage img=QCVMat2QImage(m_frame);
        img = img.scaled(ui->camera_view_label->size(),
                         Qt::KeepAspectRatio,Qt::SmoothTransformation);
        ui->camera_view_label->setPixmap(QPixmap::fromImage(img));
    }
}

// 刷新摄像头数据
void MainWindow::camera_handle(char* data)
{
    (void) data;
    while(O_Thread_1->get_status()==O_Thread::RUN){
        qDebug()<< "here";
        if(m_cap->isOpened()==true)
        {
            // 获取一张图片
            QMutexLocker locker(&Mutex);
            bool bSuccess = m_cap->read(m_frame);
            if(bSuccess){
                // 进行 推理类型的选择
                switch(m_flag){
                    case Person_Detection:
                    persondet(m_frame);
                    break;

                    case Pose_Detection:
                    posedet(m_frame);

                    break;
                    case Face_Detection:
                    facedet(m_frame);
                    break;

                    case Face_Recognition:
                    facerec(m_frame);
                    break;
                }
            }
//            // 判断是否获取成功
//            if (bSuccess == false)
//            {
//                qDebug() << "Found the end of the video";
//                on_closeCamera_btn_clicked();
//            }

        }
        QThread::msleep(10);
    }
}

/** 按钮槽函数 **/
// 打开摄像头按钮
void MainWindow::on_openCamera_btn_clicked()
{
    std::string camera_path=ui->camera_cbox->currentText().toStdString();
    if(m_cap->isOpened()==false){
        m_cap->open(camera_path);
        if (m_cap->isOpened() == true)
        {
            m_cap->set(cv::CAP_PROP_FPS,30);
            double fps = m_cap->get(cv::CAP_PROP_FPS);
            QString info = QString("open the camera,Frames per seconds: %1fps").arg(fps);
            qDebug()<< info;
            camera_open_status();
        }
        else
        {
            qDebug()<< "Cannot open the camera";
            QMessageBox::critical(this, "错误", "打开摄像头失败",
                                 QMessageBox::Yes);
            camera_close_status();
            return;
        }
    }
}

// 关闭摄像头按钮
void MainWindow::on_closeCamera_btn_clicked()
{
    if(m_cap->isOpened()==true){
        m_cap->release();
        if(m_cap->isOpened()==false){
            qDebug()<< "close the camera";
            camera_close_status();
        }
    }
}

// 行人检测 按钮
void MainWindow::on_ai_person_detection_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Person_Detection;
        ui->ai_pose_detection_btn->setChecked(false);
        ui->ai_face_detection_btn->setChecked(false);
        ui->ai_face_recognition_btn->setChecked(false);
        ui->ai_face_register_btn->setEnabled(false);
        ui->statusBar->showMessage("启动行人检测");
    }else{
        m_flag=0;
    }
}

// 姿态检测 按钮
void MainWindow::on_ai_pose_detection_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Pose_Detection;
        ui->ai_person_detection_btn->setChecked(false);
        ui->ai_face_detection_btn->setChecked(false);
        ui->ai_face_recognition_btn->setChecked(false);
        ui->ai_face_register_btn->setEnabled(false);
        ui->statusBar->showMessage("启动姿态检测");
    }else{
        m_flag=0;
    }
}

// 人脸检测 按钮
void MainWindow::on_ai_face_detection_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Face_Detection;
        ui->ai_person_detection_btn->setChecked(false);
        ui->ai_pose_detection_btn->setChecked(false);
        ui->ai_face_recognition_btn->setChecked(false);
        ui->ai_face_register_btn->setEnabled(false);
        ui->statusBar->showMessage("启动人脸检测");
    }else{
        m_flag=0;
    }
}

// 人脸识别 按钮
void MainWindow::on_ai_face_recognition_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Face_Recognition;
        ui->ai_person_detection_btn->setChecked(false);
        ui->ai_pose_detection_btn->setChecked(false);
        ui->ai_face_detection_btn->setChecked(false);
        ui->ai_face_register_btn->setEnabled(true);
        ui->statusBar->showMessage("启动人脸识别");
    }else{
        m_flag=0;
        ui->ai_face_register_btn->setEnabled(false);
    }
}

// 人脸注册 按钮
void MainWindow::on_ai_face_register_btn_clicked()
{
    QString dlgTitle="注册姓名";
    QString str="输入英文姓名";
    QString defaultstr="please enter your name";
    QLineEdit::EchoMode echoMode=QLineEdit::Normal;

    bool choose=false;
    QString input = QInputDialog::getText(this, dlgTitle,str, echoMode, defaultstr, &choose);
    if (choose)
    {
        if(input.isEmpty())
            return;
        m_reg_name=input.toStdString();
        ui->statusBar->showMessage(input);
    }
}
