﻿#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>
#include <QtCore>
#include <iostream>
#include <functional>

using namespace std;
// 回调函数类型
typedef std::function<void(void*)> _CALLBACK;

class Q_Thread : public QThread
{
    Q_OBJECT
public:
    explicit Q_Thread(QObject * parent=nullptr);
    ~Q_Thread();

    enum Status {
        IDLE,
        RUN,
        PAUSE,
        STOP
    };
    // 注册回调函数
    void RegeditCallBack(_CALLBACK fun,void* para=nullptr);

signals:
    void message();
    void Q_ThreadSignal(const QString& msg);
    void Q_ThreadSignal(const QString& act,
                   const QString& cnt1,
                   const QString& cnt2);
protected:
    // 回调函数
    _CALLBACK callback = static_cast<_CALLBACK>(nullptr);
    // 回调函数参数
    void* parameter = static_cast<void*>(nullptr);
    virtual void run();
};

#endif // MYTHREAD_H
