#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include "custom_dialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPushButton *button = new QPushButton(tr("关于"));
    ui->mainToolBar->addWidget(button);
    connect(button, SIGNAL(clicked()), this, SLOT(showWin()));
    // 下面完善槽函数
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showWin()
{
    Custom_Dialog *helpWin = new Custom_Dialog();             // 此处对类进行实例化
    helpWin->resize(600, 400);                              // 设置图像大小
    QLabel *label_about = new QLabel(helpWin);
    label_about->setText(tr("图像处理自编软件 1.0 版"));
    QLabel *label_right = new QLabel(helpWin);
    label_right->setText(tr("Copyright (C) 2018  深圳 ATR"));
    QLabel *label_author = new QLabel(helpWin);
    label_author->setText(tr("作者：笔尖   http://blog.csdn.net/u013165921"));
    QPushButton *button_ok = new QPushButton(helpWin);
    button_ok->setText(tr("确定"));
    connect(button_ok, SIGNAL(clicked()), helpWin, SLOT(close()));
    label_about->move(100, 100);
    label_right->move(100, 180);
    label_author->move(100, 260);
    button_ok->move(400, 180);
    helpWin->exec();            // 模态对话框，关闭该子窗口前不能对主窗口进行任何操作。
}
