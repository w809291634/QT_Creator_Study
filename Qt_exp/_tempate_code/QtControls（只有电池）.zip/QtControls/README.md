# QtControls
视频演示：
[点击观看演示视频](https://www.bilibili.com/video/bv1u7411976V)                                                    
关注微信公众号：嵌入式基地                                      
后台回复：嵌入式基地  获取更多资料                                      
 
