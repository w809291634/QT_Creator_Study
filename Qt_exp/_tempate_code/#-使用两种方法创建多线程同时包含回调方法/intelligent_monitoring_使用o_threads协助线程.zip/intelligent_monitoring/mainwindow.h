#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore>
#include <QCameraInfo>
#include <QInputDialog>
#include <QMessageBox>

#include <chrono>

#include "o_thread.h"
#include "ncnn_detect/persondet/src/persondet.h"
#include "ncnn_detect/face_recognition/src/facerec.h"
#include "ncnn_detect/face_detection/src/FaceDetector.h"
#include "ncnn_detect/pose_detection/src/simplepose.h"

using namespace std;
using namespace chrono;

#define NCNN_MODEL_PATH         "./ncnn_detect/"
#define FACE_FEATURE_PATH       "./features.txt"
#define STR1(R)         #R
#define STR2(R)         STR1(R)
#define CAMERA_TIMER_TIMEOUT    20     // 20ms读取一张图片并显示

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    enum Detect_Type {
        Person_Detection = 0x01,
        Pose_Detection = 0x02,
        Face_Detection = 0x03,
        Face_Recognition = 0x04,
    };

private slots:
    /** ncnn 功能函数函数 **/
    // 行人检测
    void persondet(cv::Mat& frame);
    // 姿态检测
    void posedet(cv::Mat& frame);
    // 人脸检测
    void facedet(cv::Mat& frame);
    // 人脸识别
    void facerec_init(std::string feature_path=FACE_FEATURE_PATH);
    int read_feats(const std::string &path, std::vector<FaceFeature> &feats);
    int write_feat(const std::string &path, FaceFeature &feat);
    void facerec(cv::Mat& frame);

    QImage QCVMat2QImage(const cv::Mat& mat);

    /** 状态更新 **/
    void app_init_ui();
    void app_error_ui();
    void camera_open_status();
    void camera_close_status();
    void camera_handle(char* data);
    void camera_handleTimeout();

    /** 控件槽函数 **/
    void on_openCamera_btn_clicked();
    void on_closeCamera_btn_clicked();
    void on_ai_person_detection_btn_clicked(bool checked);
    void on_ai_pose_detection_btn_clicked(bool checked);
    void on_ai_face_detection_btn_clicked(bool checked);
    void on_ai_face_recognition_btn_clicked(bool checked);
    void on_ai_face_register_btn_clicked();

private:
    Ui::MainWindow *ui;
    // 摄像头
    cv::VideoCapture* m_cap=static_cast<cv::VideoCapture*>(nullptr);
    int m_flag=0;
    QTimer* m_Camera_Timer;
    QSharedPointer<O_Thread> O_Thread_1;
    cv::Mat m_frame;
    QMutex Mutex;

    // 行人检测
    Persondet* m_persondet;
    // 姿态检测
    Posedet* m_posedet;
    // 人脸检测
    Detector* m_detector;
    // 人脸识别
    Facerec* m_facerec;
    std::vector<FaceFeature> m_face_feats;
    std::string m_feature_path;
    std::string m_reg_name;
};

#endif // MAINWINDOW_H
