#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include "future.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    void on_start_btn_clicked();
    void on_pause_btn_clicked();
    void on_resume_btn_clicked();
    void on_stop_btn_clicked();

    void on_start_btn_2_clicked();
    void on_pause_btn_2_clicked();
    void on_resume_btn_2_clicked();
    void on_stop_btn_2_clicked();

    void on_start_btn_3_clicked();
    void on_pause_btn_3_clicked();
    void on_resume_btn_3_clicked();
    void on_stop_btn_3_clicked();

    void on_start_btn_4_clicked();
    void on_pause_btn_4_clicked();
    void on_resume_btn_4_clicked();
    void on_stop_btn_4_clicked();

    void on_start_btn_5_clicked();
    void on_pause_btn_5_clicked();
    void on_resume_btn_5_clicked();
    void on_stop_btn_5_clicked();

    void on_start_btn_6_clicked();
    void on_pause_btn_6_clicked();
    void on_resume_btn_6_clicked();
    void on_stop_btn_6_clicked();

private:
    Ui::MainWindow *ui;
    QTimer* m_pTimer;

    Future<void> future{"future1"};    // void表示线程的返回
    void thread_1(QString msg);

    Future<void> future2{"future2"};    // void表示线程的返回
    void thread_2(QString msg);

    Future<void> future3{"future3"};
    void thread_3(QString msg);

    Future<void> future4{"future4"};
    void thread_4(QString msg);

    Future<void> future5{"future5"};
    void thread_5(QString msg);

    Future<void> future6{"future6"};
    void thread_6(QString msg);
};

#endif // MAINWINDOW_H
