/********************************************************************************
** Form generated from reading UI file 'code.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CODE_H
#define UI_CODE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Code
{
public:
    QHBoxLayout *horizontalLayout;
    QLabel *label_Code;

    void setupUi(QWidget *Code)
    {
        if (Code->objectName().isEmpty())
            Code->setObjectName(QString::fromUtf8("Code"));
        Code->resize(275, 275);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Code->sizePolicy().hasHeightForWidth());
        Code->setSizePolicy(sizePolicy);
        Code->setMinimumSize(QSize(250, 250));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/icon/image/xLabTools.ico"), QSize(), QIcon::Normal, QIcon::Off);
        Code->setWindowIcon(icon);
        horizontalLayout = new QHBoxLayout(Code);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_Code = new QLabel(Code);
        label_Code->setObjectName(QString::fromUtf8("label_Code"));

        horizontalLayout->addWidget(label_Code);


        retranslateUi(Code);

        QMetaObject::connectSlotsByName(Code);
    } // setupUi

    void retranslateUi(QWidget *Code)
    {
        Code->setWindowTitle(QApplication::translate("Code", "IDK\345\210\206\344\272\253", nullptr));
        label_Code->setText(QApplication::translate("Code", "<html><head/><body><p align=\"center\"><br/></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Code: public Ui_Code {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CODE_H
