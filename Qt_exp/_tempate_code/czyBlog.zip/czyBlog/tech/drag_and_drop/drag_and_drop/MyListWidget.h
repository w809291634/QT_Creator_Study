#ifndef MYLISTWIDGET_H
#define MYLISTWIDGET_H


class MyListWidget
{
public:
    MyListWidget();
};

#endif // MYLISTWIDGET_H