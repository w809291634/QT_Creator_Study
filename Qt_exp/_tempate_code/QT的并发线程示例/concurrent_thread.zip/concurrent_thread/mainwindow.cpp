﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#define USE_FULL_SPEED

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QThreadPool::globalInstance()->setMaxThreadCount(4);            // 设置全局线程池的最大线程数量，决定run运行线程最大数量
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 线程1
void MainWindow::thread_1(QString msg)
{
    (void)msg;
#ifndef USE_FULL_SPEED
    int data=0;
#endif
    THREAD_HEAD(future){
        // 线程主要干的事情
#ifndef USE_FULL_SPEED
        ui->lineEdit->setText(QString("%1").arg(data));
        data++;
        QThread::msleep(10);
#endif
    }
    THREAD_TAIL;
}

// 线程2
void MainWindow::thread_2(QString msg)
{
    (void)msg;
#ifndef USE_FULL_SPEED
    int data=0;
#endif
    THREAD_HEAD(future2){
#ifndef USE_FULL_SPEED
        ui->lineEdit_2->setText(QString("%1").arg(data));
        data++;
        QThread::msleep(10);
#endif
    }
    THREAD_TAIL;
}

void MainWindow::thread_3(QString msg)
{
    (void)msg;
#ifndef USE_FULL_SPEED
    int data=0;
#endif
    THREAD_HEAD(future3){
#ifndef USE_FULL_SPEED
        ui->lineEdit_3->setText(QString("%1").arg(data));
        data++;
        QThread::msleep(10);
#endif
    }
    THREAD_TAIL;
}

void MainWindow::thread_4(QString msg)
{
    (void)msg;
#ifndef USE_FULL_SPEED
    int data=0;
#endif
    THREAD_HEAD(future4){
#ifndef USE_FULL_SPEED
        ui->lineEdit_4->setText(QString("%1").arg(data));
        data++;
        QThread::msleep(10);
#endif
    }
    THREAD_TAIL;
}

void MainWindow::thread_5(QString msg)
{
    (void)msg;
#ifndef USE_FULL_SPEED
    int data=0;
#endif
    THREAD_HEAD(future5){
#ifndef USE_FULL_SPEED
        ui->lineEdit_5->setText(QString("%1").arg(data));
        data++;
        QThread::msleep(10);
#endif
    }
    THREAD_TAIL;
}

void MainWindow::thread_6(QString msg)
{
    (void)msg;
#ifndef USE_FULL_SPEED
    int data=0;
#endif
    THREAD_HEAD(future6){
#ifndef USE_FULL_SPEED
        ui->lineEdit_6->setText(QString("%1").arg(data));
        data++;
        QThread::msleep(10);
#endif
    }
    THREAD_TAIL;
}

/** 线程1槽函数 **/
void MainWindow::on_start_btn_clicked()
{
    if(future.isStoped()){
        future.run(QtConcurrent::run(this,&MainWindow::thread_1,QString("msg")));
    }
}

void MainWindow::on_pause_btn_clicked()
{
    future.pause();
}

void MainWindow::on_resume_btn_clicked()
{
    future.resume();
}

void MainWindow::on_stop_btn_clicked()
{
    future.stop();
}

/** 线程2槽函数 **/
void MainWindow::on_start_btn_2_clicked()
{
    if(future2.isStoped()){
        future2.run(QtConcurrent::run(this,&MainWindow::thread_2,QString("msg")));
    }
}

void MainWindow::on_pause_btn_2_clicked()
{
    future2.pause();
}

void MainWindow::on_resume_btn_2_clicked()
{
    future2.resume();
}

void MainWindow::on_stop_btn_2_clicked()
{
    future2.stop();
}


/** 线程3槽函数 **/
void MainWindow::on_start_btn_3_clicked()
{
    if(future3.isStoped()){
        future3.run(QtConcurrent::run(this,&MainWindow::thread_3,QString("msg")));
    }
}

void MainWindow::on_pause_btn_3_clicked()
{
    future3.pause();
}

void MainWindow::on_resume_btn_3_clicked()
{
    future3.resume();
}

void MainWindow::on_stop_btn_3_clicked()
{
    future3.stop();
}

/** 线程4槽函数 **/
void MainWindow::on_start_btn_4_clicked()
{
    if(future4.isStoped()){
        future4.run(QtConcurrent::run(this,&MainWindow::thread_4,QString("msg")));
    }
}

void MainWindow::on_pause_btn_4_clicked()
{
    future4.pause();
}

void MainWindow::on_resume_btn_4_clicked()
{
    future4.resume();
}

void MainWindow::on_stop_btn_4_clicked()
{
    future4.stop();
}

/** 线程5槽函数 **/
void MainWindow::on_start_btn_5_clicked()
{
    if(future5.isStoped()){
        future5.run(QtConcurrent::run(this,&MainWindow::thread_5,QString("msg")));
    }
}

void MainWindow::on_pause_btn_5_clicked()
{
    future5.pause();
}

void MainWindow::on_resume_btn_5_clicked()
{
    future5.resume();
}

void MainWindow::on_stop_btn_5_clicked()
{
    future5.stop();
}

/** 线程5槽函数 **/
void MainWindow::on_start_btn_6_clicked()
{
    if(future6.isStoped()){
        future6.run(QtConcurrent::run(this,&MainWindow::thread_6,QString("msg")));
    }
}

void MainWindow::on_pause_btn_6_clicked()
{
    future6.pause();
}

void MainWindow::on_resume_btn_6_clicked()
{
    future6.resume();
}

void MainWindow::on_stop_btn_6_clicked()
{
    future6.stop();
}
