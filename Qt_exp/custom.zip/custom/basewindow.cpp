#include "basewindow.h"

BaseWindow::BaseWindow()
{

}
