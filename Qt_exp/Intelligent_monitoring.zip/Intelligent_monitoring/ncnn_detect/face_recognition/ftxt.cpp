#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main()
{
    /*
    int i, s[10];
    for (i = 0; i < 10; i++)
        s[i] = i * 2;

    ofstream outfile;//创建文件
    outfile.open("data.txt", ofstream::app);
    for (i = 0;i < 10; i++)
        outfile << s[i] << endl;

    outfile.close();
    */

    ifstream infile;
    infile.open("data.txt");
    string output;
    if (infile.is_open()) {
        while (!infile.eof()) {
            infile >> output;
            cout << output << endl;
        }
    }
    infile.close();

    return 0;
}
