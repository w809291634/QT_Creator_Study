﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#if defined(_MSC_VER) && (_MSC_VER >= 1600)
# pragma execution_character_set("utf-8")
#endif

#include <QMainWindow>
#include <iostream>
#include <functional>
using namespace std;
typedef std::function<void(void*)> _CALLBACK;

namespace Ui {
class MainWindow;
}
class O_Thread;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_start_clicked();
    void on_stop_clicked();
    void on_deleteLater_clicked();
    void on_clear_clicked();

    void on_start_2_clicked();
    void on_stop_2_clicked();
    void on_deleteLater_2_clicked();
    void on_clear_2_clicked();

    void on_start_3_clicked();
    void on_stop_3_clicked();
    void on_deleteLater_3_clicked();

    void update_info(const QString& info);
    void update_info2(const QString& info);
    void on_pushButton_clicked();

private:
    void callbackfun1(void* parameter);
    void callbackfun2(void* parameter);

    Ui::MainWindow *ui;
    QSharedPointer<O_Thread> O_Thread_1;
    QSharedPointer<O_Thread> O_Thread_2;

    bool direct_operate=false;
};

extern MainWindow* _mian_win;
#endif // MAINWINDOW_H
