﻿#include "mainwindow.h"
#include <QApplication>
#include "mythread.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    app_main(&w);
    w.resize(800, 480);
    w.show();

    return a.exec();
}
