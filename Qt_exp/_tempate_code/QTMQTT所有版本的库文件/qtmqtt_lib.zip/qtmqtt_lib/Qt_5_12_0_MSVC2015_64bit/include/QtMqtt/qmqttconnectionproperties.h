#include "../../../qtmqtt/src/mqtt/qmqttconnectionproperties.h"
