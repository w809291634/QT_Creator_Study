﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "o_thread.h"

void callbackfun3(char* parameter);
static QSharedPointer<O_Thread> O_Thread_3;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->pushButton->setCheckable(true);

    /** 子线程1 **/
    O_Thread_1.reset(new O_Thread("thread1"));
    // 绑定成员函数
    auto Fun1 = bind(&MainWindow::callbackfun1,
                    this, placeholders::_1);
    // 传入 参数
    char data[]="O_Thread_1_parameter";
    O_Thread_1->RegeditCallBack(Fun1,data);
    connect(O_Thread_1.data(),SIGNAL(message(const QString&)),
            this,SLOT(update_info(const QString&)));

    /** 子线程2 **/
    O_Thread_2.reset(new O_Thread("thread2",O_Thread::LowPriority));
    // 绑定成员函数
    auto Fun2 = bind(&MainWindow::callbackfun2,
                    this, placeholders::_1);
    // 这个线程没有参数
    O_Thread_2->RegeditCallBack(Fun2);
    connect(O_Thread_2.data(),SIGNAL(message(const QString&)),
            this,SLOT(update_info2(const QString&)));

    /** 子线程3 **/
    O_Thread_3.reset(new O_Thread("thread3",O_Thread::LowPriority));
    // 绑定普通函数
    auto Fun3 = bind(callbackfun3, placeholders::_1);
    // 传入参数
    char data1[]="O_Thread_3_parameter";
    O_Thread_3->RegeditCallBack(Fun3,data1);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 线程1 间接更新消息
void MainWindow::update_info(const QString& info)
{
    ui->listWidget->addItem(info);
}

// 线程1回调函数
void MainWindow::callbackfun1(char* parameter)
{
    // 获取参数
    if(parameter!=nullptr){
        QString argu=QString((static_cast<char*>(parameter)));
        qDebug()<<argu;
    }
    uint8_t count=0;
    // 线程主体
    while(O_Thread_1->get_status()==O_Thread::RUN){
        count++;
        QString info=QString("count:%1 priority:%2")
                .arg(count)
                .arg(O_Thread_1->thread->priority());

        // 为了验证在其他线程中操作UI时会不会影响CPU数据
        if(direct_operate){
            ui->listWidget->addItem(info);
        }else{
            emit O_Thread_1->message(info);
        }
        O_Thread_1->thread->msleep(500);
    }
}

// 线程2 间接更新消息
void MainWindow::update_info2(const QString& info)
{
    ui->listWidget_2->addItem(info);
}

// 线程2回调函数
void MainWindow::callbackfun2(char* parameter)
{
    // 获取参数
    if(parameter!=nullptr){
        QString argu=QString((static_cast<char*>(parameter)));
        qDebug()<<argu;
    }
    uint8_t count=0;
    // 线程主体
    while(O_Thread_2->get_status()==O_Thread::RUN){
        count++;
        QString info=QString("count:%1 priority:%2")
                .arg(count)
                .arg(O_Thread_2->thread->priority());

        // 为了验证在其他线程中操作UI时会不会影响CPU数据
        if(direct_operate){
            ui->listWidget_2->addItem(info);
        }else{
            emit O_Thread_2->message(info);
        }
        O_Thread_2->thread->sleep(1);
    }
}

// 为了验证在其他线程中操作UI时会不会影响CPU数据
void MainWindow::on_pushButton_clicked()
{
    direct_operate=!direct_operate;
    if(direct_operate)ui->pushButton->setChecked(true);
    else ui->pushButton->setChecked(false);
}

// 线程3回调函数
void callbackfun3(char* parameter)
{
    // 获取参数
    if(parameter!=nullptr){
        QString argu=QString((static_cast<char*>(parameter)));
        qDebug()<<argu;
    }
    uint8_t count=0;
    // 线程主体
    while(O_Thread_3->get_status()==O_Thread::RUN){
        count++;
        qDebug()<<count;
        O_Thread_3->thread->sleep(1);
    }
}

void MainWindow::on_start_clicked()
{
    O_Thread_1->start();
}

void MainWindow::on_stop_clicked()
{
    O_Thread_1->stop();
}

void MainWindow::on_deleteLater_clicked()
{
    O_Thread_1->deleteLater();
    O_Thread_1->QObject::deleteLater();
}

void MainWindow::on_start_2_clicked()
{
    O_Thread_2->start();
}

void MainWindow::on_stop_2_clicked()
{
    O_Thread_2->stop();
}

void MainWindow::on_deleteLater_2_clicked()
{
    O_Thread_2->deleteLater();
    O_Thread_2->QObject::deleteLater();
}

void MainWindow::on_clear_clicked()
{
    ui->listWidget->clear();
}

void MainWindow::on_clear_2_clicked()
{
    ui->listWidget_2->clear();
}

void MainWindow::on_start_3_clicked()
{
    O_Thread_3->start();
}

void MainWindow::on_stop_3_clicked()
{
    O_Thread_3->stop();
}

void MainWindow::on_deleteLater_3_clicked()
{
    O_Thread_3->deleteLater();
    O_Thread_3->QObject::deleteLater();
}


