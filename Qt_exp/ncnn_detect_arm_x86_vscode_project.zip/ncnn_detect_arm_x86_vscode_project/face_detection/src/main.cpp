#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <thread>
#include <chrono>
#include <ctime>
#include "mat.h"
#include <opencv2/opencv.hpp>
// #include "blazeface.h"
#include "FaceDetector.h"


using namespace cv;
using namespace std;

float scale = 1.f;


cv::Mat predict(Detector& model, Mat image) {
    Timer timer;
    timer.tic();

    std::vector<bbox> boxes;
    std::cout << "Start inference ..." << std::endl;
    model.Detect(image, boxes);

    // draw image
    for (int j = 0; j < boxes.size(); ++j) {
        cv::rectangle(image, cv::Point(boxes[j].x1/scale, boxes[j].y1/scale), cv::Point(boxes[j].x2/scale, boxes[j].y2/scale), cv::Scalar(0, 0, 255), 2);
        char test[80];
        sprintf(test, "%f", boxes[j].s);

        cv::putText(image, test, cv::Point((boxes[j].x1/scale), boxes[j].y1/scale), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 255));
        cv::circle(image, cv::Point(boxes[j].point[0]._x / scale, boxes[j].point[0]._y / scale), 1, cv::Scalar(0, 0, 225), 4);
        cv::circle(image, cv::Point(boxes[j].point[1]._x / scale, boxes[j].point[1]._y / scale), 1, cv::Scalar(0, 255, 225), 4);
        cv::circle(image, cv::Point(boxes[j].point[2]._x / scale, boxes[j].point[2]._y / scale), 1, cv::Scalar(255, 0, 225), 4);
        cv::circle(image, cv::Point(boxes[j].point[3]._x / scale, boxes[j].point[3]._y / scale), 1, cv::Scalar(0, 255, 0), 4);
        cv::circle(image, cv::Point(boxes[j].point[4]._x / scale, boxes[j].point[4]._y / scale), 1, cv::Scalar(255, 0, 0), 4);
    }

    timer.toc("predict=========: ");
    std::cout << "Finished!" << std::endl;
    return image;
}

int main(int argc, char *argv[])
{
    //open the video file for reading
    VideoCapture cap(0); 

    // if not success, exit program
    if (cap.isOpened() == false)  
    {
        cout << "Cannot open the video file" << endl;
        cin.get(); //wait for any key press
        return -1;
    }

    //get the frames rate of the video
    double fps = cap.get(CAP_PROP_FPS); 
    cout << "Frames per seconds : " << fps << endl;
    String window_name = "My First Video";
    namedWindow(window_name, WINDOW_NORMAL); //create a window

    std::string param = "../face_detection/data/blaceface.param";
    std::string bin = "../face_detection/data/blaceface.bin";
    const int max_side = 320;
    float scale = 1.f;
    Detector detector(param, bin, max_side, false);

    while (true)
    {
        Mat frame;
        bool bSuccess = cap.read(frame); // read a new frame from video 

        //Breaking the while loop at the end of the video
        if (bSuccess == false) 
        {
            cout << "Found the end of the video" << endl;
            break;
        }

        //show the frame in the created window
        cv::Mat image = predict(detector, frame);
        imshow(window_name, image);

        //wait for for 10 ms until any key is pressed.  
        //If the 'Esc' key is pressed, break the while loop.
        //If the any other key is pressed, continue the loop 
        //If any key is not pressed withing 10 ms, continue the loop
        if (waitKey(10) == 27)
        {
            cout << "Esc key is pressed by user. Stoppig the video" << endl;
            break;
        }
    }

    return 0;
}

