#ifndef CUSTOM_DIALOG_H
#define CUSTOM_DIALOG_H

#include <QtWidgets>
#include <QDialog>

class Custom_Dialog: public QDialog
{
public:
    Custom_Dialog(QWidget *parent = nullptr);
    ~Custom_Dialog();
protected:
    void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
private:
    bool        mMoveing;
    QPoint      mMovePosition;
};

#endif // CUSTOM_DIALOG_H
