/********************************************************************************
** Form generated from reading UI file 'lorawanchm.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LORAWANCHM_H
#define UI_LORAWANCHM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoRaWANChm
{
public:
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *lbl_hint;
    QSpacerItem *horizontalSpacer;
    QDialogButtonBox *buttonBox;

    void setupUi(QWidget *LoRaWANChm)
    {
        if (LoRaWANChm->objectName().isEmpty())
            LoRaWANChm->setObjectName(QString::fromUtf8("LoRaWANChm"));
        LoRaWANChm->resize(390, 441);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(LoRaWANChm->sizePolicy().hasHeightForWidth());
        LoRaWANChm->setSizePolicy(sizePolicy);
        LoRaWANChm->setMinimumSize(QSize(0, 0));
        LoRaWANChm->setMaximumSize(QSize(16777215, 16777215));
        horizontalLayout_2 = new QHBoxLayout(LoRaWANChm);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tableWidget = new QTableWidget(LoRaWANChm);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setLayoutDirection(Qt::LeftToRight);
        tableWidget->setDefaultDropAction(Qt::IgnoreAction);
        tableWidget->setTextElideMode(Qt::ElideRight);
        tableWidget->setRowCount(0);
        tableWidget->setColumnCount(0);
        tableWidget->horizontalHeader()->setDefaultSectionSize(40);

        verticalLayout->addWidget(tableWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        lbl_hint = new QLabel(LoRaWANChm);
        lbl_hint->setObjectName(QString::fromUtf8("lbl_hint"));
        QFont font;
        font.setPointSize(11);
        lbl_hint->setFont(font);

        horizontalLayout->addWidget(lbl_hint);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        buttonBox = new QDialogButtonBox(LoRaWANChm);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        horizontalLayout->addWidget(buttonBox);


        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_2->addLayout(verticalLayout);


        retranslateUi(LoRaWANChm);

        QMetaObject::connectSlotsByName(LoRaWANChm);
    } // setupUi

    void retranslateUi(QWidget *LoRaWANChm)
    {
        LoRaWANChm->setWindowTitle(QApplication::translate("LoRaWANChm", "\344\277\241\351\201\223\346\216\251\347\240\201(\345\217\214\345\207\273\344\277\256\346\224\271)", nullptr));
        lbl_hint->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class LoRaWANChm: public Ui_LoRaWANChm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LORAWANCHM_H
