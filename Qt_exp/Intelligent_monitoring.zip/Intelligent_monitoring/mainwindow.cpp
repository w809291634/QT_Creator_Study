#include "mainwindow.h"
#include "ui_mainwindow.h"

#define STR1(R)         #R
#define STR2(R)         STR1(R)
#define CAMERA_TIMER_TIMEOUT    20                  // 20ms读取一张图片并显示

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 读取所有摄像头信息
    QList<QCameraInfo> infos = QCameraInfo::availableCameras();
    foreach(QCameraInfo info, infos){
        qDebug()<<info.description()<<info.deviceName();
        ui->camera_cbox->addItem(info.deviceName());
    }
    // 新建 VideoCapture 类
    m_cap =new cv::VideoCapture();

    // 获取工程路径
    QString project_path=STR2(PROJECT_PATH);
    qDebug() <<project_path;

    // 创建所有的模型类
    m_persondet = new Persondet();

    if(m_persondet->init((project_path+"/ncnn_detect/persondet").toStdString())==0)
    {
        // 用于刷新摄像头数据
        m_Camera_Timer = new QTimer(this);
        connect(m_Camera_Timer, SIGNAL(timeout()), this, SLOT(camera_handleTimeout()));
        m_Camera_Timer->start(CAMERA_TIMER_TIMEOUT);

        app_init_ui();
    }else{
        app_error_ui();
    }
}

MainWindow::~MainWindow()
{
    delete ui;

    delete m_cap;
    delete m_persondet;
}

/** 状态更新 **/
// APP初始化UI
void MainWindow::app_init_ui()
{
    ui->ai_person_detection_btn->setCheckable(true);
    ui->ai_pose_detection_btn->setCheckable(true);
    ui->ai_face_detection_btn->setCheckable(true);
    ui->ai_face_recognition_btn->setCheckable(true);

    // 解决 QLabel 无法缩放的问题
    ui->camera_view_label->setSizePolicy(QSizePolicy::Ignored,QSizePolicy::Ignored);
    // 显示为摄像头关闭状态
    camera_close_status();
}

// APP初始化错误状态的UI
void MainWindow::app_error_ui()
{
    camera_close_status();
    ui->camera_view_label->setText("启动错误，请检查模型文件路径，请退出");

    ui->openCamera_btn->setEnabled(false);
    ui->closeCamera_btn->setEnabled(false);
}

// 摄像头打开状态
void MainWindow::camera_open_status()
{
    ui->ai_person_detection_btn->setEnabled(true);
    ui->ai_pose_detection_btn->setEnabled(true);
    ui->ai_face_detection_btn->setEnabled(true);
    ui->ai_face_recognition_btn->setEnabled(true);
}

// 摄像头关闭状态
void MainWindow::camera_close_status()
{
    ui->camera_view_label->setText("请打开摄像头");

    ui->ai_person_detection_btn->setEnabled(false);
    ui->ai_pose_detection_btn->setEnabled(false);
    ui->ai_face_detection_btn->setEnabled(false);
    ui->ai_face_recognition_btn->setEnabled(false);

    // 设置AI按钮没有打开
    ui->ai_person_detection_btn->setChecked(false);
    ui->ai_pose_detection_btn->setChecked(false);
    ui->ai_face_detection_btn->setChecked(false);
    ui->ai_face_recognition_btn->setChecked(false);
}

// 刷新摄像头数据
void MainWindow::camera_handleTimeout()
{
    if(m_cap->isOpened()==true)
    {
        cv::Mat frame;
        // 获取一张图片
        bool bSuccess = m_cap->read(frame);
        // 判断是否获取成功
        if (bSuccess == false)
        {
            qDebug() << "Found the end of the video";
            on_closeCamera_btn_clicked();
        }
        // 进行 推理类型的选择
        switch(m_flag){
            case Person_Detection:
            m_persondet->detect(frame);
            break;
            case Pose_Detection:

            break;
            case Face_Detection:

            break;
            case Face_Recognition:

            break;
        }

        // 处理摄像头图像数据并缩放自适应窗口大小
        QImage img=QCVMat2QImage(frame);
        img = img.scaled(ui->camera_view_label->size(),
                         Qt::KeepAspectRatio,Qt::SmoothTransformation);
        ui->camera_view_label->setPixmap(QPixmap::fromImage(img));
    }
}

/** 按钮槽函数 **/
// 打开摄像头按钮
void MainWindow::on_openCamera_btn_clicked()
{
    std::string camera_path=ui->camera_cbox->currentText().toStdString();
    if(m_cap->isOpened()==false){
        m_cap->open(camera_path);
        if (m_cap->isOpened() == true)
        {
            m_cap->set(cv::CAP_PROP_FPS,30);
            double fps = m_cap->get(cv::CAP_PROP_FPS);
            QString info = QString("open the camera,Frames per seconds: %1fps").arg(fps);
            qDebug()<< info;
            camera_open_status();
        }
        else
        {
            qDebug()<< "Cannot open the camera";
            camera_close_status();
            return;
        }
    }
}

// 关闭摄像头按钮
void MainWindow::on_closeCamera_btn_clicked()
{
    if(m_cap->isOpened()==true){
        m_cap->release();
        if(m_cap->isOpened()==false){
            qDebug()<< "close the camera";
            camera_close_status();
        }
    }
}

// 行人检测 按钮
void MainWindow::on_ai_person_detection_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Person_Detection;
        ui->ai_pose_detection_btn->setChecked(false);
        ui->ai_face_detection_btn->setChecked(false);
        ui->ai_face_recognition_btn->setChecked(false);
    }else{
        m_flag=0;
    }
}

// 姿态检测 按钮
void MainWindow::on_ai_pose_detection_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Pose_Detection;
        ui->ai_person_detection_btn->setChecked(false);
        ui->ai_face_detection_btn->setChecked(false);
        ui->ai_face_recognition_btn->setChecked(false);
    }else{
        m_flag=0;
    }
}

// 人脸检测 按钮
void MainWindow::on_ai_face_detection_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Face_Detection;
        ui->ai_person_detection_btn->setChecked(false);
        ui->ai_pose_detection_btn->setChecked(false);
        ui->ai_face_recognition_btn->setChecked(false);
    }else{
        m_flag=0;
    }
}

// 人脸识别 按钮
void MainWindow::on_ai_face_recognition_btn_clicked(bool checked)
{
    if(checked){
        m_flag=Face_Recognition;
        ui->ai_person_detection_btn->setChecked(false);
        ui->ai_pose_detection_btn->setChecked(false);
        ui->ai_face_detection_btn->setChecked(false);
    }else{
        m_flag=0;
    }
}

/** ncnn 功能函数函数 **/
// cv::Mat 转换为 QImage
QImage MainWindow::QCVMat2QImage(const cv::Mat& mat)
{
    const unsigned char* data = mat.data;

    int width = mat.cols;
    int height = mat.rows;
    int bytesPerLine = static_cast<int>(mat.step);
    switch(mat.type())
    {
        //8 bit , ARGB
        case CV_8UC4:
        {
            QImage image(data, width, height, bytesPerLine, QImage::Format_ARGB32);
            return image;
        }

        //8 bit BGR
        case CV_8UC3:
        {
            QImage image(data, width, height, bytesPerLine, QImage::Format_RGB888);
            //swap blue and red channel
            return image.rgbSwapped();
        }

        //8 bit Gray shale
        case CV_8UC1:
        {
            QImage image(data, width, height, bytesPerLine, QImage::Format_Grayscale8);
            return image;
        }

        //
        default:
        {
            //Unsupported format
            qWarning()<<"Unsupported cv::Mat type:"<<mat.type()
                     <<", Empty QImage will be returned!";
            return QImage();
        }
    }
}

// ncnn推理
void MainWindow::ncnn_predict()
{

//    Mat frame;
//    bool bSuccess = cap.read(frame); // read a new frame from video

//    //Breaking the while loop at the end of the video
//    if (bSuccess == false)
//    {
//        cout << "Found the end of the video" << endl;
//        break;
//    }

//    //show the frame in the created window
//    cv::Mat image = predict(persondet, frame);
//    imshow(window_name, image);

//    //wait for for 10 ms until any key is pressed.
//    //If the 'Esc' key is pressed, break the while loop.
//    //If the any other key is pressed, continue the loop
//    //If any key is not pressed withing 10 ms, continue the loop
//    if (waitKey(10) == 27)
//    {
//        cout << "Esc key is pressed by user. Stoppig the video" << endl;
//        break;
//    }
}
