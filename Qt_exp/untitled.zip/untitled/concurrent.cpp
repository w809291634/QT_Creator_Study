#include "concurrent.h"

Concurrent_Thread::Concurrent_Thread(QObject *parent) :
    QObject(parent)
{
}

Concurrent_Thread::~Concurrent_Thread()
{

}

