#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include "mat.h"
#include <opencv2/opencv.hpp>
#include "facerec.h"
#include <string>

using namespace cv;
using namespace std;


int read_feats(const std::string &path, std::vector<FaceFeature> &feats)
{
    ifstream infile;
    infile.open(path);
    // string output;
    if (infile.is_open()) {
        int index = 0;
        while (!infile.eof()) {
            FaceFeature feat;
            // infile >> feats[index].name;
            infile >> feat.name;
            for (int i = 0; i < 128; ++i){
                infile >> feat.face_feature[i];
            }
            feats.push_back(feat);
            // cout << output << endl;
        }
    }
    infile.close();

    return 0;
}


int write_feat(const std::string &path, FaceFeature &feat)
{
    ofstream outfile;//创建文件
    outfile.open(path, ofstream::app);

    // string output;
    if (outfile.is_open()) {
        outfile << feat.name;
        for (int i = 0; i < 128; ++i){
            outfile << " " << feat.face_feature[i];
        }
        outfile << endl;
    }
    outfile.close();

    return 0;
}


int main(int argc, char *argv[])
{
    //open the video file for reading
    VideoCapture cap(0); 

    // if not success, exit program
    if (cap.isOpened() == false)  
    {
        cout << "Cannot open the video file" << endl;
        cin.get(); //wait for any key press
        return -1;
    }

    vector<FaceFeature> face_feats;
    std::string feature_path = "features.txt";
    bool read_flag = read_feats(feature_path, face_feats);
    if (read_flag == false)
    {
        cout << "No person registered." << endl;
    }
    //get the frames rate of the video
    double fps = cap.get(CAP_PROP_FPS); 
    cout << "Frames per seconds : " << fps << endl;
    String window_name = "My First Video";
    namedWindow(window_name, WINDOW_NORMAL); //create a window

    std::string model_path = ".";
    Facerec facerec;
    facerec.init(model_path);
    string name;
    bool reg_flag = false;

    cout << ">================================================================<" << endl;
    cout << "使用说明: " << endl;
    cout << "退出键: Esc " << endl;
    cout << "注册键: r, 按r后，需要在终端输入注册的姓名，按Enter键则输入完成. " << endl;
    cout << ">================================================================<" << endl;

    while (true)
    {
        Mat frame;
        bool bSuccess = cap.read(frame); // read a new frame from video 

        //Breaking the while loop at the end of the video
        if (bSuccess == false) 
        {
            cout << "Found the end of the video" << endl;
            break;
        }

        //show the frame in the created window
        std::vector<BboxFace> face_out = facerec.recognize(frame, face_feats);
        if ((reg_flag == true) && (face_out.size() > 0))
        {
            FaceFeature new_feat;
            new_feat.name = name;
            memcpy(new_feat.face_feature, face_out[0].rec.data, 128 * sizeof(float));
            write_feat(feature_path, new_feat);
            face_feats.push_back(new_feat);
            reg_flag = false;
        }
        imshow(window_name, frame);

        //wait for for 10 ms until any key is pressed.  
        //If the 'Esc' key is pressed, break the while loop.
        //If the any other key is pressed, continue the loop 
        //If any key is not pressed withing 10 ms, continue the loop
        int key = waitKey(10);
        if (key == 27)
        {
            cout << "Esc key is pressed by user. Stoppig the video" << endl;
            break;
        }
        // "r"
        else if (key == 114)
        {
            cout << "Please input register name: ";
            cin >> name;
            reg_flag = true;
        }
    }

    return 0;
}

