#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore>
#include <QCameraInfo>

#include "ncnn_detect/persondet/persondet.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    enum Detect_Type {
        Person_Detection = 0x01,
        Pose_Detection = 0x02,
        Face_Detection = 0x03,
        Face_Recognition = 0x04,
    };

private slots:
    // 控件槽函数
    void on_openCamera_btn_clicked();
    void on_closeCamera_btn_clicked();
    void on_ai_person_detection_btn_clicked(bool checked);
    void on_ai_pose_detection_btn_clicked(bool checked);
    void on_ai_face_detection_btn_clicked(bool checked);
    void on_ai_face_recognition_btn_clicked(bool checked);

    // ncnn 功能函数函数
    void ncnn_predict();
    QImage QCVMat2QImage(const cv::Mat& mat);

    // 状态更新
    void app_init_ui();
    void app_error_ui();
    void camera_open_status();
    void camera_close_status();
    void camera_handleTimeout();

private:
    Ui::MainWindow *ui;
    // 摄像头
    cv::VideoCapture* m_cap=static_cast<cv::VideoCapture*>(nullptr);
    QTimer* m_Camera_Timer;
    int m_flag=0;
    // ncnn模型
    Persondet* m_persondet;
};

#endif // MAINWINDOW_H
