﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);



    m_pTimer = new QTimer(this);
    connect(m_pTimer, SIGNAL(timeout()), this, SLOT(handleTimeout()));
    m_pTimer->start(1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::thread_1(QString msg)
{
    (void)msg;
    int data=0;
    while(!future.isStoped()){
        while(!future.isPaused()){
            if(future.isStoped())break;
            // 线程主要干的事情
            {
                ui->lineEdit->setText(QString("%1").arg(data));
                data++;
                QThread::msleep(10);
            }
        }
        QThread::msleep(100);
    }
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    (void)event;
    future.stop();
}

void MainWindow::handleTimeout()
{
//    qDebug()<< __LINE__ << QThread::currentThread();
}

void MainWindow::on_start_btn_clicked()
{
    future.run(QtConcurrent::run(this,&MainWindow::thread_1,QString("msg")));
}

void MainWindow::on_pause_btn_clicked()
{
    future.pause();
}

void MainWindow::on_resume_btn_clicked()
{
    future.resume();
}

void MainWindow::on_stop_btn_clicked()
{
    future.stop();
}
