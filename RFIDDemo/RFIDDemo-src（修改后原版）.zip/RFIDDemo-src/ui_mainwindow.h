/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_19;
    QHBoxLayout *horizontalLayout_18;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_20;
    QVBoxLayout *verticalLayout_7;
    QPushButton *pushButton_IDMode;
    QPushButton *pushButton_ICMode;
    QPushButton *pushButton_ETCMode;
    QPushButton *pushButton_ZigBeeMode;
    QPushButton *pushButton_3;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_14;
    QSpacerItem *horizontalSpacer_4;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_6;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_Com;
    QComboBox *comboBox_Com;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_Baud;
    QComboBox *comboBox_Baud;
    QVBoxLayout *verticalLayout_3;
    QPushButton *pushButton_Open;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_8;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_Time;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_5;
    QStackedWidget *stackedWidget;
    QWidget *page_ID;
    QHBoxLayout *horizontalLayout_17;
    QTabWidget *tabWidget_ID;
    QWidget *tab;
    QHBoxLayout *horizontalLayout_84;
    QVBoxLayout *verticalLayout_34;
    QHBoxLayout *horizontalLayout_78;
    QGroupBox *groupBox_23;
    QHBoxLayout *horizontalLayout_83;
    QVBoxLayout *verticalLayout_38;
    QRadioButton *ID_radioButton_EM4100;
    QRadioButton *ID_radioButton_T5557;
    QGroupBox *groupBox_25;
    QHBoxLayout *horizontalLayout_85;
    QLabel *label_32;
    QSpacerItem *horizontalSpacer_27;
    QGroupBox *groupBox_24;
    QHBoxLayout *horizontalLayout_82;
    QVBoxLayout *verticalLayout_37;
    QListWidget *ID_listWidget_Card_Data;
    QHBoxLayout *horizontalLayout_80;
    QPushButton *ID_pushButton_Del;
    QSpacerItem *horizontalSpacer_25;
    QLabel *ID_label_State;
    QSpacerItem *horizontalSpacer_26;
    QPushButton *ID_pushButton_Read_Card;
    QHBoxLayout *horizontalLayout_81;
    QLineEdit *ID_lineEdit_Write;
    QPushButton *ID_pushButton_Write_Card;
    QWidget *tab_2;
    QHBoxLayout *horizontalLayout_79;
    QHBoxLayout *horizontalLayout_12;
    QVBoxLayout *verticalLayout_4;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout_13;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_2;
    QTimeEdit *ID_timeEdit_Morn_Up;
    QLabel *label;
    QTimeEdit *ID_timeEdit_Morn_Down;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_3;
    QTimeEdit *ID_timeEdit_Afte_Up;
    QLabel *label_4;
    QTimeEdit *ID_timeEdit_Afte_Down;
    QPushButton *ID_pushButton_Save;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout_10;
    QTableView *ID_tableView_ID;
    QGroupBox *groupBox_5;
    QHBoxLayout *horizontalLayout_11;
    QTableView *ID_tableView_Data;
    QWidget *page_IC;
    QHBoxLayout *horizontalLayout_39;
    QTabWidget *tabWidget_IC;
    QWidget *tab_Basics;
    QHBoxLayout *horizontalLayout_45;
    QHBoxLayout *horizontalLayout_44;
    QVBoxLayout *verticalLayout_24;
    QGroupBox *groupBox_10;
    QHBoxLayout *horizontalLayout_37;
    QVBoxLayout *verticalLayout_20;
    QHBoxLayout *horizontalLayout_35;
    QVBoxLayout *verticalLayout_19;
    QLabel *label_51;
    QLabel *label_14;
    QLabel *label_13;
    QLabel *label_15;
    QVBoxLayout *verticalLayout_18;
    QComboBox *IC_comboBox_Pass_Regic;
    QHBoxLayout *horizontalLayout_34;
    QRadioButton *IC_radioButton_Pass_A;
    QRadioButton *IC_radioButton_Pass_B;
    QLineEdit *IC_lineEdit_Pass_Last;
    QLineEdit *IC_lineEdit_Pass_New;
    QHBoxLayout *horizontalLayout_36;
    QLabel *IC_label_Pass_State;
    QSpacerItem *horizontalSpacer_12;
    QPushButton *IC_pushButton_Pass_Save;
    QGroupBox *groupBox_12;
    QHBoxLayout *horizontalLayout_43;
    QVBoxLayout *verticalLayout_22;
    QListWidget *IC_listWidget_Look_Data;
    QHBoxLayout *horizontalLayout_27;
    QPushButton *IC_pushButton_Look_Del;
    QSpacerItem *horizontalSpacer_14;
    QPushButton *IC_pushButton_one;
    QPushButton *IC_pushButton_Look_Bign;
    QGroupBox *groupBox_9;
    QHBoxLayout *horizontalLayout_38;
    QVBoxLayout *verticalLayout_62;
    QHBoxLayout *horizontalLayout_30;
    QVBoxLayout *verticalLayout_21;
    QLabel *label_11;
    QLabel *label_30;
    QVBoxLayout *verticalLayout_57;
    QComboBox *IC_comboBox_Sys_Region;
    QComboBox *IC_comboBox_passMode;
    QVBoxLayout *verticalLayout_58;
    QLabel *label_12;
    QLabel *label_16;
    QVBoxLayout *verticalLayout_61;
    QComboBox *IC_comboBox_Sys_Lump;
    QLineEdit *IC_lineEdit_Sys_Pass;
    QVBoxLayout *verticalLayout_17;
    QHBoxLayout *horizontalLayout_31;
    QLabel *label_10;
    QSpacerItem *horizontalSpacer_11;
    QListWidget *IC_listWidget_Sys_Data;
    QHBoxLayout *horizontalLayout_33;
    QVBoxLayout *verticalLayout_16;
    QHBoxLayout *horizontalLayout_32;
    QPushButton *IC_pushButton_Sys_Del;
    QSpacerItem *horizontalSpacer_10;
    QLabel *IC_label_Data_State;
    QSpacerItem *horizontalSpacer_16;
    QLineEdit *IC_lineEdit_Sys_Write;
    QVBoxLayout *verticalLayout_15;
    QPushButton *IC_pushButton_Sys_Read;
    QPushButton *IC_pushButton_Sys_Write;
    QWidget *tab_App;
    QHBoxLayout *horizontalLayout_46;
    QVBoxLayout *verticalLayout_23;
    QHBoxLayout *horizontalLayout_25;
    QGroupBox *groupBox_8;
    QHBoxLayout *horizontalLayout_42;
    QHBoxLayout *horizontalLayout_22;
    QVBoxLayout *verticalLayout_9;
    QLabel *label_17;
    QLabel *label_6;
    QLabel *label_7;
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_21;
    QLineEdit *IC_lineEdit_Mess_Pass;
    QPushButton *IC_pushButton_Mess;
    QLineEdit *IC_lineEdit_Mess_Num;
    QLineEdit *IC_lineEdit_Mess_Money;
    QGroupBox *groupBox_6;
    QHBoxLayout *horizontalLayout_26;
    QVBoxLayout *verticalLayout_11;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_6;
    QLineEdit *IC_lineEdit_Up_Money;
    QHBoxLayout *horizontalLayout_24;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *IC_pushButton_Up;
    QLabel *label_5;
    QGroupBox *groupBox_7;
    QHBoxLayout *horizontalLayout_48;
    QVBoxLayout *verticalLayout_14;
    QHBoxLayout *horizontalLayout_28;
    QLabel *label_9;
    QSpacerItem *horizontalSpacer_9;
    QLineEdit *IC_lineEdit_Down_Money;
    QHBoxLayout *horizontalLayout_29;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *IC_pushButton_Down;
    QGroupBox *groupBox_11;
    QHBoxLayout *horizontalLayout_41;
    QVBoxLayout *verticalLayout_13;
    QListWidget *IC_listWidget_Data;
    QHBoxLayout *horizontalLayout_40;
    QSpacerItem *horizontalSpacer_13;
    QPushButton *IC_pushButton_Data_Del;
    QWidget *tab_3;
    QHBoxLayout *horizontalLayout_110;
    QHBoxLayout *horizontalLayout_101;
    QVBoxLayout *verticalLayout_59;
    QGroupBox *groupBox_26;
    QHBoxLayout *horizontalLayout_100;
    QHBoxLayout *horizontalLayout_87;
    QVBoxLayout *verticalLayout_39;
    QLabel *label_34;
    QLabel *label_35;
    QLabel *IC_label_Pass_Text;
    QVBoxLayout *verticalLayout_43;
    QLineEdit *IC_lineEdit_App_Card_Num;
    QLineEdit *IC_lineEdit_App_Balance;
    QHBoxLayout *horizontalLayout_20;
    QLineEdit *IC_lineEdit_Pass;
    QPushButton *IC_pushButton_Pass_oK;
    QGroupBox *groupBox_41;
    QHBoxLayout *horizontalLayout_99;
    QHBoxLayout *horizontalLayout_88;
    QRadioButton *IC_radioButton_Out;
    QRadioButton *IC_radioButton_In;
    QGroupBox *groupBox_28;
    QHBoxLayout *horizontalLayout_95;
    QVBoxLayout *verticalLayout_41;
    QHBoxLayout *horizontalLayout_94;
    QLabel *label_38;
    QSpacerItem *horizontalSpacer_30;
    QLineEdit *IC_lineEdit_App_Ticket;
    QHBoxLayout *horizontalLayout_93;
    QSpacerItem *horizontalSpacer_31;
    QPushButton *IC_pushButton_App_Ticket;
    QGroupBox *groupBox_27;
    QHBoxLayout *horizontalLayout_92;
    QVBoxLayout *verticalLayout_40;
    QHBoxLayout *horizontalLayout_91;
    QLabel *label_37;
    QSpacerItem *horizontalSpacer_28;
    QLineEdit *IC_lineEdit_App_Up_Money;
    QHBoxLayout *horizontalLayout_90;
    QSpacerItem *horizontalSpacer_29;
    QPushButton *IC_pushButton_App_Up_Money;
    QGroupBox *groupBox_29;
    QHBoxLayout *horizontalLayout_98;
    QLabel *IC_label_Head_Money;
    QSpacerItem *verticalSpacer_4;
    QGroupBox *groupBox_30;
    QHBoxLayout *horizontalLayout_97;
    QVBoxLayout *verticalLayout_42;
    QListWidget *IC_listWidget_App_Data;
    QHBoxLayout *horizontalLayout_96;
    QPushButton *IC_pushButton_Ticket_Reset;
    QSpacerItem *horizontalSpacer_32;
    QPushButton *IC_pushButton_App_Del_Data;
    QWidget *page;
    QHBoxLayout *horizontalLayout_50;
    QTabWidget *tabWidget_ETC;
    QWidget *tab_ETC_Basics;
    QHBoxLayout *horizontalLayout_113;
    QHBoxLayout *horizontalLayout_111;
    QVBoxLayout *verticalLayout_48;
    QGroupBox *groupBox_31;
    QHBoxLayout *horizontalLayout_102;
    QVBoxLayout *verticalLayout_44;
    QHBoxLayout *horizontalLayout_57;
    QLabel *label_36;
    QComboBox *ETC_comboBox_Region;
    QHBoxLayout *horizontalLayout_60;
    QPushButton *ETC_pushButton_Region_Get;
    QSpacerItem *horizontalSpacer_33;
    QLabel *ETC_label_Region_State;
    QSpacerItem *horizontalSpacer_35;
    QPushButton *ETC_pushButton_Region_Set;
    QGroupBox *groupBox_33;
    QHBoxLayout *horizontalLayout_105;
    QVBoxLayout *verticalLayout_45;
    QHBoxLayout *horizontalLayout_103;
    QLabel *label_41;
    QComboBox *ETC_comboBox_RF;
    QHBoxLayout *horizontalLayout_104;
    QPushButton *ETC_pushButton_RF_Get;
    QSpacerItem *horizontalSpacer_36;
    QLabel *ETC_label_RF_State;
    QSpacerItem *horizontalSpacer_34;
    QPushButton *ETC_pushButton_RF_Set;
    QGroupBox *groupBox_34;
    QHBoxLayout *horizontalLayout_108;
    QVBoxLayout *verticalLayout_47;
    QHBoxLayout *horizontalLayout_106;
    QLabel *label_40;
    QLineEdit *ETC_lineEdit_TxLv;
    QLabel *label_46;
    QHBoxLayout *horizontalLayout_107;
    QPushButton *ETC_pushButton_TxLv_Get;
    QSpacerItem *horizontalSpacer_37;
    QLabel *ETC_label_TxLv_State;
    QSpacerItem *horizontalSpacer_38;
    QPushButton *ETC_pushButton_TxLv_Set;
    QGroupBox *groupBox_32;
    QHBoxLayout *horizontalLayout_89;
    QLabel *label_42;
    QHBoxLayout *horizontalLayout_86;
    QLineEdit *ETC_lineEdit_RSSI;
    QLabel *label_44;
    QPushButton *ETC_pushButton_RSSI_Get;
    QGroupBox *groupBox_13;
    QHBoxLayout *horizontalLayout_52;
    QVBoxLayout *verticalLayout_25;
    QListWidget *ETC_listWidget_Card;
    QHBoxLayout *horizontalLayout_51;
    QPushButton *ETC_pushButton_Del_Look;
    QSpacerItem *horizontalSpacer_15;
    QPushButton *ETC_pushButton_one;
    QPushButton *ETC_pushButton_Look;
    QGroupBox *groupBox_14;
    QHBoxLayout *horizontalLayout_112;
    QVBoxLayout *verticalLayout_28;
    QVBoxLayout *verticalLayout_29;
    QGridLayout *gridLayout;
    QLabel *label_21;
    QComboBox *ETC_comboBox_Card_Num;
    QLabel *label_45;
    QComboBox *ETC_comboBox_Momery;
    QHBoxLayout *horizontalLayout_56;
    QLabel *label_22;
    QLineEdit *ETC_lineEdit_Start_Add;
    QLabel *label_23;
    QLineEdit *ETC_lineEdit_ReadLength;
    QVBoxLayout *verticalLayout_26;
    QHBoxLayout *horizontalLayout_55;
    QLabel *label_24;
    QSpacerItem *horizontalSpacer_19;
    QListWidget *ETC_listWidget_Data;
    QHBoxLayout *horizontalLayout_54;
    QPushButton *ETC_pushButton_Del_Data;
    QSpacerItem *horizontalSpacer_17;
    QLabel *ETC_label_Data_State;
    QSpacerItem *horizontalSpacer_18;
    QPushButton *ETC_pushButton_Read;
    QHBoxLayout *horizontalLayout_109;
    QLabel *label_47;
    QLineEdit *ETC_lineEdit_Write_Add;
    QLabel *label_48;
    QLineEdit *ETC_lineEdit_Write_Length;
    QHBoxLayout *horizontalLayout_53;
    QLineEdit *ETC_lineEdit_WriteData;
    QPushButton *ETC_pushButton_Write;
    QWidget *tab_4;
    QHBoxLayout *horizontalLayout_139;
    QVBoxLayout *verticalLayout_56;
    QHBoxLayout *horizontalLayout_136;
    QGroupBox *groupBox_37;
    QHBoxLayout *horizontalLayout_129;
    QVBoxLayout *verticalLayout_52;
    QHBoxLayout *horizontalLayout_127;
    QLabel *label_52;
    QLineEdit *ETC_lineEdit_A_Card_Num;
    QHBoxLayout *horizontalLayout_128;
    QLabel *label_53;
    QLineEdit *ETC_lineEdit_A_Balance;
    QGroupBox *groupBox_38;
    QHBoxLayout *horizontalLayout_132;
    QVBoxLayout *verticalLayout_53;
    QHBoxLayout *horizontalLayout_130;
    QLabel *label_54;
    QLineEdit *ETC_lineEdit_A_Up_Money;
    QHBoxLayout *horizontalLayout_131;
    QSpacerItem *horizontalSpacer_40;
    QPushButton *ETC_pushButton_A_Up_Money;
    QGroupBox *groupBox_39;
    QHBoxLayout *horizontalLayout_135;
    QVBoxLayout *verticalLayout_54;
    QHBoxLayout *horizontalLayout_134;
    QLabel *label_55;
    QLineEdit *ETC_lineEdit_A_Down_Money;
    QHBoxLayout *horizontalLayout_133;
    QSpacerItem *horizontalSpacer_41;
    QPushButton *ETC_pushButton_A_Down_Money;
    QGroupBox *groupBox_40;
    QHBoxLayout *horizontalLayout_138;
    QVBoxLayout *verticalLayout_55;
    QListWidget *ETC_listWidget_A_Data;
    QHBoxLayout *horizontalLayout_137;
    QSpacerItem *horizontalSpacer_42;
    QPushButton *ETC_pushButton_A_Del_Data;
    QWidget *tab_ETC_App;
    QHBoxLayout *horizontalLayout_75;
    QVBoxLayout *verticalLayout_60;
    QHBoxLayout *horizontalLayout_59;
    QGroupBox *groupBox_15;
    QHBoxLayout *horizontalLayout_58;
    QGridLayout *gridLayout_2;
    QLabel *label_25;
    QLineEdit *ETC_lineEdit_Mess_Money;
    QLineEdit *ETC_lineEdit_Mess_Card;
    QLabel *label_26;
    QGroupBox *groupBox_42;
    QHBoxLayout *horizontalLayout_47;
    QVBoxLayout *verticalLayout_36;
    QRadioButton *ETC_radioButton_App_Down;
    QRadioButton *ETC_radioButton_App_Up;
    QGroupBox *groupBox_18;
    QHBoxLayout *horizontalLayout_73;
    QVBoxLayout *verticalLayout_32;
    QHBoxLayout *horizontalLayout_69;
    QLabel *label_28;
    QLineEdit *ETC_lineEdit_Up_Money;
    QHBoxLayout *horizontalLayout_70;
    QSpacerItem *horizontalSpacer_24;
    QPushButton *ETC_pushButton_Up;
    QHBoxLayout *horizontalLayout_74;
    QGroupBox *groupBox_16;
    QHBoxLayout *horizontalLayout_62;
    QVBoxLayout *verticalLayout_30;
    QListWidget *ETC_listWidget_App_Data;
    QHBoxLayout *horizontalLayout_61;
    QPushButton *ETC_pushButton_B_Del_Uaer;
    QSpacerItem *horizontalSpacer_20;
    QPushButton *ETC_pushButton_APP_Del;
    QVBoxLayout *verticalLayout_35;
    QGroupBox *groupBox_17;
    QHBoxLayout *horizontalLayout_71;
    QVBoxLayout *verticalLayout_27;
    QHBoxLayout *horizontalLayout_63;
    QLabel *label_29;
    QLineEdit *ETC_lineEdit_Time_In;
    QHBoxLayout *horizontalLayout_64;
    QLabel *label_19;
    QLineEdit *ETC_lineEdit_Time_Out;
    QHBoxLayout *horizontalLayout_65;
    QLabel *label_31;
    QLineEdit *ETC_lineEdit_Time_Stop;
    QHBoxLayout *horizontalLayout_66;
    QLabel *label_33;
    QLineEdit *ETC_lineEdit_Money_Stop;
    QHBoxLayout *horizontalLayout_68;
    QLabel *label_27;
    QLineEdit *ETC_lineEdit_Money_Out;
    QHBoxLayout *horizontalLayout_67;
    QSpacerItem *horizontalSpacer_21;
    QPushButton *ETC_pushButton_Money_Save;
    QSpacerItem *verticalSpacer_3;
    QGroupBox *groupBox_19;
    QHBoxLayout *horizontalLayout_72;
    QVBoxLayout *verticalLayout_31;
    QPushButton *ETC_pushButton_ON;
    QPushButton *ETC_pushButton_OFF;
    QPushButton *ETC_pushButton_Open;
    QWidget *page_2;
    QHBoxLayout *horizontalLayout_76;
    QTabWidget *tabWidget_G;
    QWidget *tab_24G;
    QHBoxLayout *horizontalLayout_123;
    QVBoxLayout *verticalLayout_51;
    QHBoxLayout *horizontalLayout_122;
    QGroupBox *groupBox_43;
    QHBoxLayout *horizontalLayout_119;
    QHBoxLayout *horizontalLayout_114;
    QVBoxLayout *verticalLayout_33;
    QLabel *label_18;
    QLabel *label_56;
    QVBoxLayout *verticalLayout_49;
    QLineEdit *G_lineEdit_Mac;
    QHBoxLayout *horizontalLayout_49;
    QLineEdit *G_lineEdit_Panid;
    QLabel *label_57;
    QComboBox *G_comboBox_Channel;
    QVBoxLayout *verticalLayout_50;
    QPushButton *G_pushButton_Read;
    QPushButton *G_pushButton_Write;
    QSpacerItem *horizontalSpacer_23;
    QGroupBox *groupBox_44;
    QHBoxLayout *horizontalLayout_116;
    QVBoxLayout *verticalLayout_46;
    QHBoxLayout *horizontalLayout_143;
    QLabel *label_58;
    QComboBox *G_comboBox_Data_Num;
    QHBoxLayout *horizontalLayout_145;
    QLabel *label_59;
    QSpacerItem *horizontalSpacer_43;
    QListWidget *G_listWidget_Data;
    QHBoxLayout *horizontalLayout_77;
    QPushButton *G_pushButton_DelData;
    QSpacerItem *horizontalSpacer_22;
    QLabel *G_label_State;
    QSpacerItem *horizontalSpacer_39;
    QPushButton *G_pushButton_ReadData;
    QHBoxLayout *horizontalLayout_115;
    QLineEdit *G_lineEdit_WriteData;
    QPushButton *G_pushButton_WriteData;
    QWidget *tab_5;
    QHBoxLayout *horizontalLayout_151;
    QVBoxLayout *verticalLayout_68;
    QHBoxLayout *horizontalLayout_140;
    QGroupBox *groupBox_22;
    QHBoxLayout *horizontalLayout_125;
    QHBoxLayout *horizontalLayout_124;
    QVBoxLayout *verticalLayout_63;
    QLabel *label_43;
    QLabel *label_49;
    QVBoxLayout *verticalLayout_64;
    QLineEdit *G_lineEdit_ReadPanid;
    QComboBox *G_comboBox_ReadChannel;
    QVBoxLayout *verticalLayout_65;
    QPushButton *G_pushButton_ReadRead;
    QPushButton *G_pushButton_ReadWrite;
    QGroupBox *groupBox_45;
    QHBoxLayout *horizontalLayout_126;
    QLabel *label_39;
    QSpacerItem *horizontalSpacer_44;
    QHBoxLayout *horizontalLayout_150;
    QGroupBox *groupBox_35;
    QHBoxLayout *horizontalLayout_142;
    QVBoxLayout *verticalLayout_66;
    QListWidget *G_listWidget_Label;
    QHBoxLayout *horizontalLayout_141;
    QPushButton *G_pushButton_DelLabel;
    QSpacerItem *horizontalSpacer_45;
    QPushButton *G_pushButton_LookCard;
    QGroupBox *groupBox_36;
    QHBoxLayout *horizontalLayout_149;
    QVBoxLayout *verticalLayout_67;
    QHBoxLayout *horizontalLayout_146;
    QLabel *label_50;
    QComboBox *G_comboBox_Label;
    QLabel *label_60;
    QComboBox *G_comboBox_Data;
    QHBoxLayout *horizontalLayout_144;
    QLabel *label_61;
    QSpacerItem *horizontalSpacer_47;
    QListWidget *G_listWidget_Record;
    QHBoxLayout *horizontalLayout_147;
    QPushButton *G_pushButton_DelLabelData;
    QSpacerItem *horizontalSpacer_48;
    QLabel *G_label_LabelState;
    QSpacerItem *horizontalSpacer_46;
    QPushButton *G_pushButton_Readlabel;
    QHBoxLayout *horizontalLayout_148;
    QLineEdit *G_lineEdit_Write;
    QPushButton *G_pushButton_WriteLabel;
    QWidget *tab_24G_App;
    QHBoxLayout *horizontalLayout_121;
    QHBoxLayout *horizontalLayout_120;
    QGroupBox *groupBox_20;
    QHBoxLayout *horizontalLayout_118;
    QTableWidget *G_tableWidget_App_In;
    QGroupBox *groupBox_21;
    QHBoxLayout *horizontalLayout_117;
    QTableWidget *G_tableWidget_Storage;
    QPushButton *pushButton_IsShow;
    QGroupBox *Uart_Data;
    QHBoxLayout *horizontalLayout_16;
    QVBoxLayout *verticalLayout_5;
    QComboBox *comboBox_Show_Mode;
    QTextEdit *textEdit_Data;
    QHBoxLayout *horizontalLayout_15;
    QPushButton *pushButton_DelData;
    QPushButton *pushButton_Rec_Mode;
    QSpacerItem *horizontalSpacer_3;
    QLabel *label_Rec_Text;
    QLabel *label_Rec_Num;
    QLabel *label_Send_Text;
    QLabel *label_Send_Num;
    QPushButton *pushButton_DelNum;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1603, 766);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/icon/image/RFIDDemo.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout_19 = new QHBoxLayout(centralWidget);
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(0);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        label_20 = new QLabel(centralWidget);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_20->sizePolicy().hasHeightForWidth());
        label_20->setSizePolicy(sizePolicy);
        label_20->setMinimumSize(QSize(125, 100));
        label_20->setSizeIncrement(QSize(0, 0));
        label_20->setStyleSheet(QString::fromUtf8("border-image: url(:/new/icon/image/RFID-Logo_05.png);"));

        verticalLayout_8->addWidget(label_20);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setSizeConstraint(QLayout::SetFixedSize);
        pushButton_IDMode = new QPushButton(centralWidget);
        pushButton_IDMode->setObjectName(QString::fromUtf8("pushButton_IDMode"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton_IDMode->sizePolicy().hasHeightForWidth());
        pushButton_IDMode->setSizePolicy(sizePolicy1);
        pushButton_IDMode->setMinimumSize(QSize(125, 60));
        pushButton_IDMode->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"	\n"
"	selection-background-color: rgb(42, 42, 255);\n"
"}"));

        verticalLayout_7->addWidget(pushButton_IDMode);

        pushButton_ICMode = new QPushButton(centralWidget);
        pushButton_ICMode->setObjectName(QString::fromUtf8("pushButton_ICMode"));
        sizePolicy1.setHeightForWidth(pushButton_ICMode->sizePolicy().hasHeightForWidth());
        pushButton_ICMode->setSizePolicy(sizePolicy1);
        pushButton_ICMode->setMinimumSize(QSize(125, 60));

        verticalLayout_7->addWidget(pushButton_ICMode);

        pushButton_ETCMode = new QPushButton(centralWidget);
        pushButton_ETCMode->setObjectName(QString::fromUtf8("pushButton_ETCMode"));
        sizePolicy1.setHeightForWidth(pushButton_ETCMode->sizePolicy().hasHeightForWidth());
        pushButton_ETCMode->setSizePolicy(sizePolicy1);
        pushButton_ETCMode->setMinimumSize(QSize(125, 60));
        pushButton_ETCMode->setStyleSheet(QString::fromUtf8(""));
        pushButton_ETCMode->setAutoRepeat(false);
        pushButton_ETCMode->setAutoExclusive(false);

        verticalLayout_7->addWidget(pushButton_ETCMode);

        pushButton_ZigBeeMode = new QPushButton(centralWidget);
        pushButton_ZigBeeMode->setObjectName(QString::fromUtf8("pushButton_ZigBeeMode"));
        sizePolicy1.setHeightForWidth(pushButton_ZigBeeMode->sizePolicy().hasHeightForWidth());
        pushButton_ZigBeeMode->setSizePolicy(sizePolicy1);
        pushButton_ZigBeeMode->setMinimumSize(QSize(125, 60));

        verticalLayout_7->addWidget(pushButton_ZigBeeMode);

        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        sizePolicy1.setHeightForWidth(pushButton_3->sizePolicy().hasHeightForWidth());
        pushButton_3->setSizePolicy(sizePolicy1);
        pushButton_3->setMinimumSize(QSize(125, 60));

        verticalLayout_7->addWidget(pushButton_3);


        verticalLayout_8->addLayout(verticalLayout_7);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer);


        horizontalLayout_18->addLayout(verticalLayout_8);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setSizeConstraint(QLayout::SetFixedSize);
        horizontalSpacer_4 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_4);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        QSizePolicy sizePolicy2(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy2);
        horizontalLayout_6 = new QHBoxLayout(groupBox);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_Com = new QLabel(groupBox);
        label_Com->setObjectName(QString::fromUtf8("label_Com"));
        sizePolicy2.setHeightForWidth(label_Com->sizePolicy().hasHeightForWidth());
        label_Com->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(label_Com);

        comboBox_Com = new QComboBox(groupBox);
        comboBox_Com->setObjectName(QString::fromUtf8("comboBox_Com"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(comboBox_Com->sizePolicy().hasHeightForWidth());
        comboBox_Com->setSizePolicy(sizePolicy3);

        horizontalLayout->addWidget(comboBox_Com);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_Baud = new QLabel(groupBox);
        label_Baud->setObjectName(QString::fromUtf8("label_Baud"));
        sizePolicy2.setHeightForWidth(label_Baud->sizePolicy().hasHeightForWidth());
        label_Baud->setSizePolicy(sizePolicy2);

        horizontalLayout_2->addWidget(label_Baud);

        comboBox_Baud = new QComboBox(groupBox);
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->setObjectName(QString::fromUtf8("comboBox_Baud"));
        sizePolicy3.setHeightForWidth(comboBox_Baud->sizePolicy().hasHeightForWidth());
        comboBox_Baud->setSizePolicy(sizePolicy3);

        horizontalLayout_2->addWidget(comboBox_Baud);


        verticalLayout->addLayout(horizontalLayout_2);


        horizontalLayout_3->addLayout(verticalLayout);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        pushButton_Open = new QPushButton(groupBox);
        pushButton_Open->setObjectName(QString::fromUtf8("pushButton_Open"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(pushButton_Open->sizePolicy().hasHeightForWidth());
        pushButton_Open->setSizePolicy(sizePolicy4);

        verticalLayout_3->addWidget(pushButton_Open);


        horizontalLayout_3->addLayout(verticalLayout_3);


        horizontalLayout_6->addLayout(horizontalLayout_3);


        horizontalLayout_14->addWidget(groupBox);

        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        horizontalLayout_8 = new QHBoxLayout(groupBox_3);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        label_Time = new QLabel(groupBox_3);
        label_Time->setObjectName(QString::fromUtf8("label_Time"));

        horizontalLayout_4->addWidget(label_Time);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);


        horizontalLayout_8->addLayout(horizontalLayout_4);


        horizontalLayout_14->addWidget(groupBox_3);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_5);


        verticalLayout_6->addLayout(horizontalLayout_14);

        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setFrameShape(QFrame::NoFrame);
        page_ID = new QWidget();
        page_ID->setObjectName(QString::fromUtf8("page_ID"));
        horizontalLayout_17 = new QHBoxLayout(page_ID);
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        tabWidget_ID = new QTabWidget(page_ID);
        tabWidget_ID->setObjectName(QString::fromUtf8("tabWidget_ID"));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        horizontalLayout_84 = new QHBoxLayout(tab);
        horizontalLayout_84->setSpacing(6);
        horizontalLayout_84->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_84->setObjectName(QString::fromUtf8("horizontalLayout_84"));
        verticalLayout_34 = new QVBoxLayout();
        verticalLayout_34->setSpacing(6);
        verticalLayout_34->setObjectName(QString::fromUtf8("verticalLayout_34"));
        horizontalLayout_78 = new QHBoxLayout();
        horizontalLayout_78->setSpacing(6);
        horizontalLayout_78->setObjectName(QString::fromUtf8("horizontalLayout_78"));
        groupBox_23 = new QGroupBox(tab);
        groupBox_23->setObjectName(QString::fromUtf8("groupBox_23"));
        QSizePolicy sizePolicy5(QSizePolicy::Preferred, QSizePolicy::Maximum);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(groupBox_23->sizePolicy().hasHeightForWidth());
        groupBox_23->setSizePolicy(sizePolicy5);
        horizontalLayout_83 = new QHBoxLayout(groupBox_23);
        horizontalLayout_83->setSpacing(6);
        horizontalLayout_83->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_83->setObjectName(QString::fromUtf8("horizontalLayout_83"));
        verticalLayout_38 = new QVBoxLayout();
        verticalLayout_38->setSpacing(6);
        verticalLayout_38->setObjectName(QString::fromUtf8("verticalLayout_38"));
        ID_radioButton_EM4100 = new QRadioButton(groupBox_23);
        ID_radioButton_EM4100->setObjectName(QString::fromUtf8("ID_radioButton_EM4100"));
        ID_radioButton_EM4100->setChecked(true);

        verticalLayout_38->addWidget(ID_radioButton_EM4100);

        ID_radioButton_T5557 = new QRadioButton(groupBox_23);
        ID_radioButton_T5557->setObjectName(QString::fromUtf8("ID_radioButton_T5557"));

        verticalLayout_38->addWidget(ID_radioButton_T5557);


        horizontalLayout_83->addLayout(verticalLayout_38);


        horizontalLayout_78->addWidget(groupBox_23);

        groupBox_25 = new QGroupBox(tab);
        groupBox_25->setObjectName(QString::fromUtf8("groupBox_25"));
        horizontalLayout_85 = new QHBoxLayout(groupBox_25);
        horizontalLayout_85->setSpacing(6);
        horizontalLayout_85->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_85->setObjectName(QString::fromUtf8("horizontalLayout_85"));
        label_32 = new QLabel(groupBox_25);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        horizontalLayout_85->addWidget(label_32);


        horizontalLayout_78->addWidget(groupBox_25);

        horizontalSpacer_27 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_78->addItem(horizontalSpacer_27);


        verticalLayout_34->addLayout(horizontalLayout_78);

        groupBox_24 = new QGroupBox(tab);
        groupBox_24->setObjectName(QString::fromUtf8("groupBox_24"));
        horizontalLayout_82 = new QHBoxLayout(groupBox_24);
        horizontalLayout_82->setSpacing(6);
        horizontalLayout_82->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_82->setObjectName(QString::fromUtf8("horizontalLayout_82"));
        verticalLayout_37 = new QVBoxLayout();
        verticalLayout_37->setSpacing(6);
        verticalLayout_37->setObjectName(QString::fromUtf8("verticalLayout_37"));
        ID_listWidget_Card_Data = new QListWidget(groupBox_24);
        ID_listWidget_Card_Data->setObjectName(QString::fromUtf8("ID_listWidget_Card_Data"));
        ID_listWidget_Card_Data->setFocusPolicy(Qt::StrongFocus);

        verticalLayout_37->addWidget(ID_listWidget_Card_Data);

        horizontalLayout_80 = new QHBoxLayout();
        horizontalLayout_80->setSpacing(6);
        horizontalLayout_80->setObjectName(QString::fromUtf8("horizontalLayout_80"));
        ID_pushButton_Del = new QPushButton(groupBox_24);
        ID_pushButton_Del->setObjectName(QString::fromUtf8("ID_pushButton_Del"));

        horizontalLayout_80->addWidget(ID_pushButton_Del);

        horizontalSpacer_25 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_80->addItem(horizontalSpacer_25);

        ID_label_State = new QLabel(groupBox_24);
        ID_label_State->setObjectName(QString::fromUtf8("ID_label_State"));

        horizontalLayout_80->addWidget(ID_label_State);

        horizontalSpacer_26 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_80->addItem(horizontalSpacer_26);

        ID_pushButton_Read_Card = new QPushButton(groupBox_24);
        ID_pushButton_Read_Card->setObjectName(QString::fromUtf8("ID_pushButton_Read_Card"));

        horizontalLayout_80->addWidget(ID_pushButton_Read_Card);


        verticalLayout_37->addLayout(horizontalLayout_80);

        horizontalLayout_81 = new QHBoxLayout();
        horizontalLayout_81->setSpacing(6);
        horizontalLayout_81->setObjectName(QString::fromUtf8("horizontalLayout_81"));
        ID_lineEdit_Write = new QLineEdit(groupBox_24);
        ID_lineEdit_Write->setObjectName(QString::fromUtf8("ID_lineEdit_Write"));

        horizontalLayout_81->addWidget(ID_lineEdit_Write);

        ID_pushButton_Write_Card = new QPushButton(groupBox_24);
        ID_pushButton_Write_Card->setObjectName(QString::fromUtf8("ID_pushButton_Write_Card"));

        horizontalLayout_81->addWidget(ID_pushButton_Write_Card);


        verticalLayout_37->addLayout(horizontalLayout_81);


        horizontalLayout_82->addLayout(verticalLayout_37);


        verticalLayout_34->addWidget(groupBox_24);


        horizontalLayout_84->addLayout(verticalLayout_34);

        tabWidget_ID->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        horizontalLayout_79 = new QHBoxLayout(tab_2);
        horizontalLayout_79->setSpacing(6);
        horizontalLayout_79->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_79->setObjectName(QString::fromUtf8("horizontalLayout_79"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        groupBox_2 = new QGroupBox(tab_2);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        horizontalLayout_13 = new QHBoxLayout(groupBox_2);
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setSizeConstraint(QLayout::SetMaximumSize);
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        sizePolicy2.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy2);

        horizontalLayout_5->addWidget(label_2);

        ID_timeEdit_Morn_Up = new QTimeEdit(groupBox_2);
        ID_timeEdit_Morn_Up->setObjectName(QString::fromUtf8("ID_timeEdit_Morn_Up"));
        QSizePolicy sizePolicy6(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(ID_timeEdit_Morn_Up->sizePolicy().hasHeightForWidth());
        ID_timeEdit_Morn_Up->setSizePolicy(sizePolicy6);
        ID_timeEdit_Morn_Up->setDateTime(QDateTime(QDate(2000, 1, 1), QTime(8, 0, 0)));
        ID_timeEdit_Morn_Up->setMaximumTime(QTime(12, 0, 0));

        horizontalLayout_5->addWidget(ID_timeEdit_Morn_Up);

        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);

        horizontalLayout_5->addWidget(label);

        ID_timeEdit_Morn_Down = new QTimeEdit(groupBox_2);
        ID_timeEdit_Morn_Down->setObjectName(QString::fromUtf8("ID_timeEdit_Morn_Down"));
        sizePolicy6.setHeightForWidth(ID_timeEdit_Morn_Down->sizePolicy().hasHeightForWidth());
        ID_timeEdit_Morn_Down->setSizePolicy(sizePolicy6);
        ID_timeEdit_Morn_Down->setDateTime(QDateTime(QDate(2000, 1, 1), QTime(12, 0, 0)));
        ID_timeEdit_Morn_Down->setMaximumTime(QTime(12, 0, 0));

        horizontalLayout_5->addWidget(ID_timeEdit_Morn_Down);


        verticalLayout_2->addLayout(horizontalLayout_5);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setSizeConstraint(QLayout::SetMaximumSize);
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        sizePolicy2.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy2);

        horizontalLayout_7->addWidget(label_3);

        ID_timeEdit_Afte_Up = new QTimeEdit(groupBox_2);
        ID_timeEdit_Afte_Up->setObjectName(QString::fromUtf8("ID_timeEdit_Afte_Up"));
        sizePolicy6.setHeightForWidth(ID_timeEdit_Afte_Up->sizePolicy().hasHeightForWidth());
        ID_timeEdit_Afte_Up->setSizePolicy(sizePolicy6);
        ID_timeEdit_Afte_Up->setDateTime(QDateTime(QDate(2000, 1, 1), QTime(14, 0, 0)));
        ID_timeEdit_Afte_Up->setMinimumTime(QTime(12, 0, 0));

        horizontalLayout_7->addWidget(ID_timeEdit_Afte_Up);

        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        sizePolicy2.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy2);

        horizontalLayout_7->addWidget(label_4);

        ID_timeEdit_Afte_Down = new QTimeEdit(groupBox_2);
        ID_timeEdit_Afte_Down->setObjectName(QString::fromUtf8("ID_timeEdit_Afte_Down"));
        sizePolicy6.setHeightForWidth(ID_timeEdit_Afte_Down->sizePolicy().hasHeightForWidth());
        ID_timeEdit_Afte_Down->setSizePolicy(sizePolicy6);
        ID_timeEdit_Afte_Down->setDateTime(QDateTime(QDate(2000, 1, 1), QTime(18, 0, 0)));
        ID_timeEdit_Afte_Down->setMinimumTime(QTime(12, 0, 0));

        horizontalLayout_7->addWidget(ID_timeEdit_Afte_Down);


        verticalLayout_2->addLayout(horizontalLayout_7);


        horizontalLayout_9->addLayout(verticalLayout_2);

        ID_pushButton_Save = new QPushButton(groupBox_2);
        ID_pushButton_Save->setObjectName(QString::fromUtf8("ID_pushButton_Save"));
        QSizePolicy sizePolicy7(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(ID_pushButton_Save->sizePolicy().hasHeightForWidth());
        ID_pushButton_Save->setSizePolicy(sizePolicy7);

        horizontalLayout_9->addWidget(ID_pushButton_Save);


        horizontalLayout_13->addLayout(horizontalLayout_9);


        verticalLayout_4->addWidget(groupBox_2);

        groupBox_4 = new QGroupBox(tab_2);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        sizePolicy4.setHeightForWidth(groupBox_4->sizePolicy().hasHeightForWidth());
        groupBox_4->setSizePolicy(sizePolicy4);
        horizontalLayout_10 = new QHBoxLayout(groupBox_4);
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        ID_tableView_ID = new QTableView(groupBox_4);
        ID_tableView_ID->setObjectName(QString::fromUtf8("ID_tableView_ID"));
        QSizePolicy sizePolicy8(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy8.setHorizontalStretch(0);
        sizePolicy8.setVerticalStretch(0);
        sizePolicy8.setHeightForWidth(ID_tableView_ID->sizePolicy().hasHeightForWidth());
        ID_tableView_ID->setSizePolicy(sizePolicy8);

        horizontalLayout_10->addWidget(ID_tableView_ID);


        verticalLayout_4->addWidget(groupBox_4);


        horizontalLayout_12->addLayout(verticalLayout_4);

        groupBox_5 = new QGroupBox(tab_2);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        horizontalLayout_11 = new QHBoxLayout(groupBox_5);
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        ID_tableView_Data = new QTableView(groupBox_5);
        ID_tableView_Data->setObjectName(QString::fromUtf8("ID_tableView_Data"));
        sizePolicy8.setHeightForWidth(ID_tableView_Data->sizePolicy().hasHeightForWidth());
        ID_tableView_Data->setSizePolicy(sizePolicy8);

        horizontalLayout_11->addWidget(ID_tableView_Data);


        horizontalLayout_12->addWidget(groupBox_5);

        horizontalLayout_12->setStretch(0, 1);
        horizontalLayout_12->setStretch(1, 2);

        horizontalLayout_79->addLayout(horizontalLayout_12);

        tabWidget_ID->addTab(tab_2, QString());

        horizontalLayout_17->addWidget(tabWidget_ID);

        stackedWidget->addWidget(page_ID);
        page_IC = new QWidget();
        page_IC->setObjectName(QString::fromUtf8("page_IC"));
        horizontalLayout_39 = new QHBoxLayout(page_IC);
        horizontalLayout_39->setSpacing(6);
        horizontalLayout_39->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_39->setObjectName(QString::fromUtf8("horizontalLayout_39"));
        tabWidget_IC = new QTabWidget(page_IC);
        tabWidget_IC->setObjectName(QString::fromUtf8("tabWidget_IC"));
        tab_Basics = new QWidget();
        tab_Basics->setObjectName(QString::fromUtf8("tab_Basics"));
        horizontalLayout_45 = new QHBoxLayout(tab_Basics);
        horizontalLayout_45->setSpacing(6);
        horizontalLayout_45->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_45->setObjectName(QString::fromUtf8("horizontalLayout_45"));
        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setSpacing(6);
        horizontalLayout_44->setObjectName(QString::fromUtf8("horizontalLayout_44"));
        verticalLayout_24 = new QVBoxLayout();
        verticalLayout_24->setSpacing(6);
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        groupBox_10 = new QGroupBox(tab_Basics);
        groupBox_10->setObjectName(QString::fromUtf8("groupBox_10"));
        horizontalLayout_37 = new QHBoxLayout(groupBox_10);
        horizontalLayout_37->setSpacing(6);
        horizontalLayout_37->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_37->setObjectName(QString::fromUtf8("horizontalLayout_37"));
        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setSpacing(6);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setSpacing(0);
        horizontalLayout_35->setObjectName(QString::fromUtf8("horizontalLayout_35"));
        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setSpacing(6);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        label_51 = new QLabel(groupBox_10);
        label_51->setObjectName(QString::fromUtf8("label_51"));

        verticalLayout_19->addWidget(label_51);

        label_14 = new QLabel(groupBox_10);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        verticalLayout_19->addWidget(label_14);

        label_13 = new QLabel(groupBox_10);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        verticalLayout_19->addWidget(label_13);

        label_15 = new QLabel(groupBox_10);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        verticalLayout_19->addWidget(label_15);


        horizontalLayout_35->addLayout(verticalLayout_19);

        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setSpacing(6);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        IC_comboBox_Pass_Regic = new QComboBox(groupBox_10);
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->addItem(QString());
        IC_comboBox_Pass_Regic->setObjectName(QString::fromUtf8("IC_comboBox_Pass_Regic"));

        verticalLayout_18->addWidget(IC_comboBox_Pass_Regic);

        horizontalLayout_34 = new QHBoxLayout();
        horizontalLayout_34->setSpacing(6);
        horizontalLayout_34->setObjectName(QString::fromUtf8("horizontalLayout_34"));
        IC_radioButton_Pass_A = new QRadioButton(groupBox_10);
        IC_radioButton_Pass_A->setObjectName(QString::fromUtf8("IC_radioButton_Pass_A"));
        IC_radioButton_Pass_A->setCheckable(true);
        IC_radioButton_Pass_A->setChecked(true);

        horizontalLayout_34->addWidget(IC_radioButton_Pass_A);

        IC_radioButton_Pass_B = new QRadioButton(groupBox_10);
        IC_radioButton_Pass_B->setObjectName(QString::fromUtf8("IC_radioButton_Pass_B"));

        horizontalLayout_34->addWidget(IC_radioButton_Pass_B);


        verticalLayout_18->addLayout(horizontalLayout_34);

        IC_lineEdit_Pass_Last = new QLineEdit(groupBox_10);
        IC_lineEdit_Pass_Last->setObjectName(QString::fromUtf8("IC_lineEdit_Pass_Last"));

        verticalLayout_18->addWidget(IC_lineEdit_Pass_Last);

        IC_lineEdit_Pass_New = new QLineEdit(groupBox_10);
        IC_lineEdit_Pass_New->setObjectName(QString::fromUtf8("IC_lineEdit_Pass_New"));

        verticalLayout_18->addWidget(IC_lineEdit_Pass_New);


        horizontalLayout_35->addLayout(verticalLayout_18);


        verticalLayout_20->addLayout(horizontalLayout_35);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setSpacing(6);
        horizontalLayout_36->setObjectName(QString::fromUtf8("horizontalLayout_36"));
        IC_label_Pass_State = new QLabel(groupBox_10);
        IC_label_Pass_State->setObjectName(QString::fromUtf8("IC_label_Pass_State"));

        horizontalLayout_36->addWidget(IC_label_Pass_State);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_36->addItem(horizontalSpacer_12);

        IC_pushButton_Pass_Save = new QPushButton(groupBox_10);
        IC_pushButton_Pass_Save->setObjectName(QString::fromUtf8("IC_pushButton_Pass_Save"));

        horizontalLayout_36->addWidget(IC_pushButton_Pass_Save);


        verticalLayout_20->addLayout(horizontalLayout_36);


        horizontalLayout_37->addLayout(verticalLayout_20);


        verticalLayout_24->addWidget(groupBox_10);

        groupBox_12 = new QGroupBox(tab_Basics);
        groupBox_12->setObjectName(QString::fromUtf8("groupBox_12"));
        horizontalLayout_43 = new QHBoxLayout(groupBox_12);
        horizontalLayout_43->setSpacing(6);
        horizontalLayout_43->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_43->setObjectName(QString::fromUtf8("horizontalLayout_43"));
        verticalLayout_22 = new QVBoxLayout();
        verticalLayout_22->setSpacing(6);
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        IC_listWidget_Look_Data = new QListWidget(groupBox_12);
        IC_listWidget_Look_Data->setObjectName(QString::fromUtf8("IC_listWidget_Look_Data"));

        verticalLayout_22->addWidget(IC_listWidget_Look_Data);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setSpacing(6);
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        IC_pushButton_Look_Del = new QPushButton(groupBox_12);
        IC_pushButton_Look_Del->setObjectName(QString::fromUtf8("IC_pushButton_Look_Del"));

        horizontalLayout_27->addWidget(IC_pushButton_Look_Del);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_27->addItem(horizontalSpacer_14);

        IC_pushButton_one = new QPushButton(groupBox_12);
        IC_pushButton_one->setObjectName(QString::fromUtf8("IC_pushButton_one"));

        horizontalLayout_27->addWidget(IC_pushButton_one);

        IC_pushButton_Look_Bign = new QPushButton(groupBox_12);
        IC_pushButton_Look_Bign->setObjectName(QString::fromUtf8("IC_pushButton_Look_Bign"));

        horizontalLayout_27->addWidget(IC_pushButton_Look_Bign);


        verticalLayout_22->addLayout(horizontalLayout_27);


        horizontalLayout_43->addLayout(verticalLayout_22);


        verticalLayout_24->addWidget(groupBox_12);


        horizontalLayout_44->addLayout(verticalLayout_24);

        groupBox_9 = new QGroupBox(tab_Basics);
        groupBox_9->setObjectName(QString::fromUtf8("groupBox_9"));
        horizontalLayout_38 = new QHBoxLayout(groupBox_9);
        horizontalLayout_38->setSpacing(6);
        horizontalLayout_38->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_38->setObjectName(QString::fromUtf8("horizontalLayout_38"));
        verticalLayout_62 = new QVBoxLayout();
        verticalLayout_62->setSpacing(6);
        verticalLayout_62->setObjectName(QString::fromUtf8("verticalLayout_62"));
        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setSpacing(6);
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setSpacing(6);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        label_11 = new QLabel(groupBox_9);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        QSizePolicy sizePolicy9(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy9.setHorizontalStretch(0);
        sizePolicy9.setVerticalStretch(0);
        sizePolicy9.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy9);

        verticalLayout_21->addWidget(label_11);

        label_30 = new QLabel(groupBox_9);
        label_30->setObjectName(QString::fromUtf8("label_30"));

        verticalLayout_21->addWidget(label_30);


        horizontalLayout_30->addLayout(verticalLayout_21);

        verticalLayout_57 = new QVBoxLayout();
        verticalLayout_57->setSpacing(6);
        verticalLayout_57->setObjectName(QString::fromUtf8("verticalLayout_57"));
        IC_comboBox_Sys_Region = new QComboBox(groupBox_9);
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->addItem(QString());
        IC_comboBox_Sys_Region->setObjectName(QString::fromUtf8("IC_comboBox_Sys_Region"));
        IC_comboBox_Sys_Region->setMinimumContentsLength(0);

        verticalLayout_57->addWidget(IC_comboBox_Sys_Region);

        IC_comboBox_passMode = new QComboBox(groupBox_9);
        IC_comboBox_passMode->addItem(QString());
        IC_comboBox_passMode->addItem(QString());
        IC_comboBox_passMode->setObjectName(QString::fromUtf8("IC_comboBox_passMode"));

        verticalLayout_57->addWidget(IC_comboBox_passMode);


        horizontalLayout_30->addLayout(verticalLayout_57);

        verticalLayout_58 = new QVBoxLayout();
        verticalLayout_58->setSpacing(6);
        verticalLayout_58->setObjectName(QString::fromUtf8("verticalLayout_58"));
        label_12 = new QLabel(groupBox_9);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        sizePolicy2.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy2);

        verticalLayout_58->addWidget(label_12);

        label_16 = new QLabel(groupBox_9);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        verticalLayout_58->addWidget(label_16);


        horizontalLayout_30->addLayout(verticalLayout_58);

        verticalLayout_61 = new QVBoxLayout();
        verticalLayout_61->setSpacing(6);
        verticalLayout_61->setObjectName(QString::fromUtf8("verticalLayout_61"));
        IC_comboBox_Sys_Lump = new QComboBox(groupBox_9);
        IC_comboBox_Sys_Lump->addItem(QString());
        IC_comboBox_Sys_Lump->addItem(QString());
        IC_comboBox_Sys_Lump->addItem(QString());
        IC_comboBox_Sys_Lump->addItem(QString());
        IC_comboBox_Sys_Lump->setObjectName(QString::fromUtf8("IC_comboBox_Sys_Lump"));

        verticalLayout_61->addWidget(IC_comboBox_Sys_Lump);

        IC_lineEdit_Sys_Pass = new QLineEdit(groupBox_9);
        IC_lineEdit_Sys_Pass->setObjectName(QString::fromUtf8("IC_lineEdit_Sys_Pass"));

        verticalLayout_61->addWidget(IC_lineEdit_Sys_Pass);


        horizontalLayout_30->addLayout(verticalLayout_61);

        horizontalLayout_30->setStretch(1, 1);
        horizontalLayout_30->setStretch(3, 1);

        verticalLayout_62->addLayout(horizontalLayout_30);

        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setSpacing(6);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setSpacing(6);
        horizontalLayout_31->setObjectName(QString::fromUtf8("horizontalLayout_31"));
        label_10 = new QLabel(groupBox_9);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_31->addWidget(label_10);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_11);


        verticalLayout_17->addLayout(horizontalLayout_31);

        IC_listWidget_Sys_Data = new QListWidget(groupBox_9);
        IC_listWidget_Sys_Data->setObjectName(QString::fromUtf8("IC_listWidget_Sys_Data"));
        IC_listWidget_Sys_Data->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";"));

        verticalLayout_17->addWidget(IC_listWidget_Sys_Data);


        verticalLayout_62->addLayout(verticalLayout_17);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setSpacing(6);
        horizontalLayout_33->setObjectName(QString::fromUtf8("horizontalLayout_33"));
        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setSpacing(6);
        horizontalLayout_32->setObjectName(QString::fromUtf8("horizontalLayout_32"));
        IC_pushButton_Sys_Del = new QPushButton(groupBox_9);
        IC_pushButton_Sys_Del->setObjectName(QString::fromUtf8("IC_pushButton_Sys_Del"));

        horizontalLayout_32->addWidget(IC_pushButton_Sys_Del);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_10);

        IC_label_Data_State = new QLabel(groupBox_9);
        IC_label_Data_State->setObjectName(QString::fromUtf8("IC_label_Data_State"));

        horizontalLayout_32->addWidget(IC_label_Data_State);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_16);


        verticalLayout_16->addLayout(horizontalLayout_32);

        IC_lineEdit_Sys_Write = new QLineEdit(groupBox_9);
        IC_lineEdit_Sys_Write->setObjectName(QString::fromUtf8("IC_lineEdit_Sys_Write"));

        verticalLayout_16->addWidget(IC_lineEdit_Sys_Write);


        horizontalLayout_33->addLayout(verticalLayout_16);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        IC_pushButton_Sys_Read = new QPushButton(groupBox_9);
        IC_pushButton_Sys_Read->setObjectName(QString::fromUtf8("IC_pushButton_Sys_Read"));

        verticalLayout_15->addWidget(IC_pushButton_Sys_Read);

        IC_pushButton_Sys_Write = new QPushButton(groupBox_9);
        IC_pushButton_Sys_Write->setObjectName(QString::fromUtf8("IC_pushButton_Sys_Write"));

        verticalLayout_15->addWidget(IC_pushButton_Sys_Write);


        horizontalLayout_33->addLayout(verticalLayout_15);


        verticalLayout_62->addLayout(horizontalLayout_33);


        horizontalLayout_38->addLayout(verticalLayout_62);


        horizontalLayout_44->addWidget(groupBox_9);

        horizontalLayout_44->setStretch(0, 1);
        horizontalLayout_44->setStretch(1, 5);

        horizontalLayout_45->addLayout(horizontalLayout_44);

        tabWidget_IC->addTab(tab_Basics, QString());
        tab_App = new QWidget();
        tab_App->setObjectName(QString::fromUtf8("tab_App"));
        horizontalLayout_46 = new QHBoxLayout(tab_App);
        horizontalLayout_46->setSpacing(6);
        horizontalLayout_46->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_46->setObjectName(QString::fromUtf8("horizontalLayout_46"));
        verticalLayout_23 = new QVBoxLayout();
        verticalLayout_23->setSpacing(6);
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        groupBox_8 = new QGroupBox(tab_App);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        horizontalLayout_42 = new QHBoxLayout(groupBox_8);
        horizontalLayout_42->setSpacing(6);
        horizontalLayout_42->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_42->setObjectName(QString::fromUtf8("horizontalLayout_42"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(0);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        label_17 = new QLabel(groupBox_8);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout_9->addWidget(label_17);

        label_6 = new QLabel(groupBox_8);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_9->addWidget(label_6);

        label_7 = new QLabel(groupBox_8);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_9->addWidget(label_7);


        horizontalLayout_22->addLayout(verticalLayout_9);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        IC_lineEdit_Mess_Pass = new QLineEdit(groupBox_8);
        IC_lineEdit_Mess_Pass->setObjectName(QString::fromUtf8("IC_lineEdit_Mess_Pass"));

        horizontalLayout_21->addWidget(IC_lineEdit_Mess_Pass);

        IC_pushButton_Mess = new QPushButton(groupBox_8);
        IC_pushButton_Mess->setObjectName(QString::fromUtf8("IC_pushButton_Mess"));

        horizontalLayout_21->addWidget(IC_pushButton_Mess);


        verticalLayout_12->addLayout(horizontalLayout_21);

        IC_lineEdit_Mess_Num = new QLineEdit(groupBox_8);
        IC_lineEdit_Mess_Num->setObjectName(QString::fromUtf8("IC_lineEdit_Mess_Num"));
        IC_lineEdit_Mess_Num->setReadOnly(true);

        verticalLayout_12->addWidget(IC_lineEdit_Mess_Num);

        IC_lineEdit_Mess_Money = new QLineEdit(groupBox_8);
        IC_lineEdit_Mess_Money->setObjectName(QString::fromUtf8("IC_lineEdit_Mess_Money"));
        IC_lineEdit_Mess_Money->setReadOnly(true);

        verticalLayout_12->addWidget(IC_lineEdit_Mess_Money);


        horizontalLayout_22->addLayout(verticalLayout_12);


        horizontalLayout_42->addLayout(horizontalLayout_22);


        horizontalLayout_25->addWidget(groupBox_8);

        groupBox_6 = new QGroupBox(tab_App);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        horizontalLayout_26 = new QHBoxLayout(groupBox_6);
        horizontalLayout_26->setSpacing(6);
        horizontalLayout_26->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        label_8 = new QLabel(groupBox_6);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_23->addWidget(label_8);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_6);


        verticalLayout_10->addLayout(horizontalLayout_23);

        IC_lineEdit_Up_Money = new QLineEdit(groupBox_6);
        IC_lineEdit_Up_Money->setObjectName(QString::fromUtf8("IC_lineEdit_Up_Money"));

        verticalLayout_10->addWidget(IC_lineEdit_Up_Money);


        verticalLayout_11->addLayout(verticalLayout_10);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_24->addItem(horizontalSpacer_7);

        IC_pushButton_Up = new QPushButton(groupBox_6);
        IC_pushButton_Up->setObjectName(QString::fromUtf8("IC_pushButton_Up"));

        horizontalLayout_24->addWidget(IC_pushButton_Up);


        verticalLayout_11->addLayout(horizontalLayout_24);


        horizontalLayout_26->addLayout(verticalLayout_11);

        label_5 = new QLabel(groupBox_6);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_26->addWidget(label_5);


        horizontalLayout_25->addWidget(groupBox_6);

        groupBox_7 = new QGroupBox(tab_App);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        horizontalLayout_48 = new QHBoxLayout(groupBox_7);
        horizontalLayout_48->setSpacing(6);
        horizontalLayout_48->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_48->setObjectName(QString::fromUtf8("horizontalLayout_48"));
        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setSpacing(6);
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        label_9 = new QLabel(groupBox_7);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_28->addWidget(label_9);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_28->addItem(horizontalSpacer_9);


        verticalLayout_14->addLayout(horizontalLayout_28);

        IC_lineEdit_Down_Money = new QLineEdit(groupBox_7);
        IC_lineEdit_Down_Money->setObjectName(QString::fromUtf8("IC_lineEdit_Down_Money"));

        verticalLayout_14->addWidget(IC_lineEdit_Down_Money);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setSpacing(6);
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_29->addItem(horizontalSpacer_8);

        IC_pushButton_Down = new QPushButton(groupBox_7);
        IC_pushButton_Down->setObjectName(QString::fromUtf8("IC_pushButton_Down"));

        horizontalLayout_29->addWidget(IC_pushButton_Down);


        verticalLayout_14->addLayout(horizontalLayout_29);


        horizontalLayout_48->addLayout(verticalLayout_14);


        horizontalLayout_25->addWidget(groupBox_7);


        verticalLayout_23->addLayout(horizontalLayout_25);

        groupBox_11 = new QGroupBox(tab_App);
        groupBox_11->setObjectName(QString::fromUtf8("groupBox_11"));
        horizontalLayout_41 = new QHBoxLayout(groupBox_11);
        horizontalLayout_41->setSpacing(6);
        horizontalLayout_41->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_41->setObjectName(QString::fromUtf8("horizontalLayout_41"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        IC_listWidget_Data = new QListWidget(groupBox_11);
        IC_listWidget_Data->setObjectName(QString::fromUtf8("IC_listWidget_Data"));

        verticalLayout_13->addWidget(IC_listWidget_Data);

        horizontalLayout_40 = new QHBoxLayout();
        horizontalLayout_40->setSpacing(6);
        horizontalLayout_40->setObjectName(QString::fromUtf8("horizontalLayout_40"));
        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_40->addItem(horizontalSpacer_13);

        IC_pushButton_Data_Del = new QPushButton(groupBox_11);
        IC_pushButton_Data_Del->setObjectName(QString::fromUtf8("IC_pushButton_Data_Del"));

        horizontalLayout_40->addWidget(IC_pushButton_Data_Del);


        verticalLayout_13->addLayout(horizontalLayout_40);


        horizontalLayout_41->addLayout(verticalLayout_13);


        verticalLayout_23->addWidget(groupBox_11);


        horizontalLayout_46->addLayout(verticalLayout_23);

        tabWidget_IC->addTab(tab_App, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        horizontalLayout_110 = new QHBoxLayout(tab_3);
        horizontalLayout_110->setSpacing(6);
        horizontalLayout_110->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_110->setObjectName(QString::fromUtf8("horizontalLayout_110"));
        horizontalLayout_101 = new QHBoxLayout();
        horizontalLayout_101->setSpacing(6);
        horizontalLayout_101->setObjectName(QString::fromUtf8("horizontalLayout_101"));
        verticalLayout_59 = new QVBoxLayout();
        verticalLayout_59->setSpacing(6);
        verticalLayout_59->setObjectName(QString::fromUtf8("verticalLayout_59"));
        groupBox_26 = new QGroupBox(tab_3);
        groupBox_26->setObjectName(QString::fromUtf8("groupBox_26"));
        horizontalLayout_100 = new QHBoxLayout(groupBox_26);
        horizontalLayout_100->setSpacing(6);
        horizontalLayout_100->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_100->setObjectName(QString::fromUtf8("horizontalLayout_100"));
        horizontalLayout_87 = new QHBoxLayout();
        horizontalLayout_87->setSpacing(0);
        horizontalLayout_87->setObjectName(QString::fromUtf8("horizontalLayout_87"));
        verticalLayout_39 = new QVBoxLayout();
        verticalLayout_39->setSpacing(6);
        verticalLayout_39->setObjectName(QString::fromUtf8("verticalLayout_39"));
        label_34 = new QLabel(groupBox_26);
        label_34->setObjectName(QString::fromUtf8("label_34"));

        verticalLayout_39->addWidget(label_34);

        label_35 = new QLabel(groupBox_26);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        verticalLayout_39->addWidget(label_35);

        IC_label_Pass_Text = new QLabel(groupBox_26);
        IC_label_Pass_Text->setObjectName(QString::fromUtf8("IC_label_Pass_Text"));

        verticalLayout_39->addWidget(IC_label_Pass_Text);


        horizontalLayout_87->addLayout(verticalLayout_39);

        verticalLayout_43 = new QVBoxLayout();
        verticalLayout_43->setSpacing(6);
        verticalLayout_43->setObjectName(QString::fromUtf8("verticalLayout_43"));
        IC_lineEdit_App_Card_Num = new QLineEdit(groupBox_26);
        IC_lineEdit_App_Card_Num->setObjectName(QString::fromUtf8("IC_lineEdit_App_Card_Num"));
        IC_lineEdit_App_Card_Num->setReadOnly(true);

        verticalLayout_43->addWidget(IC_lineEdit_App_Card_Num);

        IC_lineEdit_App_Balance = new QLineEdit(groupBox_26);
        IC_lineEdit_App_Balance->setObjectName(QString::fromUtf8("IC_lineEdit_App_Balance"));
        IC_lineEdit_App_Balance->setReadOnly(true);

        verticalLayout_43->addWidget(IC_lineEdit_App_Balance);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setSpacing(0);
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));
        IC_lineEdit_Pass = new QLineEdit(groupBox_26);
        IC_lineEdit_Pass->setObjectName(QString::fromUtf8("IC_lineEdit_Pass"));

        horizontalLayout_20->addWidget(IC_lineEdit_Pass);

        IC_pushButton_Pass_oK = new QPushButton(groupBox_26);
        IC_pushButton_Pass_oK->setObjectName(QString::fromUtf8("IC_pushButton_Pass_oK"));
        sizePolicy.setHeightForWidth(IC_pushButton_Pass_oK->sizePolicy().hasHeightForWidth());
        IC_pushButton_Pass_oK->setSizePolicy(sizePolicy);
        IC_pushButton_Pass_oK->setMinimumSize(QSize(30, 0));

        horizontalLayout_20->addWidget(IC_pushButton_Pass_oK);


        verticalLayout_43->addLayout(horizontalLayout_20);


        horizontalLayout_87->addLayout(verticalLayout_43);


        horizontalLayout_100->addLayout(horizontalLayout_87);


        verticalLayout_59->addWidget(groupBox_26);

        groupBox_41 = new QGroupBox(tab_3);
        groupBox_41->setObjectName(QString::fromUtf8("groupBox_41"));
        horizontalLayout_99 = new QHBoxLayout(groupBox_41);
        horizontalLayout_99->setSpacing(6);
        horizontalLayout_99->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_99->setObjectName(QString::fromUtf8("horizontalLayout_99"));
        horizontalLayout_88 = new QHBoxLayout();
        horizontalLayout_88->setSpacing(6);
        horizontalLayout_88->setObjectName(QString::fromUtf8("horizontalLayout_88"));
        IC_radioButton_Out = new QRadioButton(groupBox_41);
        IC_radioButton_Out->setObjectName(QString::fromUtf8("IC_radioButton_Out"));
        IC_radioButton_Out->setChecked(true);

        horizontalLayout_88->addWidget(IC_radioButton_Out);

        IC_radioButton_In = new QRadioButton(groupBox_41);
        IC_radioButton_In->setObjectName(QString::fromUtf8("IC_radioButton_In"));

        horizontalLayout_88->addWidget(IC_radioButton_In);


        horizontalLayout_99->addLayout(horizontalLayout_88);


        verticalLayout_59->addWidget(groupBox_41);

        groupBox_28 = new QGroupBox(tab_3);
        groupBox_28->setObjectName(QString::fromUtf8("groupBox_28"));
        horizontalLayout_95 = new QHBoxLayout(groupBox_28);
        horizontalLayout_95->setSpacing(6);
        horizontalLayout_95->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_95->setObjectName(QString::fromUtf8("horizontalLayout_95"));
        verticalLayout_41 = new QVBoxLayout();
        verticalLayout_41->setSpacing(6);
        verticalLayout_41->setObjectName(QString::fromUtf8("verticalLayout_41"));
        horizontalLayout_94 = new QHBoxLayout();
        horizontalLayout_94->setSpacing(6);
        horizontalLayout_94->setObjectName(QString::fromUtf8("horizontalLayout_94"));
        label_38 = new QLabel(groupBox_28);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        horizontalLayout_94->addWidget(label_38);

        horizontalSpacer_30 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_94->addItem(horizontalSpacer_30);


        verticalLayout_41->addLayout(horizontalLayout_94);

        IC_lineEdit_App_Ticket = new QLineEdit(groupBox_28);
        IC_lineEdit_App_Ticket->setObjectName(QString::fromUtf8("IC_lineEdit_App_Ticket"));

        verticalLayout_41->addWidget(IC_lineEdit_App_Ticket);

        horizontalLayout_93 = new QHBoxLayout();
        horizontalLayout_93->setSpacing(6);
        horizontalLayout_93->setObjectName(QString::fromUtf8("horizontalLayout_93"));
        horizontalSpacer_31 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_93->addItem(horizontalSpacer_31);

        IC_pushButton_App_Ticket = new QPushButton(groupBox_28);
        IC_pushButton_App_Ticket->setObjectName(QString::fromUtf8("IC_pushButton_App_Ticket"));

        horizontalLayout_93->addWidget(IC_pushButton_App_Ticket);


        verticalLayout_41->addLayout(horizontalLayout_93);


        horizontalLayout_95->addLayout(verticalLayout_41);


        verticalLayout_59->addWidget(groupBox_28);

        groupBox_27 = new QGroupBox(tab_3);
        groupBox_27->setObjectName(QString::fromUtf8("groupBox_27"));
        horizontalLayout_92 = new QHBoxLayout(groupBox_27);
        horizontalLayout_92->setSpacing(6);
        horizontalLayout_92->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_92->setObjectName(QString::fromUtf8("horizontalLayout_92"));
        verticalLayout_40 = new QVBoxLayout();
        verticalLayout_40->setSpacing(6);
        verticalLayout_40->setObjectName(QString::fromUtf8("verticalLayout_40"));
        horizontalLayout_91 = new QHBoxLayout();
        horizontalLayout_91->setSpacing(6);
        horizontalLayout_91->setObjectName(QString::fromUtf8("horizontalLayout_91"));
        label_37 = new QLabel(groupBox_27);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        horizontalLayout_91->addWidget(label_37);

        horizontalSpacer_28 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_91->addItem(horizontalSpacer_28);


        verticalLayout_40->addLayout(horizontalLayout_91);

        IC_lineEdit_App_Up_Money = new QLineEdit(groupBox_27);
        IC_lineEdit_App_Up_Money->setObjectName(QString::fromUtf8("IC_lineEdit_App_Up_Money"));

        verticalLayout_40->addWidget(IC_lineEdit_App_Up_Money);

        horizontalLayout_90 = new QHBoxLayout();
        horizontalLayout_90->setSpacing(6);
        horizontalLayout_90->setObjectName(QString::fromUtf8("horizontalLayout_90"));
        horizontalSpacer_29 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_90->addItem(horizontalSpacer_29);

        IC_pushButton_App_Up_Money = new QPushButton(groupBox_27);
        IC_pushButton_App_Up_Money->setObjectName(QString::fromUtf8("IC_pushButton_App_Up_Money"));

        horizontalLayout_90->addWidget(IC_pushButton_App_Up_Money);


        verticalLayout_40->addLayout(horizontalLayout_90);


        horizontalLayout_92->addLayout(verticalLayout_40);


        verticalLayout_59->addWidget(groupBox_27);

        groupBox_29 = new QGroupBox(tab_3);
        groupBox_29->setObjectName(QString::fromUtf8("groupBox_29"));
        groupBox_29->setFlat(false);
        groupBox_29->setCheckable(false);
        horizontalLayout_98 = new QHBoxLayout(groupBox_29);
        horizontalLayout_98->setSpacing(6);
        horizontalLayout_98->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_98->setObjectName(QString::fromUtf8("horizontalLayout_98"));
        IC_label_Head_Money = new QLabel(groupBox_29);
        IC_label_Head_Money->setObjectName(QString::fromUtf8("IC_label_Head_Money"));

        horizontalLayout_98->addWidget(IC_label_Head_Money);


        verticalLayout_59->addWidget(groupBox_29);

        verticalSpacer_4 = new QSpacerItem(17, 31, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_59->addItem(verticalSpacer_4);


        horizontalLayout_101->addLayout(verticalLayout_59);

        groupBox_30 = new QGroupBox(tab_3);
        groupBox_30->setObjectName(QString::fromUtf8("groupBox_30"));
        horizontalLayout_97 = new QHBoxLayout(groupBox_30);
        horizontalLayout_97->setSpacing(6);
        horizontalLayout_97->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_97->setObjectName(QString::fromUtf8("horizontalLayout_97"));
        verticalLayout_42 = new QVBoxLayout();
        verticalLayout_42->setSpacing(6);
        verticalLayout_42->setObjectName(QString::fromUtf8("verticalLayout_42"));
        IC_listWidget_App_Data = new QListWidget(groupBox_30);
        IC_listWidget_App_Data->setObjectName(QString::fromUtf8("IC_listWidget_App_Data"));

        verticalLayout_42->addWidget(IC_listWidget_App_Data);

        horizontalLayout_96 = new QHBoxLayout();
        horizontalLayout_96->setSpacing(6);
        horizontalLayout_96->setObjectName(QString::fromUtf8("horizontalLayout_96"));
        IC_pushButton_Ticket_Reset = new QPushButton(groupBox_30);
        IC_pushButton_Ticket_Reset->setObjectName(QString::fromUtf8("IC_pushButton_Ticket_Reset"));

        horizontalLayout_96->addWidget(IC_pushButton_Ticket_Reset);

        horizontalSpacer_32 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_96->addItem(horizontalSpacer_32);

        IC_pushButton_App_Del_Data = new QPushButton(groupBox_30);
        IC_pushButton_App_Del_Data->setObjectName(QString::fromUtf8("IC_pushButton_App_Del_Data"));

        horizontalLayout_96->addWidget(IC_pushButton_App_Del_Data);


        verticalLayout_42->addLayout(horizontalLayout_96);


        horizontalLayout_97->addLayout(verticalLayout_42);


        horizontalLayout_101->addWidget(groupBox_30);

        horizontalLayout_101->setStretch(0, 2);
        horizontalLayout_101->setStretch(1, 5);

        horizontalLayout_110->addLayout(horizontalLayout_101);

        tabWidget_IC->addTab(tab_3, QString());

        horizontalLayout_39->addWidget(tabWidget_IC);

        stackedWidget->addWidget(page_IC);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        horizontalLayout_50 = new QHBoxLayout(page);
        horizontalLayout_50->setSpacing(6);
        horizontalLayout_50->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_50->setObjectName(QString::fromUtf8("horizontalLayout_50"));
        tabWidget_ETC = new QTabWidget(page);
        tabWidget_ETC->setObjectName(QString::fromUtf8("tabWidget_ETC"));
        tab_ETC_Basics = new QWidget();
        tab_ETC_Basics->setObjectName(QString::fromUtf8("tab_ETC_Basics"));
        horizontalLayout_113 = new QHBoxLayout(tab_ETC_Basics);
        horizontalLayout_113->setSpacing(6);
        horizontalLayout_113->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_113->setObjectName(QString::fromUtf8("horizontalLayout_113"));
        horizontalLayout_111 = new QHBoxLayout();
        horizontalLayout_111->setSpacing(6);
        horizontalLayout_111->setObjectName(QString::fromUtf8("horizontalLayout_111"));
        verticalLayout_48 = new QVBoxLayout();
        verticalLayout_48->setSpacing(6);
        verticalLayout_48->setObjectName(QString::fromUtf8("verticalLayout_48"));
        groupBox_31 = new QGroupBox(tab_ETC_Basics);
        groupBox_31->setObjectName(QString::fromUtf8("groupBox_31"));
        horizontalLayout_102 = new QHBoxLayout(groupBox_31);
        horizontalLayout_102->setSpacing(6);
        horizontalLayout_102->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_102->setObjectName(QString::fromUtf8("horizontalLayout_102"));
        verticalLayout_44 = new QVBoxLayout();
        verticalLayout_44->setSpacing(6);
        verticalLayout_44->setObjectName(QString::fromUtf8("verticalLayout_44"));
        horizontalLayout_57 = new QHBoxLayout();
        horizontalLayout_57->setSpacing(6);
        horizontalLayout_57->setObjectName(QString::fromUtf8("horizontalLayout_57"));
        label_36 = new QLabel(groupBox_31);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        sizePolicy2.setHeightForWidth(label_36->sizePolicy().hasHeightForWidth());
        label_36->setSizePolicy(sizePolicy2);

        horizontalLayout_57->addWidget(label_36);

        ETC_comboBox_Region = new QComboBox(groupBox_31);
        ETC_comboBox_Region->addItem(QString());
        ETC_comboBox_Region->addItem(QString());
        ETC_comboBox_Region->addItem(QString());
        ETC_comboBox_Region->addItem(QString());
        ETC_comboBox_Region->addItem(QString());
        ETC_comboBox_Region->addItem(QString());
        ETC_comboBox_Region->addItem(QString());
        ETC_comboBox_Region->setObjectName(QString::fromUtf8("ETC_comboBox_Region"));

        horizontalLayout_57->addWidget(ETC_comboBox_Region);


        verticalLayout_44->addLayout(horizontalLayout_57);

        horizontalLayout_60 = new QHBoxLayout();
        horizontalLayout_60->setSpacing(6);
        horizontalLayout_60->setObjectName(QString::fromUtf8("horizontalLayout_60"));
        ETC_pushButton_Region_Get = new QPushButton(groupBox_31);
        ETC_pushButton_Region_Get->setObjectName(QString::fromUtf8("ETC_pushButton_Region_Get"));

        horizontalLayout_60->addWidget(ETC_pushButton_Region_Get);

        horizontalSpacer_33 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_60->addItem(horizontalSpacer_33);

        ETC_label_Region_State = new QLabel(groupBox_31);
        ETC_label_Region_State->setObjectName(QString::fromUtf8("ETC_label_Region_State"));

        horizontalLayout_60->addWidget(ETC_label_Region_State);

        horizontalSpacer_35 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_60->addItem(horizontalSpacer_35);

        ETC_pushButton_Region_Set = new QPushButton(groupBox_31);
        ETC_pushButton_Region_Set->setObjectName(QString::fromUtf8("ETC_pushButton_Region_Set"));

        horizontalLayout_60->addWidget(ETC_pushButton_Region_Set);


        verticalLayout_44->addLayout(horizontalLayout_60);


        horizontalLayout_102->addLayout(verticalLayout_44);


        verticalLayout_48->addWidget(groupBox_31);

        groupBox_33 = new QGroupBox(tab_ETC_Basics);
        groupBox_33->setObjectName(QString::fromUtf8("groupBox_33"));
        horizontalLayout_105 = new QHBoxLayout(groupBox_33);
        horizontalLayout_105->setSpacing(6);
        horizontalLayout_105->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_105->setObjectName(QString::fromUtf8("horizontalLayout_105"));
        verticalLayout_45 = new QVBoxLayout();
        verticalLayout_45->setSpacing(6);
        verticalLayout_45->setObjectName(QString::fromUtf8("verticalLayout_45"));
        horizontalLayout_103 = new QHBoxLayout();
        horizontalLayout_103->setSpacing(6);
        horizontalLayout_103->setObjectName(QString::fromUtf8("horizontalLayout_103"));
        label_41 = new QLabel(groupBox_33);
        label_41->setObjectName(QString::fromUtf8("label_41"));
        sizePolicy2.setHeightForWidth(label_41->sizePolicy().hasHeightForWidth());
        label_41->setSizePolicy(sizePolicy2);

        horizontalLayout_103->addWidget(label_41);

        ETC_comboBox_RF = new QComboBox(groupBox_33);
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->addItem(QString());
        ETC_comboBox_RF->setObjectName(QString::fromUtf8("ETC_comboBox_RF"));

        horizontalLayout_103->addWidget(ETC_comboBox_RF);


        verticalLayout_45->addLayout(horizontalLayout_103);

        horizontalLayout_104 = new QHBoxLayout();
        horizontalLayout_104->setSpacing(6);
        horizontalLayout_104->setObjectName(QString::fromUtf8("horizontalLayout_104"));
        ETC_pushButton_RF_Get = new QPushButton(groupBox_33);
        ETC_pushButton_RF_Get->setObjectName(QString::fromUtf8("ETC_pushButton_RF_Get"));

        horizontalLayout_104->addWidget(ETC_pushButton_RF_Get);

        horizontalSpacer_36 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_104->addItem(horizontalSpacer_36);

        ETC_label_RF_State = new QLabel(groupBox_33);
        ETC_label_RF_State->setObjectName(QString::fromUtf8("ETC_label_RF_State"));

        horizontalLayout_104->addWidget(ETC_label_RF_State);

        horizontalSpacer_34 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_104->addItem(horizontalSpacer_34);

        ETC_pushButton_RF_Set = new QPushButton(groupBox_33);
        ETC_pushButton_RF_Set->setObjectName(QString::fromUtf8("ETC_pushButton_RF_Set"));

        horizontalLayout_104->addWidget(ETC_pushButton_RF_Set);


        verticalLayout_45->addLayout(horizontalLayout_104);


        horizontalLayout_105->addLayout(verticalLayout_45);


        verticalLayout_48->addWidget(groupBox_33);

        groupBox_34 = new QGroupBox(tab_ETC_Basics);
        groupBox_34->setObjectName(QString::fromUtf8("groupBox_34"));
        horizontalLayout_108 = new QHBoxLayout(groupBox_34);
        horizontalLayout_108->setSpacing(6);
        horizontalLayout_108->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_108->setObjectName(QString::fromUtf8("horizontalLayout_108"));
        verticalLayout_47 = new QVBoxLayout();
        verticalLayout_47->setSpacing(6);
        verticalLayout_47->setObjectName(QString::fromUtf8("verticalLayout_47"));
        horizontalLayout_106 = new QHBoxLayout();
        horizontalLayout_106->setSpacing(6);
        horizontalLayout_106->setObjectName(QString::fromUtf8("horizontalLayout_106"));
        label_40 = new QLabel(groupBox_34);
        label_40->setObjectName(QString::fromUtf8("label_40"));

        horizontalLayout_106->addWidget(label_40);

        ETC_lineEdit_TxLv = new QLineEdit(groupBox_34);
        ETC_lineEdit_TxLv->setObjectName(QString::fromUtf8("ETC_lineEdit_TxLv"));

        horizontalLayout_106->addWidget(ETC_lineEdit_TxLv);

        label_46 = new QLabel(groupBox_34);
        label_46->setObjectName(QString::fromUtf8("label_46"));

        horizontalLayout_106->addWidget(label_46);


        verticalLayout_47->addLayout(horizontalLayout_106);

        horizontalLayout_107 = new QHBoxLayout();
        horizontalLayout_107->setSpacing(6);
        horizontalLayout_107->setObjectName(QString::fromUtf8("horizontalLayout_107"));
        ETC_pushButton_TxLv_Get = new QPushButton(groupBox_34);
        ETC_pushButton_TxLv_Get->setObjectName(QString::fromUtf8("ETC_pushButton_TxLv_Get"));

        horizontalLayout_107->addWidget(ETC_pushButton_TxLv_Get);

        horizontalSpacer_37 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_107->addItem(horizontalSpacer_37);

        ETC_label_TxLv_State = new QLabel(groupBox_34);
        ETC_label_TxLv_State->setObjectName(QString::fromUtf8("ETC_label_TxLv_State"));

        horizontalLayout_107->addWidget(ETC_label_TxLv_State);

        horizontalSpacer_38 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_107->addItem(horizontalSpacer_38);

        ETC_pushButton_TxLv_Set = new QPushButton(groupBox_34);
        ETC_pushButton_TxLv_Set->setObjectName(QString::fromUtf8("ETC_pushButton_TxLv_Set"));

        horizontalLayout_107->addWidget(ETC_pushButton_TxLv_Set);


        verticalLayout_47->addLayout(horizontalLayout_107);


        horizontalLayout_108->addLayout(verticalLayout_47);


        verticalLayout_48->addWidget(groupBox_34);

        groupBox_32 = new QGroupBox(tab_ETC_Basics);
        groupBox_32->setObjectName(QString::fromUtf8("groupBox_32"));
        horizontalLayout_89 = new QHBoxLayout(groupBox_32);
        horizontalLayout_89->setSpacing(6);
        horizontalLayout_89->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_89->setObjectName(QString::fromUtf8("horizontalLayout_89"));
        label_42 = new QLabel(groupBox_32);
        label_42->setObjectName(QString::fromUtf8("label_42"));

        horizontalLayout_89->addWidget(label_42);

        horizontalLayout_86 = new QHBoxLayout();
        horizontalLayout_86->setSpacing(6);
        horizontalLayout_86->setObjectName(QString::fromUtf8("horizontalLayout_86"));
        ETC_lineEdit_RSSI = new QLineEdit(groupBox_32);
        ETC_lineEdit_RSSI->setObjectName(QString::fromUtf8("ETC_lineEdit_RSSI"));
        ETC_lineEdit_RSSI->setReadOnly(true);

        horizontalLayout_86->addWidget(ETC_lineEdit_RSSI);

        label_44 = new QLabel(groupBox_32);
        label_44->setObjectName(QString::fromUtf8("label_44"));

        horizontalLayout_86->addWidget(label_44);


        horizontalLayout_89->addLayout(horizontalLayout_86);

        ETC_pushButton_RSSI_Get = new QPushButton(groupBox_32);
        ETC_pushButton_RSSI_Get->setObjectName(QString::fromUtf8("ETC_pushButton_RSSI_Get"));

        horizontalLayout_89->addWidget(ETC_pushButton_RSSI_Get);


        verticalLayout_48->addWidget(groupBox_32);

        groupBox_13 = new QGroupBox(tab_ETC_Basics);
        groupBox_13->setObjectName(QString::fromUtf8("groupBox_13"));
        horizontalLayout_52 = new QHBoxLayout(groupBox_13);
        horizontalLayout_52->setSpacing(6);
        horizontalLayout_52->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_52->setObjectName(QString::fromUtf8("horizontalLayout_52"));
        verticalLayout_25 = new QVBoxLayout();
        verticalLayout_25->setSpacing(6);
        verticalLayout_25->setObjectName(QString::fromUtf8("verticalLayout_25"));
        ETC_listWidget_Card = new QListWidget(groupBox_13);
        ETC_listWidget_Card->setObjectName(QString::fromUtf8("ETC_listWidget_Card"));

        verticalLayout_25->addWidget(ETC_listWidget_Card);

        horizontalLayout_51 = new QHBoxLayout();
        horizontalLayout_51->setSpacing(6);
        horizontalLayout_51->setObjectName(QString::fromUtf8("horizontalLayout_51"));
        ETC_pushButton_Del_Look = new QPushButton(groupBox_13);
        ETC_pushButton_Del_Look->setObjectName(QString::fromUtf8("ETC_pushButton_Del_Look"));

        horizontalLayout_51->addWidget(ETC_pushButton_Del_Look);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_51->addItem(horizontalSpacer_15);

        ETC_pushButton_one = new QPushButton(groupBox_13);
        ETC_pushButton_one->setObjectName(QString::fromUtf8("ETC_pushButton_one"));

        horizontalLayout_51->addWidget(ETC_pushButton_one);

        ETC_pushButton_Look = new QPushButton(groupBox_13);
        ETC_pushButton_Look->setObjectName(QString::fromUtf8("ETC_pushButton_Look"));

        horizontalLayout_51->addWidget(ETC_pushButton_Look);


        verticalLayout_25->addLayout(horizontalLayout_51);


        horizontalLayout_52->addLayout(verticalLayout_25);


        verticalLayout_48->addWidget(groupBox_13);


        horizontalLayout_111->addLayout(verticalLayout_48);

        groupBox_14 = new QGroupBox(tab_ETC_Basics);
        groupBox_14->setObjectName(QString::fromUtf8("groupBox_14"));
        horizontalLayout_112 = new QHBoxLayout(groupBox_14);
        horizontalLayout_112->setSpacing(6);
        horizontalLayout_112->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_112->setObjectName(QString::fromUtf8("horizontalLayout_112"));
        verticalLayout_28 = new QVBoxLayout();
        verticalLayout_28->setSpacing(6);
        verticalLayout_28->setObjectName(QString::fromUtf8("verticalLayout_28"));
        verticalLayout_29 = new QVBoxLayout();
        verticalLayout_29->setSpacing(6);
        verticalLayout_29->setObjectName(QString::fromUtf8("verticalLayout_29"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_21 = new QLabel(groupBox_14);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        sizePolicy2.setHeightForWidth(label_21->sizePolicy().hasHeightForWidth());
        label_21->setSizePolicy(sizePolicy2);

        gridLayout->addWidget(label_21, 0, 0, 1, 1);

        ETC_comboBox_Card_Num = new QComboBox(groupBox_14);
        ETC_comboBox_Card_Num->setObjectName(QString::fromUtf8("ETC_comboBox_Card_Num"));

        gridLayout->addWidget(ETC_comboBox_Card_Num, 0, 1, 1, 1);

        label_45 = new QLabel(groupBox_14);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        sizePolicy2.setHeightForWidth(label_45->sizePolicy().hasHeightForWidth());
        label_45->setSizePolicy(sizePolicy2);

        gridLayout->addWidget(label_45, 1, 0, 1, 1);

        ETC_comboBox_Momery = new QComboBox(groupBox_14);
        ETC_comboBox_Momery->addItem(QString());
        ETC_comboBox_Momery->addItem(QString());
        ETC_comboBox_Momery->addItem(QString());
        ETC_comboBox_Momery->addItem(QString());
        ETC_comboBox_Momery->setObjectName(QString::fromUtf8("ETC_comboBox_Momery"));

        gridLayout->addWidget(ETC_comboBox_Momery, 1, 1, 1, 1);


        verticalLayout_29->addLayout(gridLayout);

        horizontalLayout_56 = new QHBoxLayout();
        horizontalLayout_56->setSpacing(6);
        horizontalLayout_56->setObjectName(QString::fromUtf8("horizontalLayout_56"));
        label_22 = new QLabel(groupBox_14);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        sizePolicy2.setHeightForWidth(label_22->sizePolicy().hasHeightForWidth());
        label_22->setSizePolicy(sizePolicy2);

        horizontalLayout_56->addWidget(label_22);

        ETC_lineEdit_Start_Add = new QLineEdit(groupBox_14);
        ETC_lineEdit_Start_Add->setObjectName(QString::fromUtf8("ETC_lineEdit_Start_Add"));

        horizontalLayout_56->addWidget(ETC_lineEdit_Start_Add);

        label_23 = new QLabel(groupBox_14);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        sizePolicy2.setHeightForWidth(label_23->sizePolicy().hasHeightForWidth());
        label_23->setSizePolicy(sizePolicy2);

        horizontalLayout_56->addWidget(label_23);

        ETC_lineEdit_ReadLength = new QLineEdit(groupBox_14);
        ETC_lineEdit_ReadLength->setObjectName(QString::fromUtf8("ETC_lineEdit_ReadLength"));

        horizontalLayout_56->addWidget(ETC_lineEdit_ReadLength);


        verticalLayout_29->addLayout(horizontalLayout_56);


        verticalLayout_28->addLayout(verticalLayout_29);

        verticalLayout_26 = new QVBoxLayout();
        verticalLayout_26->setSpacing(6);
        verticalLayout_26->setObjectName(QString::fromUtf8("verticalLayout_26"));
        horizontalLayout_55 = new QHBoxLayout();
        horizontalLayout_55->setSpacing(6);
        horizontalLayout_55->setObjectName(QString::fromUtf8("horizontalLayout_55"));
        label_24 = new QLabel(groupBox_14);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        horizontalLayout_55->addWidget(label_24);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_55->addItem(horizontalSpacer_19);


        verticalLayout_26->addLayout(horizontalLayout_55);

        ETC_listWidget_Data = new QListWidget(groupBox_14);
        ETC_listWidget_Data->setObjectName(QString::fromUtf8("ETC_listWidget_Data"));
        ETC_listWidget_Data->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";"));

        verticalLayout_26->addWidget(ETC_listWidget_Data);


        verticalLayout_28->addLayout(verticalLayout_26);

        horizontalLayout_54 = new QHBoxLayout();
        horizontalLayout_54->setSpacing(6);
        horizontalLayout_54->setObjectName(QString::fromUtf8("horizontalLayout_54"));
        ETC_pushButton_Del_Data = new QPushButton(groupBox_14);
        ETC_pushButton_Del_Data->setObjectName(QString::fromUtf8("ETC_pushButton_Del_Data"));

        horizontalLayout_54->addWidget(ETC_pushButton_Del_Data);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_54->addItem(horizontalSpacer_17);

        ETC_label_Data_State = new QLabel(groupBox_14);
        ETC_label_Data_State->setObjectName(QString::fromUtf8("ETC_label_Data_State"));

        horizontalLayout_54->addWidget(ETC_label_Data_State);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_54->addItem(horizontalSpacer_18);

        ETC_pushButton_Read = new QPushButton(groupBox_14);
        ETC_pushButton_Read->setObjectName(QString::fromUtf8("ETC_pushButton_Read"));

        horizontalLayout_54->addWidget(ETC_pushButton_Read);


        verticalLayout_28->addLayout(horizontalLayout_54);

        horizontalLayout_109 = new QHBoxLayout();
        horizontalLayout_109->setSpacing(6);
        horizontalLayout_109->setObjectName(QString::fromUtf8("horizontalLayout_109"));
        label_47 = new QLabel(groupBox_14);
        label_47->setObjectName(QString::fromUtf8("label_47"));

        horizontalLayout_109->addWidget(label_47);

        ETC_lineEdit_Write_Add = new QLineEdit(groupBox_14);
        ETC_lineEdit_Write_Add->setObjectName(QString::fromUtf8("ETC_lineEdit_Write_Add"));

        horizontalLayout_109->addWidget(ETC_lineEdit_Write_Add);

        label_48 = new QLabel(groupBox_14);
        label_48->setObjectName(QString::fromUtf8("label_48"));

        horizontalLayout_109->addWidget(label_48);

        ETC_lineEdit_Write_Length = new QLineEdit(groupBox_14);
        ETC_lineEdit_Write_Length->setObjectName(QString::fromUtf8("ETC_lineEdit_Write_Length"));
        ETC_lineEdit_Write_Length->setReadOnly(true);

        horizontalLayout_109->addWidget(ETC_lineEdit_Write_Length);


        verticalLayout_28->addLayout(horizontalLayout_109);

        horizontalLayout_53 = new QHBoxLayout();
        horizontalLayout_53->setSpacing(6);
        horizontalLayout_53->setObjectName(QString::fromUtf8("horizontalLayout_53"));
        ETC_lineEdit_WriteData = new QLineEdit(groupBox_14);
        ETC_lineEdit_WriteData->setObjectName(QString::fromUtf8("ETC_lineEdit_WriteData"));

        horizontalLayout_53->addWidget(ETC_lineEdit_WriteData);

        ETC_pushButton_Write = new QPushButton(groupBox_14);
        ETC_pushButton_Write->setObjectName(QString::fromUtf8("ETC_pushButton_Write"));
        sizePolicy9.setHeightForWidth(ETC_pushButton_Write->sizePolicy().hasHeightForWidth());
        ETC_pushButton_Write->setSizePolicy(sizePolicy9);

        horizontalLayout_53->addWidget(ETC_pushButton_Write);


        verticalLayout_28->addLayout(horizontalLayout_53);


        horizontalLayout_112->addLayout(verticalLayout_28);


        horizontalLayout_111->addWidget(groupBox_14);

        horizontalLayout_111->setStretch(0, 1);
        horizontalLayout_111->setStretch(1, 2);

        horizontalLayout_113->addLayout(horizontalLayout_111);

        tabWidget_ETC->addTab(tab_ETC_Basics, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        horizontalLayout_139 = new QHBoxLayout(tab_4);
        horizontalLayout_139->setSpacing(6);
        horizontalLayout_139->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_139->setObjectName(QString::fromUtf8("horizontalLayout_139"));
        verticalLayout_56 = new QVBoxLayout();
        verticalLayout_56->setSpacing(6);
        verticalLayout_56->setObjectName(QString::fromUtf8("verticalLayout_56"));
        horizontalLayout_136 = new QHBoxLayout();
        horizontalLayout_136->setSpacing(6);
        horizontalLayout_136->setObjectName(QString::fromUtf8("horizontalLayout_136"));
        groupBox_37 = new QGroupBox(tab_4);
        groupBox_37->setObjectName(QString::fromUtf8("groupBox_37"));
        horizontalLayout_129 = new QHBoxLayout(groupBox_37);
        horizontalLayout_129->setSpacing(6);
        horizontalLayout_129->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_129->setObjectName(QString::fromUtf8("horizontalLayout_129"));
        verticalLayout_52 = new QVBoxLayout();
        verticalLayout_52->setSpacing(6);
        verticalLayout_52->setObjectName(QString::fromUtf8("verticalLayout_52"));
        horizontalLayout_127 = new QHBoxLayout();
        horizontalLayout_127->setSpacing(6);
        horizontalLayout_127->setObjectName(QString::fromUtf8("horizontalLayout_127"));
        label_52 = new QLabel(groupBox_37);
        label_52->setObjectName(QString::fromUtf8("label_52"));

        horizontalLayout_127->addWidget(label_52);

        ETC_lineEdit_A_Card_Num = new QLineEdit(groupBox_37);
        ETC_lineEdit_A_Card_Num->setObjectName(QString::fromUtf8("ETC_lineEdit_A_Card_Num"));
        ETC_lineEdit_A_Card_Num->setReadOnly(true);

        horizontalLayout_127->addWidget(ETC_lineEdit_A_Card_Num);


        verticalLayout_52->addLayout(horizontalLayout_127);

        horizontalLayout_128 = new QHBoxLayout();
        horizontalLayout_128->setSpacing(6);
        horizontalLayout_128->setObjectName(QString::fromUtf8("horizontalLayout_128"));
        label_53 = new QLabel(groupBox_37);
        label_53->setObjectName(QString::fromUtf8("label_53"));

        horizontalLayout_128->addWidget(label_53);

        ETC_lineEdit_A_Balance = new QLineEdit(groupBox_37);
        ETC_lineEdit_A_Balance->setObjectName(QString::fromUtf8("ETC_lineEdit_A_Balance"));
        ETC_lineEdit_A_Balance->setReadOnly(true);

        horizontalLayout_128->addWidget(ETC_lineEdit_A_Balance);


        verticalLayout_52->addLayout(horizontalLayout_128);


        horizontalLayout_129->addLayout(verticalLayout_52);


        horizontalLayout_136->addWidget(groupBox_37);

        groupBox_38 = new QGroupBox(tab_4);
        groupBox_38->setObjectName(QString::fromUtf8("groupBox_38"));
        horizontalLayout_132 = new QHBoxLayout(groupBox_38);
        horizontalLayout_132->setSpacing(6);
        horizontalLayout_132->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_132->setObjectName(QString::fromUtf8("horizontalLayout_132"));
        verticalLayout_53 = new QVBoxLayout();
        verticalLayout_53->setSpacing(6);
        verticalLayout_53->setObjectName(QString::fromUtf8("verticalLayout_53"));
        horizontalLayout_130 = new QHBoxLayout();
        horizontalLayout_130->setSpacing(6);
        horizontalLayout_130->setObjectName(QString::fromUtf8("horizontalLayout_130"));
        label_54 = new QLabel(groupBox_38);
        label_54->setObjectName(QString::fromUtf8("label_54"));

        horizontalLayout_130->addWidget(label_54);

        ETC_lineEdit_A_Up_Money = new QLineEdit(groupBox_38);
        ETC_lineEdit_A_Up_Money->setObjectName(QString::fromUtf8("ETC_lineEdit_A_Up_Money"));

        horizontalLayout_130->addWidget(ETC_lineEdit_A_Up_Money);


        verticalLayout_53->addLayout(horizontalLayout_130);

        horizontalLayout_131 = new QHBoxLayout();
        horizontalLayout_131->setSpacing(6);
        horizontalLayout_131->setObjectName(QString::fromUtf8("horizontalLayout_131"));
        horizontalSpacer_40 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_131->addItem(horizontalSpacer_40);

        ETC_pushButton_A_Up_Money = new QPushButton(groupBox_38);
        ETC_pushButton_A_Up_Money->setObjectName(QString::fromUtf8("ETC_pushButton_A_Up_Money"));

        horizontalLayout_131->addWidget(ETC_pushButton_A_Up_Money);


        verticalLayout_53->addLayout(horizontalLayout_131);


        horizontalLayout_132->addLayout(verticalLayout_53);


        horizontalLayout_136->addWidget(groupBox_38);

        groupBox_39 = new QGroupBox(tab_4);
        groupBox_39->setObjectName(QString::fromUtf8("groupBox_39"));
        horizontalLayout_135 = new QHBoxLayout(groupBox_39);
        horizontalLayout_135->setSpacing(6);
        horizontalLayout_135->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_135->setObjectName(QString::fromUtf8("horizontalLayout_135"));
        verticalLayout_54 = new QVBoxLayout();
        verticalLayout_54->setSpacing(6);
        verticalLayout_54->setObjectName(QString::fromUtf8("verticalLayout_54"));
        horizontalLayout_134 = new QHBoxLayout();
        horizontalLayout_134->setSpacing(6);
        horizontalLayout_134->setObjectName(QString::fromUtf8("horizontalLayout_134"));
        label_55 = new QLabel(groupBox_39);
        label_55->setObjectName(QString::fromUtf8("label_55"));

        horizontalLayout_134->addWidget(label_55);

        ETC_lineEdit_A_Down_Money = new QLineEdit(groupBox_39);
        ETC_lineEdit_A_Down_Money->setObjectName(QString::fromUtf8("ETC_lineEdit_A_Down_Money"));

        horizontalLayout_134->addWidget(ETC_lineEdit_A_Down_Money);


        verticalLayout_54->addLayout(horizontalLayout_134);

        horizontalLayout_133 = new QHBoxLayout();
        horizontalLayout_133->setSpacing(6);
        horizontalLayout_133->setObjectName(QString::fromUtf8("horizontalLayout_133"));
        horizontalSpacer_41 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_133->addItem(horizontalSpacer_41);

        ETC_pushButton_A_Down_Money = new QPushButton(groupBox_39);
        ETC_pushButton_A_Down_Money->setObjectName(QString::fromUtf8("ETC_pushButton_A_Down_Money"));

        horizontalLayout_133->addWidget(ETC_pushButton_A_Down_Money);


        verticalLayout_54->addLayout(horizontalLayout_133);


        horizontalLayout_135->addLayout(verticalLayout_54);


        horizontalLayout_136->addWidget(groupBox_39);


        verticalLayout_56->addLayout(horizontalLayout_136);

        groupBox_40 = new QGroupBox(tab_4);
        groupBox_40->setObjectName(QString::fromUtf8("groupBox_40"));
        horizontalLayout_138 = new QHBoxLayout(groupBox_40);
        horizontalLayout_138->setSpacing(6);
        horizontalLayout_138->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_138->setObjectName(QString::fromUtf8("horizontalLayout_138"));
        verticalLayout_55 = new QVBoxLayout();
        verticalLayout_55->setSpacing(6);
        verticalLayout_55->setObjectName(QString::fromUtf8("verticalLayout_55"));
        ETC_listWidget_A_Data = new QListWidget(groupBox_40);
        ETC_listWidget_A_Data->setObjectName(QString::fromUtf8("ETC_listWidget_A_Data"));

        verticalLayout_55->addWidget(ETC_listWidget_A_Data);

        horizontalLayout_137 = new QHBoxLayout();
        horizontalLayout_137->setSpacing(6);
        horizontalLayout_137->setObjectName(QString::fromUtf8("horizontalLayout_137"));
        horizontalSpacer_42 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_137->addItem(horizontalSpacer_42);

        ETC_pushButton_A_Del_Data = new QPushButton(groupBox_40);
        ETC_pushButton_A_Del_Data->setObjectName(QString::fromUtf8("ETC_pushButton_A_Del_Data"));

        horizontalLayout_137->addWidget(ETC_pushButton_A_Del_Data);


        verticalLayout_55->addLayout(horizontalLayout_137);


        horizontalLayout_138->addLayout(verticalLayout_55);


        verticalLayout_56->addWidget(groupBox_40);


        horizontalLayout_139->addLayout(verticalLayout_56);

        tabWidget_ETC->addTab(tab_4, QString());
        tab_ETC_App = new QWidget();
        tab_ETC_App->setObjectName(QString::fromUtf8("tab_ETC_App"));
        horizontalLayout_75 = new QHBoxLayout(tab_ETC_App);
        horizontalLayout_75->setSpacing(6);
        horizontalLayout_75->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_75->setObjectName(QString::fromUtf8("horizontalLayout_75"));
        verticalLayout_60 = new QVBoxLayout();
        verticalLayout_60->setSpacing(6);
        verticalLayout_60->setObjectName(QString::fromUtf8("verticalLayout_60"));
        horizontalLayout_59 = new QHBoxLayout();
        horizontalLayout_59->setSpacing(6);
        horizontalLayout_59->setObjectName(QString::fromUtf8("horizontalLayout_59"));
        groupBox_15 = new QGroupBox(tab_ETC_App);
        groupBox_15->setObjectName(QString::fromUtf8("groupBox_15"));
        horizontalLayout_58 = new QHBoxLayout(groupBox_15);
        horizontalLayout_58->setSpacing(6);
        horizontalLayout_58->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_58->setObjectName(QString::fromUtf8("horizontalLayout_58"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_25 = new QLabel(groupBox_15);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        gridLayout_2->addWidget(label_25, 0, 0, 1, 1);

        ETC_lineEdit_Mess_Money = new QLineEdit(groupBox_15);
        ETC_lineEdit_Mess_Money->setObjectName(QString::fromUtf8("ETC_lineEdit_Mess_Money"));
        ETC_lineEdit_Mess_Money->setReadOnly(true);

        gridLayout_2->addWidget(ETC_lineEdit_Mess_Money, 1, 1, 1, 1);

        ETC_lineEdit_Mess_Card = new QLineEdit(groupBox_15);
        ETC_lineEdit_Mess_Card->setObjectName(QString::fromUtf8("ETC_lineEdit_Mess_Card"));
        ETC_lineEdit_Mess_Card->setReadOnly(true);

        gridLayout_2->addWidget(ETC_lineEdit_Mess_Card, 0, 1, 1, 1);

        label_26 = new QLabel(groupBox_15);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout_2->addWidget(label_26, 1, 0, 1, 1);


        horizontalLayout_58->addLayout(gridLayout_2);


        horizontalLayout_59->addWidget(groupBox_15);

        groupBox_42 = new QGroupBox(tab_ETC_App);
        groupBox_42->setObjectName(QString::fromUtf8("groupBox_42"));
        horizontalLayout_47 = new QHBoxLayout(groupBox_42);
        horizontalLayout_47->setSpacing(6);
        horizontalLayout_47->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_47->setObjectName(QString::fromUtf8("horizontalLayout_47"));
        verticalLayout_36 = new QVBoxLayout();
        verticalLayout_36->setSpacing(6);
        verticalLayout_36->setObjectName(QString::fromUtf8("verticalLayout_36"));
        ETC_radioButton_App_Down = new QRadioButton(groupBox_42);
        ETC_radioButton_App_Down->setObjectName(QString::fromUtf8("ETC_radioButton_App_Down"));
        ETC_radioButton_App_Down->setChecked(true);

        verticalLayout_36->addWidget(ETC_radioButton_App_Down);

        ETC_radioButton_App_Up = new QRadioButton(groupBox_42);
        ETC_radioButton_App_Up->setObjectName(QString::fromUtf8("ETC_radioButton_App_Up"));

        verticalLayout_36->addWidget(ETC_radioButton_App_Up);


        horizontalLayout_47->addLayout(verticalLayout_36);


        horizontalLayout_59->addWidget(groupBox_42);

        groupBox_18 = new QGroupBox(tab_ETC_App);
        groupBox_18->setObjectName(QString::fromUtf8("groupBox_18"));
        sizePolicy6.setHeightForWidth(groupBox_18->sizePolicy().hasHeightForWidth());
        groupBox_18->setSizePolicy(sizePolicy6);
        horizontalLayout_73 = new QHBoxLayout(groupBox_18);
        horizontalLayout_73->setSpacing(6);
        horizontalLayout_73->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_73->setObjectName(QString::fromUtf8("horizontalLayout_73"));
        verticalLayout_32 = new QVBoxLayout();
        verticalLayout_32->setSpacing(6);
        verticalLayout_32->setObjectName(QString::fromUtf8("verticalLayout_32"));
        horizontalLayout_69 = new QHBoxLayout();
        horizontalLayout_69->setSpacing(6);
        horizontalLayout_69->setObjectName(QString::fromUtf8("horizontalLayout_69"));
        horizontalLayout_69->setSizeConstraint(QLayout::SetFixedSize);
        label_28 = new QLabel(groupBox_18);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        sizePolicy5.setHeightForWidth(label_28->sizePolicy().hasHeightForWidth());
        label_28->setSizePolicy(sizePolicy5);

        horizontalLayout_69->addWidget(label_28);

        ETC_lineEdit_Up_Money = new QLineEdit(groupBox_18);
        ETC_lineEdit_Up_Money->setObjectName(QString::fromUtf8("ETC_lineEdit_Up_Money"));

        horizontalLayout_69->addWidget(ETC_lineEdit_Up_Money);


        verticalLayout_32->addLayout(horizontalLayout_69);

        horizontalLayout_70 = new QHBoxLayout();
        horizontalLayout_70->setSpacing(6);
        horizontalLayout_70->setObjectName(QString::fromUtf8("horizontalLayout_70"));
        horizontalSpacer_24 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_70->addItem(horizontalSpacer_24);

        ETC_pushButton_Up = new QPushButton(groupBox_18);
        ETC_pushButton_Up->setObjectName(QString::fromUtf8("ETC_pushButton_Up"));

        horizontalLayout_70->addWidget(ETC_pushButton_Up);


        verticalLayout_32->addLayout(horizontalLayout_70);


        horizontalLayout_73->addLayout(verticalLayout_32);


        horizontalLayout_59->addWidget(groupBox_18);


        verticalLayout_60->addLayout(horizontalLayout_59);

        horizontalLayout_74 = new QHBoxLayout();
        horizontalLayout_74->setSpacing(6);
        horizontalLayout_74->setObjectName(QString::fromUtf8("horizontalLayout_74"));
        groupBox_16 = new QGroupBox(tab_ETC_App);
        groupBox_16->setObjectName(QString::fromUtf8("groupBox_16"));
        horizontalLayout_62 = new QHBoxLayout(groupBox_16);
        horizontalLayout_62->setSpacing(6);
        horizontalLayout_62->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_62->setObjectName(QString::fromUtf8("horizontalLayout_62"));
        verticalLayout_30 = new QVBoxLayout();
        verticalLayout_30->setSpacing(6);
        verticalLayout_30->setObjectName(QString::fromUtf8("verticalLayout_30"));
        ETC_listWidget_App_Data = new QListWidget(groupBox_16);
        ETC_listWidget_App_Data->setObjectName(QString::fromUtf8("ETC_listWidget_App_Data"));

        verticalLayout_30->addWidget(ETC_listWidget_App_Data);

        horizontalLayout_61 = new QHBoxLayout();
        horizontalLayout_61->setSpacing(6);
        horizontalLayout_61->setObjectName(QString::fromUtf8("horizontalLayout_61"));
        ETC_pushButton_B_Del_Uaer = new QPushButton(groupBox_16);
        ETC_pushButton_B_Del_Uaer->setObjectName(QString::fromUtf8("ETC_pushButton_B_Del_Uaer"));

        horizontalLayout_61->addWidget(ETC_pushButton_B_Del_Uaer);

        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_61->addItem(horizontalSpacer_20);

        ETC_pushButton_APP_Del = new QPushButton(groupBox_16);
        ETC_pushButton_APP_Del->setObjectName(QString::fromUtf8("ETC_pushButton_APP_Del"));

        horizontalLayout_61->addWidget(ETC_pushButton_APP_Del);


        verticalLayout_30->addLayout(horizontalLayout_61);


        horizontalLayout_62->addLayout(verticalLayout_30);


        horizontalLayout_74->addWidget(groupBox_16);

        verticalLayout_35 = new QVBoxLayout();
        verticalLayout_35->setSpacing(6);
        verticalLayout_35->setObjectName(QString::fromUtf8("verticalLayout_35"));
        groupBox_17 = new QGroupBox(tab_ETC_App);
        groupBox_17->setObjectName(QString::fromUtf8("groupBox_17"));
        horizontalLayout_71 = new QHBoxLayout(groupBox_17);
        horizontalLayout_71->setSpacing(6);
        horizontalLayout_71->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_71->setObjectName(QString::fromUtf8("horizontalLayout_71"));
        verticalLayout_27 = new QVBoxLayout();
        verticalLayout_27->setSpacing(6);
        verticalLayout_27->setObjectName(QString::fromUtf8("verticalLayout_27"));
        horizontalLayout_63 = new QHBoxLayout();
        horizontalLayout_63->setSpacing(6);
        horizontalLayout_63->setObjectName(QString::fromUtf8("horizontalLayout_63"));
        label_29 = new QLabel(groupBox_17);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        sizePolicy2.setHeightForWidth(label_29->sizePolicy().hasHeightForWidth());
        label_29->setSizePolicy(sizePolicy2);

        horizontalLayout_63->addWidget(label_29);

        ETC_lineEdit_Time_In = new QLineEdit(groupBox_17);
        ETC_lineEdit_Time_In->setObjectName(QString::fromUtf8("ETC_lineEdit_Time_In"));
        ETC_lineEdit_Time_In->setReadOnly(true);

        horizontalLayout_63->addWidget(ETC_lineEdit_Time_In);


        verticalLayout_27->addLayout(horizontalLayout_63);

        horizontalLayout_64 = new QHBoxLayout();
        horizontalLayout_64->setSpacing(6);
        horizontalLayout_64->setObjectName(QString::fromUtf8("horizontalLayout_64"));
        label_19 = new QLabel(groupBox_17);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        sizePolicy5.setHeightForWidth(label_19->sizePolicy().hasHeightForWidth());
        label_19->setSizePolicy(sizePolicy5);

        horizontalLayout_64->addWidget(label_19);

        ETC_lineEdit_Time_Out = new QLineEdit(groupBox_17);
        ETC_lineEdit_Time_Out->setObjectName(QString::fromUtf8("ETC_lineEdit_Time_Out"));
        ETC_lineEdit_Time_Out->setReadOnly(true);

        horizontalLayout_64->addWidget(ETC_lineEdit_Time_Out);


        verticalLayout_27->addLayout(horizontalLayout_64);

        horizontalLayout_65 = new QHBoxLayout();
        horizontalLayout_65->setSpacing(6);
        horizontalLayout_65->setObjectName(QString::fromUtf8("horizontalLayout_65"));
        label_31 = new QLabel(groupBox_17);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        horizontalLayout_65->addWidget(label_31);

        ETC_lineEdit_Time_Stop = new QLineEdit(groupBox_17);
        ETC_lineEdit_Time_Stop->setObjectName(QString::fromUtf8("ETC_lineEdit_Time_Stop"));
        ETC_lineEdit_Time_Stop->setReadOnly(true);

        horizontalLayout_65->addWidget(ETC_lineEdit_Time_Stop);


        verticalLayout_27->addLayout(horizontalLayout_65);

        horizontalLayout_66 = new QHBoxLayout();
        horizontalLayout_66->setSpacing(6);
        horizontalLayout_66->setObjectName(QString::fromUtf8("horizontalLayout_66"));
        label_33 = new QLabel(groupBox_17);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        horizontalLayout_66->addWidget(label_33);

        ETC_lineEdit_Money_Stop = new QLineEdit(groupBox_17);
        ETC_lineEdit_Money_Stop->setObjectName(QString::fromUtf8("ETC_lineEdit_Money_Stop"));

        horizontalLayout_66->addWidget(ETC_lineEdit_Money_Stop);


        verticalLayout_27->addLayout(horizontalLayout_66);

        horizontalLayout_68 = new QHBoxLayout();
        horizontalLayout_68->setSpacing(6);
        horizontalLayout_68->setObjectName(QString::fromUtf8("horizontalLayout_68"));
        label_27 = new QLabel(groupBox_17);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        horizontalLayout_68->addWidget(label_27);

        ETC_lineEdit_Money_Out = new QLineEdit(groupBox_17);
        ETC_lineEdit_Money_Out->setObjectName(QString::fromUtf8("ETC_lineEdit_Money_Out"));
        ETC_lineEdit_Money_Out->setReadOnly(true);

        horizontalLayout_68->addWidget(ETC_lineEdit_Money_Out);


        verticalLayout_27->addLayout(horizontalLayout_68);

        horizontalLayout_67 = new QHBoxLayout();
        horizontalLayout_67->setSpacing(6);
        horizontalLayout_67->setObjectName(QString::fromUtf8("horizontalLayout_67"));
        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_67->addItem(horizontalSpacer_21);

        ETC_pushButton_Money_Save = new QPushButton(groupBox_17);
        ETC_pushButton_Money_Save->setObjectName(QString::fromUtf8("ETC_pushButton_Money_Save"));

        horizontalLayout_67->addWidget(ETC_pushButton_Money_Save);


        verticalLayout_27->addLayout(horizontalLayout_67);


        horizontalLayout_71->addLayout(verticalLayout_27);


        verticalLayout_35->addWidget(groupBox_17);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_35->addItem(verticalSpacer_3);

        groupBox_19 = new QGroupBox(tab_ETC_App);
        groupBox_19->setObjectName(QString::fromUtf8("groupBox_19"));
        horizontalLayout_72 = new QHBoxLayout(groupBox_19);
        horizontalLayout_72->setSpacing(6);
        horizontalLayout_72->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_72->setObjectName(QString::fromUtf8("horizontalLayout_72"));
        verticalLayout_31 = new QVBoxLayout();
        verticalLayout_31->setSpacing(6);
        verticalLayout_31->setObjectName(QString::fromUtf8("verticalLayout_31"));
        ETC_pushButton_ON = new QPushButton(groupBox_19);
        ETC_pushButton_ON->setObjectName(QString::fromUtf8("ETC_pushButton_ON"));
        sizePolicy9.setHeightForWidth(ETC_pushButton_ON->sizePolicy().hasHeightForWidth());
        ETC_pushButton_ON->setSizePolicy(sizePolicy9);

        verticalLayout_31->addWidget(ETC_pushButton_ON);

        ETC_pushButton_OFF = new QPushButton(groupBox_19);
        ETC_pushButton_OFF->setObjectName(QString::fromUtf8("ETC_pushButton_OFF"));
        sizePolicy9.setHeightForWidth(ETC_pushButton_OFF->sizePolicy().hasHeightForWidth());
        ETC_pushButton_OFF->setSizePolicy(sizePolicy9);

        verticalLayout_31->addWidget(ETC_pushButton_OFF);

        ETC_pushButton_Open = new QPushButton(groupBox_19);
        ETC_pushButton_Open->setObjectName(QString::fromUtf8("ETC_pushButton_Open"));
        sizePolicy9.setHeightForWidth(ETC_pushButton_Open->sizePolicy().hasHeightForWidth());
        ETC_pushButton_Open->setSizePolicy(sizePolicy9);

        verticalLayout_31->addWidget(ETC_pushButton_Open);


        horizontalLayout_72->addLayout(verticalLayout_31);


        verticalLayout_35->addWidget(groupBox_19);

        verticalLayout_35->setStretch(0, 1);
        verticalLayout_35->setStretch(1, 1);
        verticalLayout_35->setStretch(2, 2);

        horizontalLayout_74->addLayout(verticalLayout_35);

        horizontalLayout_74->setStretch(0, 2);
        horizontalLayout_74->setStretch(1, 1);

        verticalLayout_60->addLayout(horizontalLayout_74);


        horizontalLayout_75->addLayout(verticalLayout_60);

        tabWidget_ETC->addTab(tab_ETC_App, QString());

        horizontalLayout_50->addWidget(tabWidget_ETC);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        horizontalLayout_76 = new QHBoxLayout(page_2);
        horizontalLayout_76->setSpacing(6);
        horizontalLayout_76->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_76->setObjectName(QString::fromUtf8("horizontalLayout_76"));
        tabWidget_G = new QTabWidget(page_2);
        tabWidget_G->setObjectName(QString::fromUtf8("tabWidget_G"));
        tab_24G = new QWidget();
        tab_24G->setObjectName(QString::fromUtf8("tab_24G"));
        horizontalLayout_123 = new QHBoxLayout(tab_24G);
        horizontalLayout_123->setSpacing(6);
        horizontalLayout_123->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_123->setObjectName(QString::fromUtf8("horizontalLayout_123"));
        verticalLayout_51 = new QVBoxLayout();
        verticalLayout_51->setSpacing(6);
        verticalLayout_51->setObjectName(QString::fromUtf8("verticalLayout_51"));
        horizontalLayout_122 = new QHBoxLayout();
        horizontalLayout_122->setSpacing(6);
        horizontalLayout_122->setObjectName(QString::fromUtf8("horizontalLayout_122"));
        groupBox_43 = new QGroupBox(tab_24G);
        groupBox_43->setObjectName(QString::fromUtf8("groupBox_43"));
        horizontalLayout_119 = new QHBoxLayout(groupBox_43);
        horizontalLayout_119->setSpacing(6);
        horizontalLayout_119->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_119->setObjectName(QString::fromUtf8("horizontalLayout_119"));
        horizontalLayout_114 = new QHBoxLayout();
        horizontalLayout_114->setSpacing(6);
        horizontalLayout_114->setObjectName(QString::fromUtf8("horizontalLayout_114"));
        verticalLayout_33 = new QVBoxLayout();
        verticalLayout_33->setSpacing(6);
        verticalLayout_33->setObjectName(QString::fromUtf8("verticalLayout_33"));
        label_18 = new QLabel(groupBox_43);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        verticalLayout_33->addWidget(label_18);

        label_56 = new QLabel(groupBox_43);
        label_56->setObjectName(QString::fromUtf8("label_56"));

        verticalLayout_33->addWidget(label_56);


        horizontalLayout_114->addLayout(verticalLayout_33);

        verticalLayout_49 = new QVBoxLayout();
        verticalLayout_49->setSpacing(6);
        verticalLayout_49->setObjectName(QString::fromUtf8("verticalLayout_49"));
        G_lineEdit_Mac = new QLineEdit(groupBox_43);
        G_lineEdit_Mac->setObjectName(QString::fromUtf8("G_lineEdit_Mac"));
        sizePolicy3.setHeightForWidth(G_lineEdit_Mac->sizePolicy().hasHeightForWidth());
        G_lineEdit_Mac->setSizePolicy(sizePolicy3);
        G_lineEdit_Mac->setMinimumSize(QSize(200, 0));
        G_lineEdit_Mac->setReadOnly(true);

        verticalLayout_49->addWidget(G_lineEdit_Mac);

        horizontalLayout_49 = new QHBoxLayout();
        horizontalLayout_49->setSpacing(6);
        horizontalLayout_49->setObjectName(QString::fromUtf8("horizontalLayout_49"));
        G_lineEdit_Panid = new QLineEdit(groupBox_43);
        G_lineEdit_Panid->setObjectName(QString::fromUtf8("G_lineEdit_Panid"));
        sizePolicy.setHeightForWidth(G_lineEdit_Panid->sizePolicy().hasHeightForWidth());
        G_lineEdit_Panid->setSizePolicy(sizePolicy);
        G_lineEdit_Panid->setMinimumSize(QSize(200, 0));

        horizontalLayout_49->addWidget(G_lineEdit_Panid);

        label_57 = new QLabel(groupBox_43);
        label_57->setObjectName(QString::fromUtf8("label_57"));

        horizontalLayout_49->addWidget(label_57);

        G_comboBox_Channel = new QComboBox(groupBox_43);
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->addItem(QString());
        G_comboBox_Channel->setObjectName(QString::fromUtf8("G_comboBox_Channel"));
        sizePolicy.setHeightForWidth(G_comboBox_Channel->sizePolicy().hasHeightForWidth());
        G_comboBox_Channel->setSizePolicy(sizePolicy);
        G_comboBox_Channel->setMinimumSize(QSize(200, 0));

        horizontalLayout_49->addWidget(G_comboBox_Channel);


        verticalLayout_49->addLayout(horizontalLayout_49);


        horizontalLayout_114->addLayout(verticalLayout_49);

        verticalLayout_50 = new QVBoxLayout();
        verticalLayout_50->setSpacing(6);
        verticalLayout_50->setObjectName(QString::fromUtf8("verticalLayout_50"));
        G_pushButton_Read = new QPushButton(groupBox_43);
        G_pushButton_Read->setObjectName(QString::fromUtf8("G_pushButton_Read"));

        verticalLayout_50->addWidget(G_pushButton_Read);

        G_pushButton_Write = new QPushButton(groupBox_43);
        G_pushButton_Write->setObjectName(QString::fromUtf8("G_pushButton_Write"));

        verticalLayout_50->addWidget(G_pushButton_Write);


        horizontalLayout_114->addLayout(verticalLayout_50);


        horizontalLayout_119->addLayout(horizontalLayout_114);


        horizontalLayout_122->addWidget(groupBox_43);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_122->addItem(horizontalSpacer_23);


        verticalLayout_51->addLayout(horizontalLayout_122);

        groupBox_44 = new QGroupBox(tab_24G);
        groupBox_44->setObjectName(QString::fromUtf8("groupBox_44"));
        horizontalLayout_116 = new QHBoxLayout(groupBox_44);
        horizontalLayout_116->setSpacing(6);
        horizontalLayout_116->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_116->setObjectName(QString::fromUtf8("horizontalLayout_116"));
        verticalLayout_46 = new QVBoxLayout();
        verticalLayout_46->setSpacing(6);
        verticalLayout_46->setObjectName(QString::fromUtf8("verticalLayout_46"));
        horizontalLayout_143 = new QHBoxLayout();
        horizontalLayout_143->setSpacing(6);
        horizontalLayout_143->setObjectName(QString::fromUtf8("horizontalLayout_143"));
        label_58 = new QLabel(groupBox_44);
        label_58->setObjectName(QString::fromUtf8("label_58"));
        sizePolicy7.setHeightForWidth(label_58->sizePolicy().hasHeightForWidth());
        label_58->setSizePolicy(sizePolicy7);

        horizontalLayout_143->addWidget(label_58);

        G_comboBox_Data_Num = new QComboBox(groupBox_44);
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->addItem(QString());
        G_comboBox_Data_Num->setObjectName(QString::fromUtf8("G_comboBox_Data_Num"));

        horizontalLayout_143->addWidget(G_comboBox_Data_Num);


        verticalLayout_46->addLayout(horizontalLayout_143);

        horizontalLayout_145 = new QHBoxLayout();
        horizontalLayout_145->setSpacing(6);
        horizontalLayout_145->setObjectName(QString::fromUtf8("horizontalLayout_145"));
        label_59 = new QLabel(groupBox_44);
        label_59->setObjectName(QString::fromUtf8("label_59"));

        horizontalLayout_145->addWidget(label_59);

        horizontalSpacer_43 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_145->addItem(horizontalSpacer_43);


        verticalLayout_46->addLayout(horizontalLayout_145);

        G_listWidget_Data = new QListWidget(groupBox_44);
        G_listWidget_Data->setObjectName(QString::fromUtf8("G_listWidget_Data"));
        G_listWidget_Data->setStyleSheet(QString::fromUtf8("font: 9pt \"\345\256\213\344\275\223\";"));

        verticalLayout_46->addWidget(G_listWidget_Data);

        horizontalLayout_77 = new QHBoxLayout();
        horizontalLayout_77->setSpacing(6);
        horizontalLayout_77->setObjectName(QString::fromUtf8("horizontalLayout_77"));
        G_pushButton_DelData = new QPushButton(groupBox_44);
        G_pushButton_DelData->setObjectName(QString::fromUtf8("G_pushButton_DelData"));

        horizontalLayout_77->addWidget(G_pushButton_DelData);

        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_77->addItem(horizontalSpacer_22);

        G_label_State = new QLabel(groupBox_44);
        G_label_State->setObjectName(QString::fromUtf8("G_label_State"));

        horizontalLayout_77->addWidget(G_label_State);

        horizontalSpacer_39 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_77->addItem(horizontalSpacer_39);

        G_pushButton_ReadData = new QPushButton(groupBox_44);
        G_pushButton_ReadData->setObjectName(QString::fromUtf8("G_pushButton_ReadData"));

        horizontalLayout_77->addWidget(G_pushButton_ReadData);


        verticalLayout_46->addLayout(horizontalLayout_77);

        horizontalLayout_115 = new QHBoxLayout();
        horizontalLayout_115->setSpacing(6);
        horizontalLayout_115->setObjectName(QString::fromUtf8("horizontalLayout_115"));
        G_lineEdit_WriteData = new QLineEdit(groupBox_44);
        G_lineEdit_WriteData->setObjectName(QString::fromUtf8("G_lineEdit_WriteData"));

        horizontalLayout_115->addWidget(G_lineEdit_WriteData);

        G_pushButton_WriteData = new QPushButton(groupBox_44);
        G_pushButton_WriteData->setObjectName(QString::fromUtf8("G_pushButton_WriteData"));

        horizontalLayout_115->addWidget(G_pushButton_WriteData);


        verticalLayout_46->addLayout(horizontalLayout_115);


        horizontalLayout_116->addLayout(verticalLayout_46);


        verticalLayout_51->addWidget(groupBox_44);


        horizontalLayout_123->addLayout(verticalLayout_51);

        tabWidget_G->addTab(tab_24G, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        horizontalLayout_151 = new QHBoxLayout(tab_5);
        horizontalLayout_151->setSpacing(6);
        horizontalLayout_151->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_151->setObjectName(QString::fromUtf8("horizontalLayout_151"));
        verticalLayout_68 = new QVBoxLayout();
        verticalLayout_68->setSpacing(6);
        verticalLayout_68->setObjectName(QString::fromUtf8("verticalLayout_68"));
        horizontalLayout_140 = new QHBoxLayout();
        horizontalLayout_140->setSpacing(6);
        horizontalLayout_140->setObjectName(QString::fromUtf8("horizontalLayout_140"));
        groupBox_22 = new QGroupBox(tab_5);
        groupBox_22->setObjectName(QString::fromUtf8("groupBox_22"));
        horizontalLayout_125 = new QHBoxLayout(groupBox_22);
        horizontalLayout_125->setSpacing(6);
        horizontalLayout_125->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_125->setObjectName(QString::fromUtf8("horizontalLayout_125"));
        horizontalLayout_124 = new QHBoxLayout();
        horizontalLayout_124->setSpacing(6);
        horizontalLayout_124->setObjectName(QString::fromUtf8("horizontalLayout_124"));
        verticalLayout_63 = new QVBoxLayout();
        verticalLayout_63->setSpacing(6);
        verticalLayout_63->setObjectName(QString::fromUtf8("verticalLayout_63"));
        label_43 = new QLabel(groupBox_22);
        label_43->setObjectName(QString::fromUtf8("label_43"));

        verticalLayout_63->addWidget(label_43);

        label_49 = new QLabel(groupBox_22);
        label_49->setObjectName(QString::fromUtf8("label_49"));

        verticalLayout_63->addWidget(label_49);


        horizontalLayout_124->addLayout(verticalLayout_63);

        verticalLayout_64 = new QVBoxLayout();
        verticalLayout_64->setSpacing(6);
        verticalLayout_64->setObjectName(QString::fromUtf8("verticalLayout_64"));
        G_lineEdit_ReadPanid = new QLineEdit(groupBox_22);
        G_lineEdit_ReadPanid->setObjectName(QString::fromUtf8("G_lineEdit_ReadPanid"));
        G_lineEdit_ReadPanid->setMinimumSize(QSize(200, 0));

        verticalLayout_64->addWidget(G_lineEdit_ReadPanid);

        G_comboBox_ReadChannel = new QComboBox(groupBox_22);
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->addItem(QString());
        G_comboBox_ReadChannel->setObjectName(QString::fromUtf8("G_comboBox_ReadChannel"));
        G_comboBox_ReadChannel->setMinimumSize(QSize(200, 0));

        verticalLayout_64->addWidget(G_comboBox_ReadChannel);


        horizontalLayout_124->addLayout(verticalLayout_64);

        verticalLayout_65 = new QVBoxLayout();
        verticalLayout_65->setSpacing(6);
        verticalLayout_65->setObjectName(QString::fromUtf8("verticalLayout_65"));
        G_pushButton_ReadRead = new QPushButton(groupBox_22);
        G_pushButton_ReadRead->setObjectName(QString::fromUtf8("G_pushButton_ReadRead"));

        verticalLayout_65->addWidget(G_pushButton_ReadRead);

        G_pushButton_ReadWrite = new QPushButton(groupBox_22);
        G_pushButton_ReadWrite->setObjectName(QString::fromUtf8("G_pushButton_ReadWrite"));

        verticalLayout_65->addWidget(G_pushButton_ReadWrite);


        horizontalLayout_124->addLayout(verticalLayout_65);


        horizontalLayout_125->addLayout(horizontalLayout_124);


        horizontalLayout_140->addWidget(groupBox_22);

        groupBox_45 = new QGroupBox(tab_5);
        groupBox_45->setObjectName(QString::fromUtf8("groupBox_45"));
        horizontalLayout_126 = new QHBoxLayout(groupBox_45);
        horizontalLayout_126->setSpacing(6);
        horizontalLayout_126->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_126->setObjectName(QString::fromUtf8("horizontalLayout_126"));
        label_39 = new QLabel(groupBox_45);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        horizontalLayout_126->addWidget(label_39);


        horizontalLayout_140->addWidget(groupBox_45);

        horizontalSpacer_44 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_140->addItem(horizontalSpacer_44);


        verticalLayout_68->addLayout(horizontalLayout_140);

        horizontalLayout_150 = new QHBoxLayout();
        horizontalLayout_150->setSpacing(6);
        horizontalLayout_150->setObjectName(QString::fromUtf8("horizontalLayout_150"));
        groupBox_35 = new QGroupBox(tab_5);
        groupBox_35->setObjectName(QString::fromUtf8("groupBox_35"));
        horizontalLayout_142 = new QHBoxLayout(groupBox_35);
        horizontalLayout_142->setSpacing(6);
        horizontalLayout_142->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_142->setObjectName(QString::fromUtf8("horizontalLayout_142"));
        verticalLayout_66 = new QVBoxLayout();
        verticalLayout_66->setSpacing(6);
        verticalLayout_66->setObjectName(QString::fromUtf8("verticalLayout_66"));
        G_listWidget_Label = new QListWidget(groupBox_35);
        G_listWidget_Label->setObjectName(QString::fromUtf8("G_listWidget_Label"));

        verticalLayout_66->addWidget(G_listWidget_Label);

        horizontalLayout_141 = new QHBoxLayout();
        horizontalLayout_141->setSpacing(6);
        horizontalLayout_141->setObjectName(QString::fromUtf8("horizontalLayout_141"));
        G_pushButton_DelLabel = new QPushButton(groupBox_35);
        G_pushButton_DelLabel->setObjectName(QString::fromUtf8("G_pushButton_DelLabel"));

        horizontalLayout_141->addWidget(G_pushButton_DelLabel);

        horizontalSpacer_45 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_141->addItem(horizontalSpacer_45);

        G_pushButton_LookCard = new QPushButton(groupBox_35);
        G_pushButton_LookCard->setObjectName(QString::fromUtf8("G_pushButton_LookCard"));

        horizontalLayout_141->addWidget(G_pushButton_LookCard);


        verticalLayout_66->addLayout(horizontalLayout_141);


        horizontalLayout_142->addLayout(verticalLayout_66);


        horizontalLayout_150->addWidget(groupBox_35);

        groupBox_36 = new QGroupBox(tab_5);
        groupBox_36->setObjectName(QString::fromUtf8("groupBox_36"));
        horizontalLayout_149 = new QHBoxLayout(groupBox_36);
        horizontalLayout_149->setSpacing(6);
        horizontalLayout_149->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_149->setObjectName(QString::fromUtf8("horizontalLayout_149"));
        verticalLayout_67 = new QVBoxLayout();
        verticalLayout_67->setSpacing(6);
        verticalLayout_67->setObjectName(QString::fromUtf8("verticalLayout_67"));
        horizontalLayout_146 = new QHBoxLayout();
        horizontalLayout_146->setSpacing(6);
        horizontalLayout_146->setObjectName(QString::fromUtf8("horizontalLayout_146"));
        label_50 = new QLabel(groupBox_36);
        label_50->setObjectName(QString::fromUtf8("label_50"));
        sizePolicy7.setHeightForWidth(label_50->sizePolicy().hasHeightForWidth());
        label_50->setSizePolicy(sizePolicy7);

        horizontalLayout_146->addWidget(label_50);

        G_comboBox_Label = new QComboBox(groupBox_36);
        G_comboBox_Label->setObjectName(QString::fromUtf8("G_comboBox_Label"));

        horizontalLayout_146->addWidget(G_comboBox_Label);

        label_60 = new QLabel(groupBox_36);
        label_60->setObjectName(QString::fromUtf8("label_60"));
        sizePolicy7.setHeightForWidth(label_60->sizePolicy().hasHeightForWidth());
        label_60->setSizePolicy(sizePolicy7);

        horizontalLayout_146->addWidget(label_60);

        G_comboBox_Data = new QComboBox(groupBox_36);
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->addItem(QString());
        G_comboBox_Data->setObjectName(QString::fromUtf8("G_comboBox_Data"));

        horizontalLayout_146->addWidget(G_comboBox_Data);


        verticalLayout_67->addLayout(horizontalLayout_146);

        horizontalLayout_144 = new QHBoxLayout();
        horizontalLayout_144->setSpacing(6);
        horizontalLayout_144->setObjectName(QString::fromUtf8("horizontalLayout_144"));
        label_61 = new QLabel(groupBox_36);
        label_61->setObjectName(QString::fromUtf8("label_61"));

        horizontalLayout_144->addWidget(label_61);

        horizontalSpacer_47 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_144->addItem(horizontalSpacer_47);


        verticalLayout_67->addLayout(horizontalLayout_144);

        G_listWidget_Record = new QListWidget(groupBox_36);
        G_listWidget_Record->setObjectName(QString::fromUtf8("G_listWidget_Record"));

        verticalLayout_67->addWidget(G_listWidget_Record);

        horizontalLayout_147 = new QHBoxLayout();
        horizontalLayout_147->setSpacing(6);
        horizontalLayout_147->setObjectName(QString::fromUtf8("horizontalLayout_147"));
        G_pushButton_DelLabelData = new QPushButton(groupBox_36);
        G_pushButton_DelLabelData->setObjectName(QString::fromUtf8("G_pushButton_DelLabelData"));

        horizontalLayout_147->addWidget(G_pushButton_DelLabelData);

        horizontalSpacer_48 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_147->addItem(horizontalSpacer_48);

        G_label_LabelState = new QLabel(groupBox_36);
        G_label_LabelState->setObjectName(QString::fromUtf8("G_label_LabelState"));

        horizontalLayout_147->addWidget(G_label_LabelState);

        horizontalSpacer_46 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_147->addItem(horizontalSpacer_46);

        G_pushButton_Readlabel = new QPushButton(groupBox_36);
        G_pushButton_Readlabel->setObjectName(QString::fromUtf8("G_pushButton_Readlabel"));

        horizontalLayout_147->addWidget(G_pushButton_Readlabel);


        verticalLayout_67->addLayout(horizontalLayout_147);

        horizontalLayout_148 = new QHBoxLayout();
        horizontalLayout_148->setSpacing(6);
        horizontalLayout_148->setObjectName(QString::fromUtf8("horizontalLayout_148"));
        G_lineEdit_Write = new QLineEdit(groupBox_36);
        G_lineEdit_Write->setObjectName(QString::fromUtf8("G_lineEdit_Write"));

        horizontalLayout_148->addWidget(G_lineEdit_Write);

        G_pushButton_WriteLabel = new QPushButton(groupBox_36);
        G_pushButton_WriteLabel->setObjectName(QString::fromUtf8("G_pushButton_WriteLabel"));

        horizontalLayout_148->addWidget(G_pushButton_WriteLabel);


        verticalLayout_67->addLayout(horizontalLayout_148);


        horizontalLayout_149->addLayout(verticalLayout_67);


        horizontalLayout_150->addWidget(groupBox_36);

        horizontalLayout_150->setStretch(0, 1);
        horizontalLayout_150->setStretch(1, 2);

        verticalLayout_68->addLayout(horizontalLayout_150);


        horizontalLayout_151->addLayout(verticalLayout_68);

        tabWidget_G->addTab(tab_5, QString());
        tab_24G_App = new QWidget();
        tab_24G_App->setObjectName(QString::fromUtf8("tab_24G_App"));
        horizontalLayout_121 = new QHBoxLayout(tab_24G_App);
        horizontalLayout_121->setSpacing(6);
        horizontalLayout_121->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_121->setObjectName(QString::fromUtf8("horizontalLayout_121"));
        horizontalLayout_120 = new QHBoxLayout();
        horizontalLayout_120->setSpacing(6);
        horizontalLayout_120->setObjectName(QString::fromUtf8("horizontalLayout_120"));
        groupBox_20 = new QGroupBox(tab_24G_App);
        groupBox_20->setObjectName(QString::fromUtf8("groupBox_20"));
        horizontalLayout_118 = new QHBoxLayout(groupBox_20);
        horizontalLayout_118->setSpacing(6);
        horizontalLayout_118->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_118->setObjectName(QString::fromUtf8("horizontalLayout_118"));
        G_tableWidget_App_In = new QTableWidget(groupBox_20);
        G_tableWidget_App_In->setObjectName(QString::fromUtf8("G_tableWidget_App_In"));

        horizontalLayout_118->addWidget(G_tableWidget_App_In);


        horizontalLayout_120->addWidget(groupBox_20);

        groupBox_21 = new QGroupBox(tab_24G_App);
        groupBox_21->setObjectName(QString::fromUtf8("groupBox_21"));
        horizontalLayout_117 = new QHBoxLayout(groupBox_21);
        horizontalLayout_117->setSpacing(6);
        horizontalLayout_117->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_117->setObjectName(QString::fromUtf8("horizontalLayout_117"));
        G_tableWidget_Storage = new QTableWidget(groupBox_21);
        G_tableWidget_Storage->setObjectName(QString::fromUtf8("G_tableWidget_Storage"));

        horizontalLayout_117->addWidget(G_tableWidget_Storage);


        horizontalLayout_120->addWidget(groupBox_21);


        horizontalLayout_121->addLayout(horizontalLayout_120);

        tabWidget_G->addTab(tab_24G_App, QString());

        horizontalLayout_76->addWidget(tabWidget_G);

        stackedWidget->addWidget(page_2);

        verticalLayout_6->addWidget(stackedWidget);


        horizontalLayout_18->addLayout(verticalLayout_6);


        horizontalLayout_19->addLayout(horizontalLayout_18);

        pushButton_IsShow = new QPushButton(centralWidget);
        pushButton_IsShow->setObjectName(QString::fromUtf8("pushButton_IsShow"));
        sizePolicy.setHeightForWidth(pushButton_IsShow->sizePolicy().hasHeightForWidth());
        pushButton_IsShow->setSizePolicy(sizePolicy);
        pushButton_IsShow->setMinimumSize(QSize(16, 0));
        pushButton_IsShow->setMaximumSize(QSize(16, 16777215));

        horizontalLayout_19->addWidget(pushButton_IsShow);

        Uart_Data = new QGroupBox(centralWidget);
        Uart_Data->setObjectName(QString::fromUtf8("Uart_Data"));
        horizontalLayout_16 = new QHBoxLayout(Uart_Data);
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        comboBox_Show_Mode = new QComboBox(Uart_Data);
        comboBox_Show_Mode->addItem(QString());
        comboBox_Show_Mode->addItem(QString());
        comboBox_Show_Mode->addItem(QString());
        comboBox_Show_Mode->setObjectName(QString::fromUtf8("comboBox_Show_Mode"));

        verticalLayout_5->addWidget(comboBox_Show_Mode);

        textEdit_Data = new QTextEdit(Uart_Data);
        textEdit_Data->setObjectName(QString::fromUtf8("textEdit_Data"));
        textEdit_Data->setFocusPolicy(Qt::WheelFocus);
        textEdit_Data->setTabChangesFocus(false);
        textEdit_Data->setReadOnly(true);
        textEdit_Data->setOverwriteMode(false);

        verticalLayout_5->addWidget(textEdit_Data);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        pushButton_DelData = new QPushButton(Uart_Data);
        pushButton_DelData->setObjectName(QString::fromUtf8("pushButton_DelData"));
        sizePolicy9.setHeightForWidth(pushButton_DelData->sizePolicy().hasHeightForWidth());
        pushButton_DelData->setSizePolicy(sizePolicy9);

        horizontalLayout_15->addWidget(pushButton_DelData);

        pushButton_Rec_Mode = new QPushButton(Uart_Data);
        pushButton_Rec_Mode->setObjectName(QString::fromUtf8("pushButton_Rec_Mode"));

        horizontalLayout_15->addWidget(pushButton_Rec_Mode);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_3);

        label_Rec_Text = new QLabel(Uart_Data);
        label_Rec_Text->setObjectName(QString::fromUtf8("label_Rec_Text"));

        horizontalLayout_15->addWidget(label_Rec_Text);

        label_Rec_Num = new QLabel(Uart_Data);
        label_Rec_Num->setObjectName(QString::fromUtf8("label_Rec_Num"));

        horizontalLayout_15->addWidget(label_Rec_Num);

        label_Send_Text = new QLabel(Uart_Data);
        label_Send_Text->setObjectName(QString::fromUtf8("label_Send_Text"));

        horizontalLayout_15->addWidget(label_Send_Text);

        label_Send_Num = new QLabel(Uart_Data);
        label_Send_Num->setObjectName(QString::fromUtf8("label_Send_Num"));

        horizontalLayout_15->addWidget(label_Send_Num);

        pushButton_DelNum = new QPushButton(Uart_Data);
        pushButton_DelNum->setObjectName(QString::fromUtf8("pushButton_DelNum"));
        sizePolicy9.setHeightForWidth(pushButton_DelNum->sizePolicy().hasHeightForWidth());
        pushButton_DelNum->setSizePolicy(sizePolicy9);

        horizontalLayout_15->addWidget(pushButton_DelNum);


        verticalLayout_5->addLayout(horizontalLayout_15);


        horizontalLayout_16->addLayout(verticalLayout_5);


        horizontalLayout_19->addWidget(Uart_Data);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);
        QObject::connect(pushButton_DelNum, SIGNAL(clicked()), MainWindow, SLOT(Del_Num()));
        QObject::connect(pushButton_Rec_Mode, SIGNAL(clicked()), MainWindow, SLOT(Stop_Rec()));
        QObject::connect(comboBox_Show_Mode, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(Set_Show_Mode()));
        QObject::connect(pushButton_IsShow, SIGNAL(clicked()), MainWindow, SLOT(Show_Data()));
        QObject::connect(pushButton_Open, SIGNAL(clicked()), MainWindow, SLOT(OpenUart_Clicked()));
        QObject::connect(IC_pushButton_Sys_Del, SIGNAL(clicked()), IC_listWidget_Sys_Data, SLOT(clear()));
        QObject::connect(IC_pushButton_Data_Del, SIGNAL(clicked()), IC_listWidget_Data, SLOT(clear()));
        QObject::connect(IC_pushButton_Look_Bign, SIGNAL(clicked()), MainWindow, SLOT(IC_Begin_Look()));
        QObject::connect(pushButton_IDMode, SIGNAL(clicked()), MainWindow, SLOT(Change_ID()));
        QObject::connect(pushButton_ICMode, SIGNAL(clicked()), MainWindow, SLOT(Change_IC()));
        QObject::connect(IC_pushButton_Pass_Save, SIGNAL(clicked()), MainWindow, SLOT(IC_Pass_Change()));
        QObject::connect(IC_pushButton_Sys_Read, SIGNAL(clicked()), MainWindow, SLOT(IC_Read_Region()));
        QObject::connect(IC_pushButton_Sys_Write, SIGNAL(clicked()), MainWindow, SLOT(IC_Write_Region()));
        QObject::connect(pushButton_DelData, SIGNAL(clicked()), textEdit_Data, SLOT(clear()));
        QObject::connect(tabWidget_IC, SIGNAL(currentChanged(int)), MainWindow, SLOT(Mode_Change()));
        QObject::connect(IC_pushButton_Mess, SIGNAL(clicked()), MainWindow, SLOT(IC_Read_Mess_flag()));
        QObject::connect(IC_pushButton_Up, SIGNAL(clicked()), MainWindow, SLOT(Money_Up()));
        QObject::connect(IC_pushButton_Down, SIGNAL(clicked()), MainWindow, SLOT(Down_Money_Save()));
        QObject::connect(ETC_pushButton_Look, SIGNAL(clicked()), MainWindow, SLOT(ETC_Look_Begin()));
        QObject::connect(pushButton_ETCMode, SIGNAL(clicked()), MainWindow, SLOT(Change_ETC()));
        QObject::connect(ETC_pushButton_Del_Look, SIGNAL(clicked()), MainWindow, SLOT(Del_Look_Data()));
        QObject::connect(tabWidget_ETC, SIGNAL(currentChanged(int)), MainWindow, SLOT(ETC_Change_Mode()));
        QObject::connect(ID_pushButton_Save, SIGNAL(clicked()), MainWindow, SLOT(Time_Save()));
        QObject::connect(tabWidget_ID, SIGNAL(currentChanged(int)), MainWindow, SLOT(ID_Change_Mode()));
        QObject::connect(ID_radioButton_EM4100, SIGNAL(clicked()), MainWindow, SLOT(ID_EM4100()));
        QObject::connect(ID_radioButton_T5557, SIGNAL(clicked()), MainWindow, SLOT(ID_EM4100()));
        QObject::connect(ID_pushButton_Read_Card, SIGNAL(clicked()), MainWindow, SLOT(ID_Read_Card()));
        QObject::connect(ID_pushButton_Del, SIGNAL(clicked()), ID_listWidget_Card_Data, SLOT(clear()));
        QObject::connect(ID_pushButton_Write_Card, SIGNAL(clicked()), MainWindow, SLOT(ID_Write_Card()));
        QObject::connect(ETC_pushButton_Region_Get, SIGNAL(clicked()), MainWindow, SLOT(ETC_Get_Region()));
        QObject::connect(ETC_pushButton_RF_Get, SIGNAL(clicked()), MainWindow, SLOT(ETC_Get_RF()));
        QObject::connect(ETC_pushButton_TxLv_Get, SIGNAL(clicked()), MainWindow, SLOT(ETC_Get_TxLv()));
        QObject::connect(ETC_pushButton_RSSI_Get, SIGNAL(clicked()), MainWindow, SLOT(ETC_Get_RSSI()));
        QObject::connect(ETC_pushButton_Region_Set, SIGNAL(clicked()), MainWindow, SLOT(ETC_Set_Region()));
        QObject::connect(ETC_pushButton_RF_Set, SIGNAL(clicked()), MainWindow, SLOT(ETC_Set_RF()));
        QObject::connect(ETC_pushButton_Del_Data, SIGNAL(clicked()), ETC_listWidget_Data, SLOT(clear()));
        QObject::connect(ETC_pushButton_TxLv_Set, SIGNAL(clicked()), MainWindow, SLOT(ETC_Set_TxLv()));
        QObject::connect(ETC_pushButton_Read, SIGNAL(clicked()), MainWindow, SLOT(ETC_Read_Data()));
        QObject::connect(ETC_pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(ETC_Write_Data()));
        QObject::connect(ETC_comboBox_Momery, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(ETC_Momery_Change()));
        QObject::connect(IC_pushButton_App_Ticket, SIGNAL(clicked()), MainWindow, SLOT(IC_App_Ticket_Save()));
        QObject::connect(IC_pushButton_App_Up_Money, SIGNAL(clicked()), MainWindow, SLOT(IC_App_Up_Money()));
        QObject::connect(pushButton_ZigBeeMode, SIGNAL(clicked()), MainWindow, SLOT(Change_24G()));
        QObject::connect(ETC_pushButton_A_Up_Money, SIGNAL(clicked()), MainWindow, SLOT(ETC_A_Up_Money()));
        QObject::connect(ETC_pushButton_A_Down_Money, SIGNAL(clicked()), MainWindow, SLOT(ETC_A_Down_Money()));
        QObject::connect(ETC_pushButton_APP_Del, SIGNAL(clicked()), ETC_listWidget_App_Data, SLOT(clear()));
        QObject::connect(ETC_pushButton_A_Del_Data, SIGNAL(clicked()), ETC_listWidget_A_Data, SLOT(clear()));
        QObject::connect(ETC_pushButton_ON, SIGNAL(clicked()), MainWindow, SLOT(ETC_B_Up_Handrail()));
        QObject::connect(ETC_pushButton_OFF, SIGNAL(clicked()), MainWindow, SLOT(ETC_B_Down_Handrail()));
        QObject::connect(ETC_pushButton_Money_Save, SIGNAL(clicked()), MainWindow, SLOT(ETC_B_Price_Save()));
        QObject::connect(ETC_pushButton_Open, SIGNAL(clicked()), MainWindow, SLOT(ETC_B_Handrail_AllOpen()));
        QObject::connect(ETC_pushButton_Up, SIGNAL(clicked()), MainWindow, SLOT(ETC_B_Up_Money()));
        QObject::connect(ETC_pushButton_B_Del_Uaer, SIGNAL(clicked()), MainWindow, SLOT(ETC_B_Del_User()));
        QObject::connect(tabWidget_G, SIGNAL(currentChanged(int)), MainWindow, SLOT(G_Change_Mode()));
        QObject::connect(IC_pushButton_App_Del_Data, SIGNAL(clicked()), IC_listWidget_App_Data, SLOT(clear()));
        QObject::connect(IC_pushButton_Ticket_Reset, SIGNAL(clicked()), MainWindow, SLOT(IC_Ticket_Reset()));
        QObject::connect(IC_radioButton_Out, SIGNAL(toggled(bool)), MainWindow, SLOT(IC_Switch_Mode()));
        QObject::connect(IC_pushButton_Pass_oK, SIGNAL(clicked()), MainWindow, SLOT(IC_Change_Pass()));
        QObject::connect(ETC_radioButton_App_Down, SIGNAL(toggled(bool)), MainWindow, SLOT(ETC_B_Mode()));
        QObject::connect(ETC_radioButton_App_Up, SIGNAL(toggled(bool)), MainWindow, SLOT(ETC_B_Mode()));
        QObject::connect(pushButton_3, SIGNAL(clicked()), MainWindow, SLOT(About_up()));
        QObject::connect(G_pushButton_Read, SIGNAL(clicked()), MainWindow, SLOT(G_Read_Panid()));
        QObject::connect(G_pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(G_Write_Panid()));
        QObject::connect(G_pushButton_ReadData, SIGNAL(clicked()), MainWindow, SLOT(G_Read_Data()));
        QObject::connect(G_pushButton_WriteData, SIGNAL(clicked()), MainWindow, SLOT(G_Write_Data()));
        QObject::connect(G_pushButton_DelData, SIGNAL(clicked(bool)), G_listWidget_Data, SLOT(clear()));
        QObject::connect(G_tableWidget_App_In, SIGNAL(itemSelectionChanged()), MainWindow, SLOT(G_Get_Row()));
        QObject::connect(IC_pushButton_Look_Del, SIGNAL(clicked(bool)), MainWindow, SLOT(IC_Del_Card()));
        QObject::connect(IC_pushButton_one, SIGNAL(clicked(bool)), MainWindow, SLOT(IC_Send_Look()));
        QObject::connect(ETC_pushButton_one, SIGNAL(clicked(bool)), MainWindow, SLOT(ETC_One_Look()));
        QObject::connect(G_pushButton_LookCard, SIGNAL(clicked(bool)), MainWindow, SLOT(G_Look_Card()));
        QObject::connect(G_pushButton_Readlabel, SIGNAL(clicked(bool)), MainWindow, SLOT(G_Read_CardData()));
        QObject::connect(G_pushButton_WriteLabel, SIGNAL(clicked(bool)), MainWindow, SLOT(G_Write_CardData()));
        QObject::connect(G_pushButton_DelLabel, SIGNAL(clicked(bool)), MainWindow, SLOT(G_Del_Cargo()));
        QObject::connect(G_pushButton_DelLabelData, SIGNAL(clicked(bool)), G_listWidget_Record, SLOT(clear()));
        QObject::connect(G_pushButton_ReadRead, SIGNAL(clicked(bool)), MainWindow, SLOT(G_Read_Panid()));
        QObject::connect(G_pushButton_ReadWrite, SIGNAL(clicked(bool)), MainWindow, SLOT(G_Write_Panid()));

        stackedWidget->setCurrentIndex(0);
        tabWidget_ID->setCurrentIndex(0);
        tabWidget_IC->setCurrentIndex(0);
        IC_comboBox_Pass_Regic->setCurrentIndex(0);
        tabWidget_ETC->setCurrentIndex(0);
        ETC_comboBox_Region->setCurrentIndex(6);
        tabWidget_G->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "RFIDDemo", nullptr));
        label_20->setText(QString());
        pushButton_IDMode->setText(QApplication::translate("MainWindow", "ID\345\215\241", nullptr));
        pushButton_ICMode->setText(QApplication::translate("MainWindow", "IC\345\215\241", nullptr));
        pushButton_ETCMode->setText(QApplication::translate("MainWindow", "\350\266\205\351\253\230\351\242\221900M", nullptr));
        pushButton_ZigBeeMode->setText(QApplication::translate("MainWindow", "\345\276\256\346\263\2422.4G", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "\347\211\210\346\234\254\346\233\264\346\226\260", nullptr));
        groupBox->setTitle(QApplication::translate("MainWindow", "\344\270\262\345\217\243\350\256\276\347\275\256", nullptr));
        label_Com->setText(QApplication::translate("MainWindow", "\344\270\262\345\217\243\345\217\267\357\274\232", nullptr));
        label_Baud->setText(QApplication::translate("MainWindow", "\346\263\242\347\211\271\347\216\207\357\274\232", nullptr));
        comboBox_Baud->setItemText(0, QApplication::translate("MainWindow", "1200", nullptr));
        comboBox_Baud->setItemText(1, QApplication::translate("MainWindow", "2400", nullptr));
        comboBox_Baud->setItemText(2, QApplication::translate("MainWindow", "4800", nullptr));
        comboBox_Baud->setItemText(3, QApplication::translate("MainWindow", "9600", nullptr));
        comboBox_Baud->setItemText(4, QApplication::translate("MainWindow", "19200", nullptr));
        comboBox_Baud->setItemText(5, QApplication::translate("MainWindow", "38400", nullptr));
        comboBox_Baud->setItemText(6, QApplication::translate("MainWindow", "57600", nullptr));
        comboBox_Baud->setItemText(7, QApplication::translate("MainWindow", "115200", nullptr));

        pushButton_Open->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\243", nullptr));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "\345\275\223\345\211\215\346\227\266\351\227\264", nullptr));
        label_Time->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:20pt;\">TextLabel</span></p></body></html>", nullptr));
        groupBox_23->setTitle(QApplication::translate("MainWindow", "\345\215\241\347\261\273\345\236\213\351\200\211\346\213\251", nullptr));
        ID_radioButton_EM4100->setText(QApplication::translate("MainWindow", "EM4100", nullptr));
        ID_radioButton_T5557->setText(QApplication::translate("MainWindow", "T5577", nullptr));
        groupBox_25->setTitle(QApplication::translate("MainWindow", "\346\263\250\346\204\217", nullptr));
        label_32->setText(QApplication::translate("MainWindow", "<html><head/><body><p>T5577\347\261\273\345\236\213\346\226\260\345\215\241\351\234\200\350\246\201\345\205\210\345\206\231\345\205\245\345\215\241\345\217\267\357\274\201\345\220\246\345\210\231\345\260\206\350\257\273\345\217\226\345\244\261\350\264\245\357\274\201</p></body></html>", nullptr));
        groupBox_24->setTitle(QApplication::translate("MainWindow", "\346\223\215\344\275\234\350\256\260\345\275\225", nullptr));
        ID_pushButton_Del->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        ID_label_State->setText(QString());
        ID_pushButton_Read_Card->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226\345\215\241\345\217\267", nullptr));
        ID_lineEdit_Write->setText(QApplication::translate("MainWindow", "0001020304", nullptr));
        ID_pushButton_Write_Card->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245\345\215\241\345\217\267", nullptr));
        tabWidget_ID->setTabText(tabWidget_ID->indexOf(tab), QApplication::translate("MainWindow", "\345\237\272\347\241\200", nullptr));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "\346\227\266\351\227\264\350\256\276\347\275\256", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "\344\270\212\345\215\210", nullptr));
        label->setText(QApplication::translate("MainWindow", "\350\207\263", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "\344\270\213\345\215\210", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "\350\207\263", nullptr));
        ID_pushButton_Save->setText(QApplication::translate("MainWindow", "\344\277\235\345\255\230", nullptr));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "\345\221\230\345\267\245\345\210\227\350\241\250", nullptr));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "\350\200\203\345\213\244\346\203\205\345\206\265", nullptr));
        tabWidget_ID->setTabText(tabWidget_ID->indexOf(tab_2), QApplication::translate("MainWindow", "\345\272\224\347\224\250*", nullptr));
        groupBox_10->setTitle(QApplication::translate("MainWindow", "\344\277\256\346\224\271\345\257\206\351\222\245", nullptr));
        label_51->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\211\207\345\214\272\357\274\232</p></body></html>", nullptr));
        label_14->setText(QApplication::translate("MainWindow", "\345\257\206\351\222\245\351\200\211\346\213\251\357\274\232", nullptr));
        label_13->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\216\237\345\257\206\351\222\245\357\274\232</p></body></html>", nullptr));
        label_15->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\226\260\345\257\206\351\222\245\357\274\232</p></body></html>", nullptr));
        IC_comboBox_Pass_Regic->setItemText(0, QApplication::translate("MainWindow", "0", nullptr));
        IC_comboBox_Pass_Regic->setItemText(1, QApplication::translate("MainWindow", "1", nullptr));
        IC_comboBox_Pass_Regic->setItemText(2, QApplication::translate("MainWindow", "2", nullptr));
        IC_comboBox_Pass_Regic->setItemText(3, QApplication::translate("MainWindow", "3", nullptr));
        IC_comboBox_Pass_Regic->setItemText(4, QApplication::translate("MainWindow", "4", nullptr));
        IC_comboBox_Pass_Regic->setItemText(5, QApplication::translate("MainWindow", "5", nullptr));
        IC_comboBox_Pass_Regic->setItemText(6, QApplication::translate("MainWindow", "6", nullptr));
        IC_comboBox_Pass_Regic->setItemText(7, QApplication::translate("MainWindow", "7", nullptr));
        IC_comboBox_Pass_Regic->setItemText(8, QApplication::translate("MainWindow", "8", nullptr));
        IC_comboBox_Pass_Regic->setItemText(9, QApplication::translate("MainWindow", "9", nullptr));
        IC_comboBox_Pass_Regic->setItemText(10, QApplication::translate("MainWindow", "10", nullptr));
        IC_comboBox_Pass_Regic->setItemText(11, QApplication::translate("MainWindow", "11", nullptr));
        IC_comboBox_Pass_Regic->setItemText(12, QApplication::translate("MainWindow", "12", nullptr));
        IC_comboBox_Pass_Regic->setItemText(13, QApplication::translate("MainWindow", "13", nullptr));
        IC_comboBox_Pass_Regic->setItemText(14, QApplication::translate("MainWindow", "14", nullptr));
        IC_comboBox_Pass_Regic->setItemText(15, QApplication::translate("MainWindow", "15", nullptr));

        IC_radioButton_Pass_A->setText(QApplication::translate("MainWindow", "\345\257\206\351\222\245A", nullptr));
        IC_radioButton_Pass_B->setText(QApplication::translate("MainWindow", "\345\257\206\351\222\245B", nullptr));
        IC_lineEdit_Pass_Last->setText(QApplication::translate("MainWindow", "FFFFFFFFFFFF", nullptr));
        IC_lineEdit_Pass_New->setText(QApplication::translate("MainWindow", "FFFFFFFFFFFF", nullptr));
        IC_label_Pass_State->setText(QString());
        IC_pushButton_Pass_Save->setText(QApplication::translate("MainWindow", "\344\277\256\346\224\271", nullptr));
        groupBox_12->setTitle(QApplication::translate("MainWindow", "\345\257\273\345\215\241\346\223\215\344\275\234", nullptr));
        IC_pushButton_Look_Del->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        IC_pushButton_one->setText(QApplication::translate("MainWindow", "\345\215\225\346\254\241\345\257\273\345\215\241", nullptr));
        IC_pushButton_Look_Bign->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213\345\257\273\345\215\241", nullptr));
        groupBox_9->setTitle(QApplication::translate("MainWindow", "\347\263\273\347\273\237\345\235\227\350\257\273\345\206\231", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\211\207\345\214\272\357\274\232</p></body></html>", nullptr));
        label_30->setText(QApplication::translate("MainWindow", "\345\257\206\351\222\245\351\200\211\346\213\251\357\274\232", nullptr));
        IC_comboBox_Sys_Region->setItemText(0, QApplication::translate("MainWindow", "0", nullptr));
        IC_comboBox_Sys_Region->setItemText(1, QApplication::translate("MainWindow", "1", nullptr));
        IC_comboBox_Sys_Region->setItemText(2, QApplication::translate("MainWindow", "2", nullptr));
        IC_comboBox_Sys_Region->setItemText(3, QApplication::translate("MainWindow", "3", nullptr));
        IC_comboBox_Sys_Region->setItemText(4, QApplication::translate("MainWindow", "4", nullptr));
        IC_comboBox_Sys_Region->setItemText(5, QApplication::translate("MainWindow", "5", nullptr));
        IC_comboBox_Sys_Region->setItemText(6, QApplication::translate("MainWindow", "6", nullptr));
        IC_comboBox_Sys_Region->setItemText(7, QApplication::translate("MainWindow", "7", nullptr));
        IC_comboBox_Sys_Region->setItemText(8, QApplication::translate("MainWindow", "8", nullptr));
        IC_comboBox_Sys_Region->setItemText(9, QApplication::translate("MainWindow", "9", nullptr));
        IC_comboBox_Sys_Region->setItemText(10, QApplication::translate("MainWindow", "10", nullptr));
        IC_comboBox_Sys_Region->setItemText(11, QApplication::translate("MainWindow", "11", nullptr));
        IC_comboBox_Sys_Region->setItemText(12, QApplication::translate("MainWindow", "12", nullptr));
        IC_comboBox_Sys_Region->setItemText(13, QApplication::translate("MainWindow", "13", nullptr));
        IC_comboBox_Sys_Region->setItemText(14, QApplication::translate("MainWindow", "14", nullptr));
        IC_comboBox_Sys_Region->setItemText(15, QApplication::translate("MainWindow", "15", nullptr));

        IC_comboBox_Sys_Region->setCurrentText(QApplication::translate("MainWindow", "0", nullptr));
        IC_comboBox_passMode->setItemText(0, QApplication::translate("MainWindow", "\345\257\206\351\222\245A", nullptr));
        IC_comboBox_passMode->setItemText(1, QApplication::translate("MainWindow", "\345\257\206\351\222\245B", nullptr));

        label_12->setText(QApplication::translate("MainWindow", "\345\235\227\347\274\226\345\217\267\357\274\232", nullptr));
        label_16->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\257\206\351\222\245\357\274\232</p></body></html>", nullptr));
        IC_comboBox_Sys_Lump->setItemText(0, QApplication::translate("MainWindow", "0", nullptr));
        IC_comboBox_Sys_Lump->setItemText(1, QApplication::translate("MainWindow", "1", nullptr));
        IC_comboBox_Sys_Lump->setItemText(2, QApplication::translate("MainWindow", "2", nullptr));
        IC_comboBox_Sys_Lump->setItemText(3, QApplication::translate("MainWindow", "3", nullptr));

        IC_comboBox_Sys_Lump->setCurrentText(QApplication::translate("MainWindow", "0", nullptr));
        IC_lineEdit_Sys_Pass->setText(QApplication::translate("MainWindow", "FFFFFFFFFFFF", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226\344\277\241\346\201\257\357\274\232", nullptr));
        IC_pushButton_Sys_Del->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        IC_label_Data_State->setText(QString());
        IC_lineEdit_Sys_Write->setText(QApplication::translate("MainWindow", "00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15", nullptr));
        IC_pushButton_Sys_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        IC_pushButton_Sys_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        tabWidget_IC->setTabText(tabWidget_IC->indexOf(tab_Basics), QApplication::translate("MainWindow", "\345\237\272\347\241\200", nullptr));
        groupBox_8->setTitle(QApplication::translate("MainWindow", "\345\215\241\344\277\241\346\201\257", nullptr));
        label_17->setText(QApplication::translate("MainWindow", "\346\211\207\345\214\2721\345\257\206\351\222\245A\357\274\232", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\215\241\345\217\267\357\274\232</p></body></html>", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\344\275\231\351\242\235\357\274\232</p></body></html>", nullptr));
        IC_lineEdit_Mess_Pass->setText(QApplication::translate("MainWindow", "FFFFFFFFFFFF", nullptr));
        IC_pushButton_Mess->setText(QApplication::translate("MainWindow", "\347\241\256\345\256\232", nullptr));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "\345\205\205\345\200\274", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274\351\207\221\351\242\235\357\274\232", nullptr));
        IC_lineEdit_Up_Money->setText(QApplication::translate("MainWindow", "100", nullptr));
        IC_pushButton_Up->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274", nullptr));
        label_5->setText(QString());
        groupBox_7->setTitle(QApplication::translate("MainWindow", "\346\266\210\350\264\271", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "\346\266\210\350\264\271\351\207\221\351\242\235\357\274\232", nullptr));
        IC_lineEdit_Down_Money->setText(QApplication::translate("MainWindow", "10", nullptr));
        IC_pushButton_Down->setText(QApplication::translate("MainWindow", "\346\266\210\350\264\271", nullptr));
        groupBox_11->setTitle(QApplication::translate("MainWindow", "\346\223\215\344\275\234\350\256\260\345\275\225", nullptr));
        IC_pushButton_Data_Del->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        tabWidget_IC->setTabText(tabWidget_IC->indexOf(tab_App), QApplication::translate("MainWindow", "\345\215\241\351\222\261\345\214\205", nullptr));
        groupBox_26->setTitle(QApplication::translate("MainWindow", "\347\224\250\346\210\267\344\277\241\346\201\257", nullptr));
        label_34->setText(QApplication::translate("MainWindow", "\345\215\241\345\217\267\357\274\232", nullptr));
        label_35->setText(QApplication::translate("MainWindow", "\344\275\231\351\242\235\357\274\232", nullptr));
        IC_label_Pass_Text->setText(QApplication::translate("MainWindow", "\345\257\206\347\240\201A\357\274\232", nullptr));
        IC_lineEdit_Pass->setText(QApplication::translate("MainWindow", "FFFFFFFFFFFF", nullptr));
        IC_pushButton_Pass_oK->setText(QApplication::translate("MainWindow", "\347\241\256\350\256\244", nullptr));
        groupBox_41->setTitle(QApplication::translate("MainWindow", "\346\250\241\345\274\217\350\256\276\347\275\256", nullptr));
        IC_radioButton_Out->setText(QApplication::translate("MainWindow", "\344\271\230\350\275\246\346\250\241\345\274\217", nullptr));
        IC_radioButton_In->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274\346\250\241\345\274\217", nullptr));
        groupBox_28->setTitle(QApplication::translate("MainWindow", "\347\245\250\344\273\267\350\256\276\347\275\256", nullptr));
        label_38->setText(QApplication::translate("MainWindow", "\345\275\223\345\211\215\347\245\250\344\273\267", nullptr));
        IC_lineEdit_App_Ticket->setText(QApplication::translate("MainWindow", "10", nullptr));
        IC_pushButton_App_Ticket->setText(QApplication::translate("MainWindow", "\344\277\235\345\255\230", nullptr));
        groupBox_27->setTitle(QApplication::translate("MainWindow", "\345\205\205\345\200\274\346\223\215\344\275\234", nullptr));
        label_37->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274\351\207\221\351\242\235", nullptr));
        IC_lineEdit_App_Up_Money->setText(QApplication::translate("MainWindow", "100", nullptr));
        IC_pushButton_App_Up_Money->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274", nullptr));
        groupBox_29->setTitle(QApplication::translate("MainWindow", "\345\224\256\347\245\250\351\207\221\351\242\235", nullptr));
        IC_label_Head_Money->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">0</span></p></body></html>", nullptr));
        groupBox_30->setTitle(QApplication::translate("MainWindow", "\346\223\215\344\275\234\350\256\260\345\275\225", nullptr));
        IC_pushButton_Ticket_Reset->setText(QApplication::translate("MainWindow", "\345\224\256\347\245\250\351\207\221\351\242\235\345\244\215\344\275\215", nullptr));
        IC_pushButton_App_Del_Data->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        tabWidget_IC->setTabText(tabWidget_IC->indexOf(tab_3), QApplication::translate("MainWindow", "\345\272\224\347\224\250*", nullptr));
        groupBox_31->setTitle(QApplication::translate("MainWindow", "\345\234\260\345\214\272\350\256\276\347\275\256", nullptr));
        label_36->setText(QApplication::translate("MainWindow", "\345\234\260\345\214\272\357\274\232", nullptr));
        ETC_comboBox_Region->setItemText(0, QApplication::translate("MainWindow", "\351\237\251\345\233\275", nullptr));
        ETC_comboBox_Region->setItemText(1, QApplication::translate("MainWindow", "\347\276\216\345\233\2751", nullptr));
        ETC_comboBox_Region->setItemText(2, QApplication::translate("MainWindow", "\347\276\216\345\233\2752", nullptr));
        ETC_comboBox_Region->setItemText(3, QApplication::translate("MainWindow", "\346\254\247\346\264\262", nullptr));
        ETC_comboBox_Region->setItemText(4, QApplication::translate("MainWindow", "\346\227\245\346\234\254", nullptr));
        ETC_comboBox_Region->setItemText(5, QApplication::translate("MainWindow", "\344\270\255\345\233\2751", nullptr));
        ETC_comboBox_Region->setItemText(6, QApplication::translate("MainWindow", "\344\270\255\345\233\2752", nullptr));

        ETC_pushButton_Region_Get->setText(QApplication::translate("MainWindow", "\350\216\267\345\217\226", nullptr));
        ETC_label_Region_State->setText(QString());
        ETC_pushButton_Region_Set->setText(QApplication::translate("MainWindow", "\350\256\276\347\275\256", nullptr));
        groupBox_33->setTitle(QApplication::translate("MainWindow", "RF\351\242\221\351\201\223\350\256\276\347\275\256", nullptr));
        label_41->setText(QApplication::translate("MainWindow", "RF\351\242\221\351\201\223\357\274\232", nullptr));
        ETC_comboBox_RF->setItemText(0, QApplication::translate("MainWindow", "1", nullptr));
        ETC_comboBox_RF->setItemText(1, QApplication::translate("MainWindow", "2", nullptr));
        ETC_comboBox_RF->setItemText(2, QApplication::translate("MainWindow", "3", nullptr));
        ETC_comboBox_RF->setItemText(3, QApplication::translate("MainWindow", "4", nullptr));
        ETC_comboBox_RF->setItemText(4, QApplication::translate("MainWindow", "5", nullptr));
        ETC_comboBox_RF->setItemText(5, QApplication::translate("MainWindow", "6", nullptr));
        ETC_comboBox_RF->setItemText(6, QApplication::translate("MainWindow", "7", nullptr));
        ETC_comboBox_RF->setItemText(7, QApplication::translate("MainWindow", "8", nullptr));
        ETC_comboBox_RF->setItemText(8, QApplication::translate("MainWindow", "9", nullptr));
        ETC_comboBox_RF->setItemText(9, QApplication::translate("MainWindow", "10", nullptr));
        ETC_comboBox_RF->setItemText(10, QApplication::translate("MainWindow", "11", nullptr));
        ETC_comboBox_RF->setItemText(11, QApplication::translate("MainWindow", "12", nullptr));
        ETC_comboBox_RF->setItemText(12, QApplication::translate("MainWindow", "13", nullptr));
        ETC_comboBox_RF->setItemText(13, QApplication::translate("MainWindow", "14", nullptr));
        ETC_comboBox_RF->setItemText(14, QApplication::translate("MainWindow", "15", nullptr));
        ETC_comboBox_RF->setItemText(15, QApplication::translate("MainWindow", "16", nullptr));
        ETC_comboBox_RF->setItemText(16, QApplication::translate("MainWindow", "17", nullptr));
        ETC_comboBox_RF->setItemText(17, QApplication::translate("MainWindow", "18", nullptr));
        ETC_comboBox_RF->setItemText(18, QApplication::translate("MainWindow", "19", nullptr));
        ETC_comboBox_RF->setItemText(19, QApplication::translate("MainWindow", "20", nullptr));

        ETC_pushButton_RF_Get->setText(QApplication::translate("MainWindow", "\350\216\267\345\217\226", nullptr));
        ETC_label_RF_State->setText(QString());
        ETC_pushButton_RF_Set->setText(QApplication::translate("MainWindow", "\350\256\276\347\275\256", nullptr));
        groupBox_34->setTitle(QApplication::translate("MainWindow", "Tx\345\212\237\347\216\207\350\256\276\347\275\256", nullptr));
        label_40->setText(QApplication::translate("MainWindow", "Tx\345\212\237\347\216\207\357\274\232", nullptr));
        ETC_lineEdit_TxLv->setPlaceholderText(QApplication::translate("MainWindow", "18.0-25.0", nullptr));
        label_46->setText(QApplication::translate("MainWindow", "dBm ", nullptr));
        ETC_pushButton_TxLv_Get->setText(QApplication::translate("MainWindow", "\350\216\267\345\217\226", nullptr));
        ETC_label_TxLv_State->setText(QString());
        ETC_pushButton_TxLv_Set->setText(QApplication::translate("MainWindow", "\350\256\276\347\275\256", nullptr));
        groupBox_32->setTitle(QApplication::translate("MainWindow", "\345\205\266\344\273\226\344\277\241\346\201\257", nullptr));
        label_42->setText(QApplication::translate("MainWindow", "RSSI\357\274\232-", nullptr));
        label_44->setText(QApplication::translate("MainWindow", "dBm", nullptr));
        ETC_pushButton_RSSI_Get->setText(QApplication::translate("MainWindow", "\350\216\267\345\217\226", nullptr));
        groupBox_13->setTitle(QApplication::translate("MainWindow", "\345\257\273\345\215\241\346\223\215\344\275\234", nullptr));
        ETC_pushButton_Del_Look->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        ETC_pushButton_one->setText(QApplication::translate("MainWindow", "\345\215\225\346\254\241\345\257\273\345\215\241", nullptr));
        ETC_pushButton_Look->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213\345\257\273\345\215\241", nullptr));
        groupBox_14->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\350\257\273\345\206\231", nullptr));
        label_21->setText(QApplication::translate("MainWindow", "\345\215\241\345\217\267\357\274\232", nullptr));
#ifndef QT_NO_TOOLTIP
        ETC_comboBox_Card_Num->setToolTip(QApplication::translate("MainWindow", "\345\274\200\345\247\213\345\257\273\345\215\241\345\220\216\350\207\252\345\212\250\346\267\273\345\212\240", nullptr));
#endif // QT_NO_TOOLTIP
        ETC_comboBox_Card_Num->setCurrentText(QString());
        label_45->setText(QApplication::translate("MainWindow", "\345\206\205\345\255\230\345\214\272\345\237\237\357\274\232", nullptr));
        ETC_comboBox_Momery->setItemText(0, QApplication::translate("MainWindow", "RFU(\344\277\235\347\225\231\345\214\272)", nullptr));
        ETC_comboBox_Momery->setItemText(1, QApplication::translate("MainWindow", "EPC(EPC\345\214\272)", nullptr));
        ETC_comboBox_Momery->setItemText(2, QApplication::translate("MainWindow", "TID(TID\345\214\272)", nullptr));
        ETC_comboBox_Momery->setItemText(3, QApplication::translate("MainWindow", "USER(\347\224\250\346\210\267\345\214\272)", nullptr));

        label_22->setText(QApplication::translate("MainWindow", "\350\265\267\345\247\213\350\257\273\345\217\226\345\234\260\345\235\200\357\274\232", nullptr));
        ETC_lineEdit_Start_Add->setText(QApplication::translate("MainWindow", "0", nullptr));
        label_23->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226\351\225\277\345\272\246\357\274\232", nullptr));
        ETC_lineEdit_ReadLength->setText(QApplication::translate("MainWindow", "4", nullptr));
        label_24->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226\344\277\241\346\201\257", nullptr));
        ETC_pushButton_Del_Data->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        ETC_label_Data_State->setText(QString());
        ETC_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        label_47->setText(QApplication::translate("MainWindow", "\350\265\267\345\247\213\345\206\231\345\205\245\345\234\260\345\235\200\357\274\232", nullptr));
        ETC_lineEdit_Write_Add->setText(QApplication::translate("MainWindow", "0", nullptr));
        label_48->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245\351\225\277\345\272\246\357\274\232", nullptr));
        ETC_lineEdit_Write_Length->setPlaceholderText(QApplication::translate("MainWindow", "\350\207\252\345\212\250\350\256\241\347\256\227", nullptr));
        ETC_lineEdit_WriteData->setText(QApplication::translate("MainWindow", "00 01 02 03 04 05 06 07", nullptr));
        ETC_lineEdit_WriteData->setPlaceholderText(QApplication::translate("MainWindow", "\344\270\215\350\266\263\344\270\200\344\270\252\346\225\260\346\215\256\351\225\277\345\272\246(16Bit)\345\260\206\350\207\252\345\212\250\350\241\2450", nullptr));
        ETC_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        tabWidget_ETC->setTabText(tabWidget_ETC->indexOf(tab_ETC_Basics), QApplication::translate("MainWindow", "\345\237\272\347\241\200", nullptr));
        groupBox_37->setTitle(QApplication::translate("MainWindow", "\345\215\241\344\277\241\346\201\257", nullptr));
        label_52->setText(QApplication::translate("MainWindow", "\345\215\241\345\217\267\357\274\232", nullptr));
        label_53->setText(QApplication::translate("MainWindow", "\344\275\231\351\242\235\357\274\232", nullptr));
        groupBox_38->setTitle(QApplication::translate("MainWindow", "\345\205\205\345\200\274\346\223\215\344\275\234", nullptr));
        label_54->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274\351\207\221\351\242\235\357\274\232", nullptr));
        ETC_lineEdit_A_Up_Money->setText(QApplication::translate("MainWindow", "100", nullptr));
        ETC_pushButton_A_Up_Money->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274", nullptr));
        groupBox_39->setTitle(QApplication::translate("MainWindow", "\346\211\243\350\264\271\346\223\215\344\275\234", nullptr));
        label_55->setText(QApplication::translate("MainWindow", "\346\211\243\350\264\271\351\207\221\351\242\235\357\274\232", nullptr));
        ETC_lineEdit_A_Down_Money->setText(QApplication::translate("MainWindow", "10", nullptr));
        ETC_pushButton_A_Down_Money->setText(QApplication::translate("MainWindow", "\346\211\243\350\264\271", nullptr));
        groupBox_40->setTitle(QApplication::translate("MainWindow", "\346\223\215\344\275\234\350\256\260\345\275\225", nullptr));
        ETC_pushButton_A_Del_Data->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        tabWidget_ETC->setTabText(tabWidget_ETC->indexOf(tab_4), QApplication::translate("MainWindow", "\345\215\241\351\222\261\345\214\205", nullptr));
        groupBox_15->setTitle(QApplication::translate("MainWindow", "\347\224\250\346\210\267\344\277\241\346\201\257", nullptr));
        label_25->setText(QApplication::translate("MainWindow", "\345\215\241\345\217\267\357\274\232", nullptr));
        ETC_lineEdit_Mess_Card->setText(QString());
        label_26->setText(QApplication::translate("MainWindow", "\344\275\231\351\242\235\357\274\232", nullptr));
        groupBox_42->setTitle(QApplication::translate("MainWindow", "\346\250\241\345\274\217\351\200\211\346\213\251", nullptr));
        ETC_radioButton_App_Down->setText(QApplication::translate("MainWindow", "\346\266\210\350\264\271\346\250\241\345\274\217", nullptr));
        ETC_radioButton_App_Up->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274\346\250\241\345\274\217", nullptr));
        groupBox_18->setTitle(QApplication::translate("MainWindow", "\345\205\205\345\200\274\346\223\215\344\275\234", nullptr));
        label_28->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274\351\207\221\351\242\235", nullptr));
        ETC_lineEdit_Up_Money->setText(QApplication::translate("MainWindow", "100", nullptr));
        ETC_pushButton_Up->setText(QApplication::translate("MainWindow", "\345\205\205\345\200\274", nullptr));
        groupBox_16->setTitle(QApplication::translate("MainWindow", "\346\223\215\344\275\234\350\256\260\345\275\225", nullptr));
        ETC_pushButton_B_Del_Uaer->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244\347\224\250\346\210\267\344\277\241\346\201\257", nullptr));
        ETC_pushButton_APP_Del->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244\346\223\215\344\275\234\350\256\260\345\275\225", nullptr));
        groupBox_17->setTitle(QApplication::translate("MainWindow", "\346\224\266\350\264\271\346\223\215\344\275\234", nullptr));
        label_29->setText(QApplication::translate("MainWindow", "\345\205\245\345\234\272\346\227\266\351\227\264\357\274\232", nullptr));
        label_19->setText(QApplication::translate("MainWindow", "\345\207\272\345\234\272\346\227\266\351\227\264\357\274\232", nullptr));
        label_31->setText(QApplication::translate("MainWindow", "\345\201\234\350\275\246\346\227\266\351\227\264\357\274\232", nullptr));
        label_33->setText(QApplication::translate("MainWindow", "\345\201\234\350\275\246\345\215\225\344\273\267\357\274\232", nullptr));
        ETC_lineEdit_Money_Stop->setText(QApplication::translate("MainWindow", "5", nullptr));
        ETC_lineEdit_Money_Stop->setPlaceholderText(QApplication::translate("MainWindow", " \345\205\203/\345\210\206\351\222\237(\351\253\230\344\272\21624S\346\214\211\344\270\200\345\210\206\351\222\237\350\256\241\347\256\227)", nullptr));
        label_27->setText(QApplication::translate("MainWindow", "\345\207\272\345\234\272\346\224\266\350\264\271\357\274\232", nullptr));
        ETC_pushButton_Money_Save->setText(QApplication::translate("MainWindow", "\345\215\225\344\273\267\344\277\235\345\255\230", nullptr));
        groupBox_19->setTitle(QApplication::translate("MainWindow", "\346\240\217\346\235\206\346\223\215\344\275\234", nullptr));
        ETC_pushButton_ON->setText(QApplication::translate("MainWindow", "\346\212\254\346\235\206", nullptr));
        ETC_pushButton_OFF->setText(QApplication::translate("MainWindow", "\351\227\255\346\235\206", nullptr));
        ETC_pushButton_Open->setText(QApplication::translate("MainWindow", "\345\270\270\345\274\200", nullptr));
        tabWidget_ETC->setTabText(tabWidget_ETC->indexOf(tab_ETC_App), QApplication::translate("MainWindow", "\345\272\224\347\224\250*", nullptr));
        groupBox_43->setTitle(QApplication::translate("MainWindow", "\345\237\272\347\241\200\350\256\276\347\275\256", nullptr));
        label_18->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\240\207\347\255\276ID\357\274\232</p></body></html>", nullptr));
        label_56->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\347\274\226\347\273\204\357\274\232</p></body></html>", nullptr));
        G_lineEdit_Panid->setPlaceholderText(QApplication::translate("MainWindow", "1-16383", nullptr));
        label_57->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\344\277\241\351\201\223\357\274\232</p></body></html>", nullptr));
        G_comboBox_Channel->setItemText(0, QApplication::translate("MainWindow", "11", nullptr));
        G_comboBox_Channel->setItemText(1, QApplication::translate("MainWindow", "12", nullptr));
        G_comboBox_Channel->setItemText(2, QApplication::translate("MainWindow", "13", nullptr));
        G_comboBox_Channel->setItemText(3, QApplication::translate("MainWindow", "14", nullptr));
        G_comboBox_Channel->setItemText(4, QApplication::translate("MainWindow", "15", nullptr));
        G_comboBox_Channel->setItemText(5, QApplication::translate("MainWindow", "16", nullptr));
        G_comboBox_Channel->setItemText(6, QApplication::translate("MainWindow", "17", nullptr));
        G_comboBox_Channel->setItemText(7, QApplication::translate("MainWindow", "18", nullptr));
        G_comboBox_Channel->setItemText(8, QApplication::translate("MainWindow", "19", nullptr));
        G_comboBox_Channel->setItemText(9, QApplication::translate("MainWindow", "20", nullptr));
        G_comboBox_Channel->setItemText(10, QApplication::translate("MainWindow", "21", nullptr));
        G_comboBox_Channel->setItemText(11, QApplication::translate("MainWindow", "22", nullptr));
        G_comboBox_Channel->setItemText(12, QApplication::translate("MainWindow", "23", nullptr));
        G_comboBox_Channel->setItemText(13, QApplication::translate("MainWindow", "24", nullptr));
        G_comboBox_Channel->setItemText(14, QApplication::translate("MainWindow", "25", nullptr));
        G_comboBox_Channel->setItemText(15, QApplication::translate("MainWindow", "26", nullptr));

        G_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        G_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        groupBox_44->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\345\235\227\350\257\273\345\206\231", nullptr));
        label_58->setText(QApplication::translate("MainWindow", "\346\225\260\346\215\256\345\235\227\347\274\226\345\217\267\357\274\232", nullptr));
        G_comboBox_Data_Num->setItemText(0, QApplication::translate("MainWindow", "1", nullptr));
        G_comboBox_Data_Num->setItemText(1, QApplication::translate("MainWindow", "2", nullptr));
        G_comboBox_Data_Num->setItemText(2, QApplication::translate("MainWindow", "3", nullptr));
        G_comboBox_Data_Num->setItemText(3, QApplication::translate("MainWindow", "4", nullptr));
        G_comboBox_Data_Num->setItemText(4, QApplication::translate("MainWindow", "5", nullptr));
        G_comboBox_Data_Num->setItemText(5, QApplication::translate("MainWindow", "6", nullptr));
        G_comboBox_Data_Num->setItemText(6, QApplication::translate("MainWindow", "7", nullptr));
        G_comboBox_Data_Num->setItemText(7, QApplication::translate("MainWindow", "8", nullptr));
        G_comboBox_Data_Num->setItemText(8, QApplication::translate("MainWindow", "9", nullptr));
        G_comboBox_Data_Num->setItemText(9, QApplication::translate("MainWindow", "10", nullptr));
        G_comboBox_Data_Num->setItemText(10, QApplication::translate("MainWindow", "11", nullptr));
        G_comboBox_Data_Num->setItemText(11, QApplication::translate("MainWindow", "12", nullptr));
        G_comboBox_Data_Num->setItemText(12, QApplication::translate("MainWindow", "13", nullptr));
        G_comboBox_Data_Num->setItemText(13, QApplication::translate("MainWindow", "14", nullptr));
        G_comboBox_Data_Num->setItemText(14, QApplication::translate("MainWindow", "15", nullptr));
        G_comboBox_Data_Num->setItemText(15, QApplication::translate("MainWindow", "16", nullptr));

        label_59->setText(QApplication::translate("MainWindow", "\350\257\273\345\206\231\350\256\260\345\275\225", nullptr));
        G_pushButton_DelData->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        G_label_State->setText(QString());
        G_pushButton_ReadData->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        G_lineEdit_WriteData->setText(QApplication::translate("MainWindow", "0102030405060708", nullptr));
        G_pushButton_WriteData->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        tabWidget_G->setTabText(tabWidget_G->indexOf(tab_24G), QApplication::translate("MainWindow", "\346\240\207\347\255\276", nullptr));
        groupBox_22->setTitle(QApplication::translate("MainWindow", "\345\237\272\347\241\200\350\256\276\347\275\256", nullptr));
        label_43->setText(QApplication::translate("MainWindow", "\347\274\226\347\273\204\357\274\232", nullptr));
        label_49->setText(QApplication::translate("MainWindow", "\344\277\241\351\201\223\357\274\232", nullptr));
        G_lineEdit_ReadPanid->setPlaceholderText(QApplication::translate("MainWindow", "1-16383", nullptr));
        G_comboBox_ReadChannel->setItemText(0, QApplication::translate("MainWindow", "11", nullptr));
        G_comboBox_ReadChannel->setItemText(1, QApplication::translate("MainWindow", "12", nullptr));
        G_comboBox_ReadChannel->setItemText(2, QApplication::translate("MainWindow", "13", nullptr));
        G_comboBox_ReadChannel->setItemText(3, QApplication::translate("MainWindow", "14", nullptr));
        G_comboBox_ReadChannel->setItemText(4, QApplication::translate("MainWindow", "15", nullptr));
        G_comboBox_ReadChannel->setItemText(5, QApplication::translate("MainWindow", "16", nullptr));
        G_comboBox_ReadChannel->setItemText(6, QApplication::translate("MainWindow", "17", nullptr));
        G_comboBox_ReadChannel->setItemText(7, QApplication::translate("MainWindow", "18", nullptr));
        G_comboBox_ReadChannel->setItemText(8, QApplication::translate("MainWindow", "19", nullptr));
        G_comboBox_ReadChannel->setItemText(9, QApplication::translate("MainWindow", "20", nullptr));
        G_comboBox_ReadChannel->setItemText(10, QApplication::translate("MainWindow", "21", nullptr));
        G_comboBox_ReadChannel->setItemText(11, QApplication::translate("MainWindow", "22", nullptr));
        G_comboBox_ReadChannel->setItemText(12, QApplication::translate("MainWindow", "23", nullptr));
        G_comboBox_ReadChannel->setItemText(13, QApplication::translate("MainWindow", "24", nullptr));
        G_comboBox_ReadChannel->setItemText(14, QApplication::translate("MainWindow", "25", nullptr));
        G_comboBox_ReadChannel->setItemText(15, QApplication::translate("MainWindow", "26", nullptr));

        G_pushButton_ReadRead->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        G_pushButton_ReadWrite->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        groupBox_45->setTitle(QApplication::translate("MainWindow", "\346\263\250\346\204\217", nullptr));
        label_39->setText(QApplication::translate("MainWindow", "<html><head/><body><p>1.\350\257\267\347\241\256\344\277\235\351\230\205\350\257\273\345\231\250\344\270\216\346\240\207\347\255\276\347\232\204\345\237\272\347\241\200\350\256\276\347\275\256\344\270\200\346\240\267,\344\277\256\346\224\271\345\256\214\346\210\220\345\220\216\350\257\267\351\207\215\345\220\257\346\240\207\347\255\276\345\217\212\351\230\205\350\257\273\345\231\250</p><p>2.\344\270\212\347\224\265\351\241\272\345\272\217\357\274\232\345\205\210\351\230\205\350\257\273\345\231\250\345\220\216\346\240\207\347\255\276</p></body></html>", nullptr));
        groupBox_35->setTitle(QApplication::translate("MainWindow", "\345\257\273\345\215\241\346\223\215\344\275\234", nullptr));
        G_pushButton_DelLabel->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        G_pushButton_LookCard->setText(QApplication::translate("MainWindow", "\345\257\273\345\215\241", nullptr));
        groupBox_36->setTitle(QApplication::translate("MainWindow", "\351\230\205\350\257\273\346\223\215\344\275\234", nullptr));
        label_50->setText(QApplication::translate("MainWindow", "\346\240\207\347\255\276\357\274\232", nullptr));
        label_60->setText(QApplication::translate("MainWindow", "\346\225\260\346\215\256\345\235\227\357\274\232", nullptr));
        G_comboBox_Data->setItemText(0, QApplication::translate("MainWindow", "1", nullptr));
        G_comboBox_Data->setItemText(1, QApplication::translate("MainWindow", "2", nullptr));
        G_comboBox_Data->setItemText(2, QApplication::translate("MainWindow", "3", nullptr));
        G_comboBox_Data->setItemText(3, QApplication::translate("MainWindow", "4", nullptr));
        G_comboBox_Data->setItemText(4, QApplication::translate("MainWindow", "5", nullptr));
        G_comboBox_Data->setItemText(5, QApplication::translate("MainWindow", "6", nullptr));
        G_comboBox_Data->setItemText(6, QApplication::translate("MainWindow", "7", nullptr));
        G_comboBox_Data->setItemText(7, QApplication::translate("MainWindow", "8", nullptr));
        G_comboBox_Data->setItemText(8, QApplication::translate("MainWindow", "9", nullptr));
        G_comboBox_Data->setItemText(9, QApplication::translate("MainWindow", "10", nullptr));
        G_comboBox_Data->setItemText(10, QApplication::translate("MainWindow", "11", nullptr));
        G_comboBox_Data->setItemText(11, QApplication::translate("MainWindow", "12", nullptr));
        G_comboBox_Data->setItemText(12, QApplication::translate("MainWindow", "13", nullptr));
        G_comboBox_Data->setItemText(13, QApplication::translate("MainWindow", "14", nullptr));
        G_comboBox_Data->setItemText(14, QApplication::translate("MainWindow", "15", nullptr));
        G_comboBox_Data->setItemText(15, QApplication::translate("MainWindow", "16", nullptr));

        label_61->setText(QApplication::translate("MainWindow", "\346\223\215\344\275\234\350\256\260\345\275\225", nullptr));
        G_pushButton_DelLabelData->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244", nullptr));
        G_label_LabelState->setText(QString());
        G_pushButton_Readlabel->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        G_lineEdit_Write->setText(QApplication::translate("MainWindow", "0102030405060708", nullptr));
        G_pushButton_WriteLabel->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        tabWidget_G->setTabText(tabWidget_G->indexOf(tab_5), QApplication::translate("MainWindow", "\351\230\205\350\257\273\345\231\250", nullptr));
        groupBox_20->setTitle(QApplication::translate("MainWindow", "\345\205\245\345\272\223\347\256\241\347\220\206", nullptr));
        groupBox_21->setTitle(QApplication::translate("MainWindow", "\344\273\223\345\202\250\346\203\205\345\206\265", nullptr));
        tabWidget_G->setTabText(tabWidget_G->indexOf(tab_24G_App), QApplication::translate("MainWindow", "\345\272\224\347\224\250*", nullptr));
        pushButton_IsShow->setText(QApplication::translate("MainWindow", "\343\200\213\n"
"\343\200\213\n"
"\343\200\213", nullptr));
        Uart_Data->setTitle(QApplication::translate("MainWindow", "\344\270\262\345\217\243\350\260\203\350\257\225\346\225\260\346\215\256", nullptr));
        comboBox_Show_Mode->setItemText(0, QApplication::translate("MainWindow", "\346\230\276\347\244\272\346\211\200\346\234\211\346\225\260\346\215\256", nullptr));
        comboBox_Show_Mode->setItemText(1, QApplication::translate("MainWindow", "\344\273\205\346\230\276\347\244\272\345\217\221\351\200\201\346\225\260\346\215\256", nullptr));
        comboBox_Show_Mode->setItemText(2, QApplication::translate("MainWindow", "\344\273\205\346\230\276\347\244\272\346\216\245\346\224\266\346\225\260\346\215\256", nullptr));

        pushButton_DelData->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244\350\260\203\350\257\225\346\225\260\346\215\256", nullptr));
        pushButton_Rec_Mode->setText(QApplication::translate("MainWindow", "\345\201\234\346\255\242\346\216\245\346\224\266", nullptr));
        label_Rec_Text->setText(QApplication::translate("MainWindow", "\346\216\245\346\224\266\357\274\232", nullptr));
        label_Rec_Num->setText(QApplication::translate("MainWindow", "0", nullptr));
        label_Send_Text->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201\357\274\232", nullptr));
        label_Send_Num->setText(QApplication::translate("MainWindow", "0", nullptr));
        pushButton_DelNum->setText(QApplication::translate("MainWindow", "\345\244\215\344\275\215\350\256\241\346\225\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
