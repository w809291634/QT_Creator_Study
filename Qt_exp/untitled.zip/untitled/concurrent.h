#ifndef CONCURRENT_H
#define CONCURRENT_H

#include <QObject>
#include <QtConcurrent>

class Concurrent_Thread : public QObject
{
    Q_OBJECT
public:
    explicit Concurrent_Thread(QObject *parent = nullptr);
    ~Concurrent_Thread();
signals:

public slots:

};

#endif // CONCURRENT_H
