#include "../../../../../../qtmqtt/src/mqtt/qmqttmessage_p.h"
