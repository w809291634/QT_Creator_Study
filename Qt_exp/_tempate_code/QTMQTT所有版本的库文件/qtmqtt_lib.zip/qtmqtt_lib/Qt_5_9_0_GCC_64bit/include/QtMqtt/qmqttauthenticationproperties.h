#include "../../../qtmqtt/src/mqtt/qmqttauthenticationproperties.h"
