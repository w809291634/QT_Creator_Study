﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_mainwindow.h"

class MainWindow : public QMainWindow       // 公有继承 QMainWindow QMainWindow私有成员不可见
{
    Q_OBJECT                                // 很重要的宏，初始化元对象模型，启用元对象特性

public:
    explicit MainWindow(QWidget *parent = nullptr);     // 构造函数
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;                     // 指向 Ui::MainWindow 类的指针
};

#endif // MAINWINDOW_H
