﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    sharedMemory(new QSharedMemory("QSharedMemoryExample",this))
{
    ui->setupUi(this);
    process = new QProcess(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

/* QProcess */
void MainWindow::on_process_start_clicked()
{
    if(ui->process_path->text().isEmpty()){
        QString curPath=QDir::currentPath();
        QString dlgTitle="选择执行文件";
#ifdef _WIN64
        QString filter="执行文件(*.exe)";           //文件过滤器
#elif __unix__
        QString filter="";                         //文件过滤器
#endif
        QString filePath=QFileDialog::getOpenFileName(this,dlgTitle,curPath,filter);
        if (filePath.isEmpty())
            return;
        ui->process_path->setText(filePath);
    }
    process->setProgram(ui->process_path->text());
    process->start();
}

void MainWindow::on_process_stop_clicked()
{
    process->kill();
}

void MainWindow::on_text_clear_clicked()
{
    ui->process_path->clear();
}

/* QSharedMemory */
void MainWindow::on_loadFromFileButton_clicked()
{
    if (sharedMemory->isAttached()){
        if (!sharedMemory->detach())
            ui->image->setText(tr("无法从共享内存分离."));
    }

    ui->image->setText(tr("选择图像文件."));
    QString fileName = QFileDialog::getOpenFileName(nullptr, QString(), QString(),
                                        tr("图片文件(*.png *.xpm *.jpg)"));
    QImage image;
    if (!image.load(fileName)) {
        ui->image->setText(tr("所选文件不是图像，请选择其他文件."));
        return;
    }
    ui->image->setPixmap(QPixmap::fromImage(image));

    // 加载到共享内存
    QBuffer buffer;
    buffer.open(QBuffer::ReadWrite);
    QDataStream out(&buffer);
    out << image;
    int size = int(buffer.size());

    if (!sharedMemory->create(size)) {                  // 创建大小为size字节的共享内存段
        ui->image->setText(tr("无法创建共享内存段."));
        return;
    }
    sharedMemory->lock();
    char *to = (char*)sharedMemory->data();             // 取共享内存 内容所在指针
    const char *from = buffer.data().data();
    memcpy(to, from, qMin(sharedMemory->size(), size)); // 拷贝数据到共享内存
    sharedMemory->unlock();
}

void MainWindow::on_loadFromSharedMemoryButton_clicked()
{
    if (!sharedMemory->attach()) {
        ui->image->setText(tr("无法连接到共享内存段.\n" \
                             "首先加载图像."));
        return;
    }

    QBuffer buffer;
    QDataStream in(&buffer);
    QImage image;

    sharedMemory->lock();
    buffer.setData((const char*)sharedMemory->constData(), sharedMemory->size());   // 读取 共享内存中的 图像数据
    buffer.open(QBuffer::ReadOnly);
    in >> image;                                        // 传输数据 到 图像
    sharedMemory->unlock();

    sharedMemory->detach();
    ui->image->setPixmap(QPixmap::fromImage(image));    // 显示图像
}
