#include "persondet.h"

// 析构函数
Persondet::~Persondet()
{
    person_det.clear();
}

// 模型初始化
int Persondet::init(std::string model_path)
{
    std::string person_param = model_path + "/person_detector.param";
    std::string person_bin= model_path + "/person_detector.bin";
	// 加载行人检测模型
    person_det.load_param(person_param.data());
    person_det.load_model(person_bin.data());
    return 0;
}


// 行人检测
int Persondet::detect(cv::Mat& image)
{
    int img_w = image.cols;
    int img_h = image.rows;
    //数据预处理
    ncnn::Mat in = ncnn::Mat::from_pixels_resize(image.data, ncnn::Mat::PIXEL_BGR2RGB, \
                                                 img_w, img_h, person_width, person_height);
    //数据归一化
    const float mean_vals[3] = {0.f, 0.f, 0.f};
    const float norm_vals[3] = {1/255.f, 1/255.f, 1/255.f};
    in.substract_mean_normalize(mean_vals, norm_vals);
    // 创建网络执行器
    ncnn::Extractor ex = person_det.create_extractor();
	// 设置网络输入
    ex.input("data", in);
    ncnn::Mat out;
	// 获取网络输出
    ex.extract("output", out);
	
	// 解析行人检测结果
    for (int i = 0; i < out.h; i++)
    {
        float x1, y1, x2, y2, score, label;
        float pw,ph,cx,cy;
        const float* values = out.row(i);

        x1 = values[2] * img_w;
        y1 = values[3] * img_h;
        x2 = values[4] * img_w;
        y2 = values[5] * img_h;

        pw = x2 - x1;
        ph = y2 - y1;
        cx = x1 + 0.5 * pw;
        cy = y1 + 0.5 * ph;

        x1 = cx - 0.7 * pw;
        y1 = cy - 0.6 * ph;
        x2 = cx + 0.7 * pw;
        y2 = cy + 0.6 * ph;

        score = values[1];
        label = values[0];

        // 处理坐标越界问题
        if (x1 < 0) x1 = 0;
        if (y1 < 0) y1 = 0;
        if (x2 < 0) x2 = 0;
        if (y2 < 0) y2 = 0;
        if (x1 > img_w) x1 = img_w;
        if (y1 > img_h) y1 = img_h;
        if (x2 > img_w) x2 = img_w;
        if (y2 > img_h) y2 = img_h;
		// 显示行人框
        cv::rectangle(image, cv::Point(x1, y1), cv::Point(x2, y2), cv::Scalar(255, 0, 255), 2);
    }
    return 0;
}


