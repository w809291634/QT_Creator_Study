#include "../../../qtmqtt/src/mqtt/qmqttsubscriptionproperties.h"
