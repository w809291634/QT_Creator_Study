#ifndef FUTURE_H
#define FUTURE_H
#include <QFuture>
#include <QMutexLocker>

template <typename T>
class Future: public QFuture<T>
{
public:
    Future():QFuture<T>()
    {

    }
    ~Future()
    {

    }

    void run(QFuture<T> p);         // 启动一个线程，注意不能重复调用
    QFuture<T>* get_base();         // 获取基类指针
    bool isStoped() const;
    void stop();

private:
    bool stoped=false;
    QMutex statusMutex;
};

template <typename T>
inline void Future<T>::run(QFuture<T> p)
{
    QMutexLocker locker(&statusMutex);
    stoped=false;
    QFuture<T>* _p=this->get_base();
    *_p = p;
}

template <typename T>
inline QFuture<T>* Future<T>::get_base()
{
    return dynamic_cast<QFuture<T>*>(this);
}

template <typename T>
inline bool Future<T>::isStoped() const
{
    return stoped;
}

template <typename T>
inline void Future<T>::stop()
{
    QMutexLocker locker(&statusMutex);
    stoped=true;
    this->waitForFinished();
}

#endif // FUTURE_H
