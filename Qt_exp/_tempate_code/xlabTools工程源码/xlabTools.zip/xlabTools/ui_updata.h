/********************************************************************************
** Form generated from reading UI file 'updata.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATA_H
#define UI_UPDATA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_upData
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QProgressBar *pgb_upData;
    QHBoxLayout *horizontalLayout;
    QLabel *lbl_byteValueStr;
    QLabel *lbl_byteValue;
    QLabel *lbl_speedNumStr;
    QLabel *lbl_speedNum;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *btn_checkUp;
    QPushButton *btn_disConnect;

    void setupUi(QMainWindow *upData)
    {
        if (upData->objectName().isEmpty())
            upData->setObjectName(QString::fromUtf8("upData"));
        upData->resize(340, 110);
        centralWidget = new QWidget(upData);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout_3 = new QHBoxLayout(centralWidget);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pgb_upData = new QProgressBar(centralWidget);
        pgb_upData->setObjectName(QString::fromUtf8("pgb_upData"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pgb_upData->sizePolicy().hasHeightForWidth());
        pgb_upData->setSizePolicy(sizePolicy);
        pgb_upData->setValue(0);
        pgb_upData->setTextVisible(true);
        pgb_upData->setInvertedAppearance(false);
        pgb_upData->setTextDirection(QProgressBar::TopToBottom);

        verticalLayout->addWidget(pgb_upData);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        lbl_byteValueStr = new QLabel(centralWidget);
        lbl_byteValueStr->setObjectName(QString::fromUtf8("lbl_byteValueStr"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lbl_byteValueStr->sizePolicy().hasHeightForWidth());
        lbl_byteValueStr->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(lbl_byteValueStr);

        lbl_byteValue = new QLabel(centralWidget);
        lbl_byteValue->setObjectName(QString::fromUtf8("lbl_byteValue"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lbl_byteValue->sizePolicy().hasHeightForWidth());
        lbl_byteValue->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(lbl_byteValue);

        lbl_speedNumStr = new QLabel(centralWidget);
        lbl_speedNumStr->setObjectName(QString::fromUtf8("lbl_speedNumStr"));
        sizePolicy1.setHeightForWidth(lbl_speedNumStr->sizePolicy().hasHeightForWidth());
        lbl_speedNumStr->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(lbl_speedNumStr);

        lbl_speedNum = new QLabel(centralWidget);
        lbl_speedNum->setObjectName(QString::fromUtf8("lbl_speedNum"));
        sizePolicy2.setHeightForWidth(lbl_speedNum->sizePolicy().hasHeightForWidth());
        lbl_speedNum->setSizePolicy(sizePolicy2);
        lbl_speedNum->setLayoutDirection(Qt::LeftToRight);

        horizontalLayout->addWidget(lbl_speedNum);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        btn_checkUp = new QPushButton(centralWidget);
        btn_checkUp->setObjectName(QString::fromUtf8("btn_checkUp"));

        horizontalLayout_2->addWidget(btn_checkUp);

        btn_disConnect = new QPushButton(centralWidget);
        btn_disConnect->setObjectName(QString::fromUtf8("btn_disConnect"));

        horizontalLayout_2->addWidget(btn_disConnect);


        verticalLayout_2->addLayout(horizontalLayout_2);


        horizontalLayout_3->addLayout(verticalLayout_2);

        upData->setCentralWidget(centralWidget);

        retranslateUi(upData);

        QMetaObject::connectSlotsByName(upData);
    } // setupUi

    void retranslateUi(QMainWindow *upData)
    {
        upData->setWindowTitle(QApplication::translate("upData", "\347\211\210\346\234\254\346\233\264\346\226\260", nullptr));
        lbl_byteValueStr->setText(QApplication::translate("upData", "\346\226\207\344\273\266\345\244\247\345\260\217\357\274\232", nullptr));
        lbl_byteValue->setText(QApplication::translate("upData", "0 MB", nullptr));
        lbl_speedNumStr->setText(QApplication::translate("upData", "\344\270\213\350\275\275\351\200\237\345\272\246\357\274\232", nullptr));
        lbl_speedNum->setText(QApplication::translate("upData", "0 KB/S", nullptr));
        btn_checkUp->setText(QApplication::translate("upData", "\346\243\200\346\265\213\346\233\264\346\226\260", nullptr));
        btn_disConnect->setText(QApplication::translate("upData", "\351\200\200\345\207\272\344\270\213\350\275\275", nullptr));
    } // retranslateUi

};

namespace Ui {
    class upData: public Ui_upData {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATA_H
