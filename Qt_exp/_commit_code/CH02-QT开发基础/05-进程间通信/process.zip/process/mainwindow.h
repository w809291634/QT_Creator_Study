﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore>
#include <QFileDialog>
#if defined(_MSC_VER) && (_MSC_VER >= 1600)
# pragma execution_character_set("utf-8")
#endif

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    /* QProcess */
    void on_process_start_clicked();
    void on_process_stop_clicked();
    void on_text_clear_clicked();
    /* QSharedMemory */
    void on_loadFromFileButton_clicked();
    void on_loadFromSharedMemoryButton_clicked();

private:
    Ui::MainWindow *ui;
    QProcess * process;
    QSharedMemory* sharedMemory;
};

#endif // MAINWINDOW_H
