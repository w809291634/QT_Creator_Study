#include "../../../qtmqtt/src/mqtt/qmqttpublishproperties.h"
