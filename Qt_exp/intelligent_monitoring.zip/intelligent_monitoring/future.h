#ifndef FUTURE_H
#define FUTURE_H

#include <QDebug>
#include <QFuture>
#include <QFutureWatcher>
#include <QMutexLocker>
#include <QtConcurrent>
#include <QThreadPool>

#define THREAD_HEAD(F)  while(!F.isRequestedStop()){ \
                            while(!F.isPaused() && !F.isRequestedStop())
#define THREAD_HEAD_2(F)  while(!F->isRequestedStop()){ \
                            while(!F->isPaused() && !F->isRequestedStop())
#define THREAD_TAIL         QThread::msleep(100);}


template <typename T>
class Future: public QFuture<T>
{
public:
    Future(QString name=""):QFuture<T>()
    {
        m_name=name;
        stop();
    }
    ~Future()
    {
        stop();
        qDebug()<< QString("QtConcurrent_thread:%1 exit").arg(m_name);
    }

    void run(QFuture<T> p);         // 启动一个线程，注意不能重复调用
    QFuture<T>* get_base();         // 获取基类指针
    bool isRequestedStop() const;
    bool isStoped() const;
    void stop();

private:
    QString m_name="";
    bool stop_flag=false;
    QMutex statusMutex;
};

template <typename T>
inline void Future<T>::run(QFuture<T> p)
{
    QMutexLocker locker(&statusMutex);
    stop_flag=false;

    QFuture<T>* _p=this->get_base();
    *_p = p;
}

template <typename T>
inline QFuture<T>* Future<T>::get_base()
{
    return dynamic_cast<QFuture<T>*>(this);
}

template <typename T>
inline bool Future<T>::isRequestedStop() const
{
    return stop_flag;
}

template <typename T>
inline bool Future<T>::isStoped() const
{
    return QFuture<T>::isFinished();
}

template <typename T>
inline void Future<T>::stop()
{
    QMutexLocker locker(&statusMutex);
    stop_flag=true;
    this->waitForFinished();        // 等待线程完成，退出run运行的函数
    stop_flag=false;
}

#endif // FUTURE_H
