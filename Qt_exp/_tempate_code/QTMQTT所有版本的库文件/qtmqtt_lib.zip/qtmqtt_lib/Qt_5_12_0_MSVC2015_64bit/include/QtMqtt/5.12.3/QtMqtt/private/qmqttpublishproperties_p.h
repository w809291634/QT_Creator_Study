#include "../../../../../../qtmqtt/src/mqtt/qmqttpublishproperties_p.h"
