﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QMessageBox>  //对话框
#include <string>
#include <QTimer>
#include <QDateTime>
#include <QStatusBar>
#include <QLabel>
#include <synchapi.h>   //延时
#include <QCloseEvent>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include "updata/updata.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QTimer *timer = new QTimer(this);
    QTimer *autoTime = new QTimer(this);
    QByteArray RecData;
    upData *up;
    bool SetUart();
    void mousePressEvent(QMouseEvent *event);
    QString Get_Xor(unsigned char x, unsigned char y, QString z);
    void Group();
    void Group_LoRa();
    void Group_WiFi();
    void Group_NoZigBee();
    char ConvertHexChar(char ch);
    QString Get_Hex(QString str);
    void StringToHex(QString str,QByteArray &send_data);
    void Set_Label(unsigned char mode);
    void WiFi_Save_Reset(bool mode);
    void WiFi_Send_Data();
    QPixmap createQRCode(const QString &text);

    void ZigBee_Data_Analysis();
    void LoRa_Data_Analysis();
    void WiFi_Data_Analysis();
    void NB_Data_Analysis();
    void CAT1_Data_Analysis();
    void ESP8266_Data_Analysis();
    void LoRaWAN_Data_Analysis();
    void Read_NetWord(bool mode);
    void ZigBee_Read_MAC();
    static QString ChmData_Str;
    static QString Code_Str;
    bool WiFi_IsOk();
    unsigned char LoRa_IsOk();
    unsigned char Mode = 1;  //当前的模式
    QString Time_str;

public slots:
    void firstVerUp();
    void fillChmDataStr();
private:
    Ui::MainWindow *ui;
    QFile *file = new QFile;
    QSerialPort Serial;
    QLabel mLabel;
    QTime time;
    int autoSendTime = 1000;
    bool autoSendFlag;
    bool IsOpen;
    bool IsRecv;
    bool Rec_Mode;
    bool Send_Mode;

    QString ZigBeeData_Str;
    QString ZigBeeData_Hex;
    QString LoRa;
    QString Other;

    QString mCom;
    QString mBaud;
    QString Group_Data[7];
    QRegExp Regexp_Cmd,Regexp_Na,Regexp_Data_Hex,Regexp_Data_Ascii,Regexp_Panid,Regexp_LoRa_ID;
    QRegExp Regexp_G_ID,Regexp_G_KEY,Regexp_G_IP;
    QRegExp Regexp_LoRa_PS,Regexp_LoRa_FP,Regexp_LoRa_HOP,Regexp_LoRa_Release;
    QRegExp Regexp_WiFi_SSID,Regexp_WiFi_PSK,Regexp_WiFi_IP;
    QRegExp Regexp_LoRaWAN_JOINEUI,Regexp_LoRaWAN_KEY;

    QString addHandleLog(QString SendStr);
    void LoRaWAN_Read_deploy();
    void RWControlChange(bool enable);
    bool LoRaWAN_IsOk();
signals:
    void Display_Code();
    void check_upFirst();
    void check_upData();
    void setLoRaWANChm();
private slots:
    void Get_Time();
    void saveFileSlot();
    void Write_NetWord();
    void OpenUart_Clicked();
    void OpenRecv_Clicked();
    void ReadUart();
    void Analysis();
    void About_Up();

    void SendNa_Add_Space();
    void SendData_Add_Space();
    void SendCmd_Add_Space();
    void WriteUart();
    void Del_SendData();
    void Del_RecData();
    void Get_Com();
    void Set_RecMode();
    void Set_SendMode();
    void Del_Num();

    void Change_ZigBee();
    void Change_LoRa();
    void Change_4G();
    void Change_NB_IOT();
    void Change_CAT1();
    void Change_WiFi();
    void Change_ESP8266();
    void Change_BLE();
    void Change_LoRaWAN();
    void Mode_Group();

    void ZigBee_AT_Test();
    void ZigBee_Make_Type();
    void ZigBee_Send_Length();

    void Read_IDK();
    void Write_IDK();
    void NB_AT_Test();

    void CAT1_AT_Test();
    void CAT1_Read_Cfg();
    void CAT1_Write_Cfg();

    void ESP8266_AT_Test();
    void ESP8266_Read_Cfg();
    void ESP8266_Write_Cfg();

    void LoRa_AT_Test();
    void Read_LoRa();
    void Write_LoRa();

    void LoRa_Write_Button();
    void LoRa_Write_Wait();
    void LoRa_Read_Button();
    void LoRa_Show_HOP();
    void LoRa_Send_Length();
    void LoRa_Send_Data();
    void Out_Code();
    void Read_Parameter();

    void WiFi_Read_Net();
    void WiFi_AT_Test();
    void WiFi_Write_Net();
    void WiFi_Send_Length();

    void Read_Netslot();
    void Del_Read_Write_flag();
    void BLE_ReadMac();
    void BLE_TestLink();

    void WiFi_Send_Move1();
    void WiFi_Send_Move2();
    void WiFi_Send_Move3();
    void WiFi_Send_Move4();
    void on_chk_sendEnd_clicked(bool checked);
    void on_pushButton_Send_clicked();
    void on_LoRaWAN_btn_Read_clicked();
    void on_LoRaWAN_btn_Write_clicked();
    void on_LoRaWAN_btn_setChm_clicked();
    void ESP8266_Mode_Select(int mode);
};

#endif // MAINWINDOW_H
