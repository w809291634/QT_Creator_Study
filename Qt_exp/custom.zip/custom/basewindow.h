#ifndef BASEWINDOW_H
#define BASEWINDOW_H


class BaseWindow: public QWidget
{
public:
    BaseWindow();
};

#endif // BASEWINDOW_H
