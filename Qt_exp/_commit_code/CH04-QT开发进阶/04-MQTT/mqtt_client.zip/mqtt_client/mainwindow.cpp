﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDateTime>
#include "QtMqtt/qmqttclient.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("MQTT客户端");
    init_mqtt_client();
    init_mqtt_client_ui();
}

MainWindow::~MainWindow()
{
    delete ui;
}

/** 初始化 **/
// 获取 本地 能够 监听的地址
void MainWindow::getLocalIP()
{
    QTcpServer TcpServer;
    QList<QNetworkInterface> list = QNetworkInterface::allInterfaces();
    foreach (QNetworkInterface interface, list)
    {
        QList<QNetworkAddressEntry> entryList= interface.addressEntries();
        foreach (QNetworkAddressEntry entry, entryList)
        {
            //过滤 IPv6 地址，只留下 IPv4
            if (entry.ip().protocol() ==QAbstractSocket::IPv4Protocol)
            {
                QHostAddress ip = entry.ip();
                //  筛选出能够监听的 ip地址
                if(TcpServer.listen(ip)){
                    bool add=true;
                    TcpServer.close();
                    // 将优先地址 排在 前面
                    for(auto _ip:FIRST_IP_ARRDESS){
                        if(ip.toString().contains(_ip)){
                            ui->host_cbox->insertItem(0,ip.toString());
                            add=false;
                            break;
                        }
                    }
                    // 不在优先选择地址，放在队列尾部
                    if(add){
                        ui->host_cbox->addItem(ip.toString());
                    }

                }
            }
        }
    }
    // 服务器 添加AnyIPv4(0.0.0.0)
    ui->host_cbox->insertItem(1,
                QHostAddress(QHostAddress::AnyIPv4).toString());
    ui->host_cbox->setCurrentIndex(0);
}

// 初始化mqtt客户端
void MainWindow::init_mqtt_client()
{
    m_client = new QMqttClient(this);
    m_client->setKeepAlive(60);         // 设置心跳间隔时间，10秒发送一次心跳信号。默认为60s

    connect(m_client, &QMqttClient::stateChanged,
            this, &MainWindow::client_stateChanged);
    connect(m_client, &QMqttClient::errorChanged,
            this, &MainWindow::client_errorChanged);

    connect(m_client, SIGNAL(messageReceived(const QByteArray&, const QMqttTopicName&)),
            this, SLOT(client_messageReceived(const QByteArray&, const QMqttTopicName&)));

    connect(m_client, SIGNAL(pingResponseReceived()),
            this,SLOT(client_pingResponse()));

    QTimer* Timer = new QTimer(this);
    connect(Timer, SIGNAL(timeout()), this, SLOT(client_sub_list_update()));
    Timer->start(100);
}

// 初始化mqtt客户端ui界面
void MainWindow::init_mqtt_client_ui()
{
    getLocalIP();

    // mqtt服务器端口设置
    ui->spinBoxPort->setRange(1,65535);
    ui->spinBoxPort->setValue(1883);
    ui->spinBoxPort->setEnabled(true);

    // mqtt服务器地址 IP 可以编辑
    ui->host_cbox->setEditable(true);
    // 正则匹配 表达只能输入 0.0.0.0~255.255.255.255
    QRegExp IP_regExp("^((\\d)|([1-9]\\d)|(1\\d{2})|(2[0-4]\\d)|(25[0-5]))"
                        "(\\.((\\d)|([1-9]\\d)|(1\\d{2})|(2[0-4]\\d)|(25[0-5]))){3}$");
    QValidator* pValidator = new QRegExpValidator(IP_regExp, this);
    ui->host_cbox->setValidator(pValidator);

    // 话题设置
    ui->sub_topic_cbox->setEditable(true);
    ui->pub_topic_cbox->setEditable(true);
    ui->sub_topic_cbox->addItem("qtmqtt/topic1");
    ui->pub_topic_cbox->addItem("qtmqtt/topic1");

    // Qos设置
    QStringList Qoslist;
    Qoslist << "0 最多一次" << "1 最少一次" << "2 仅一次";
    ui->sub_Qos_cbox->addItems(Qoslist);
    ui->pub_Qos_cbox->addItems(Qoslist);

    // 初始界面状态
    client_disconnected();
}

/** 状态 **/
// 客户端处于连接状态
void MainWindow::client_connected()
{
    // IP地址和端口
    ui->host_cbox->setEnabled(false);
    ui->spinBoxPort->setEnabled(false);
    // 连接按钮
    ui->buttonConnect->setEnabled(false);
    ui->buttonDisconnect->setEnabled(true);
    // 发布订阅按钮
    ui->sub_btn->setEnabled(true);
    ui->pub_btn->setEnabled(true);
    // ping按钮
    ui->buttonPing->setEnabled(true);
}

// 客户端处于断开状态
void MainWindow::client_disconnected()
{
    // IP地址和端口
    ui->host_cbox->setEnabled(true);
    ui->spinBoxPort->setEnabled(true);
    // 连接按钮
    ui->buttonConnect->setEnabled(true);
    ui->buttonDisconnect->setEnabled(false);
    // 发布订阅按钮
    ui->sub_btn->setEnabled(false);
    ui->pub_btn->setEnabled(false);
    // ping按钮
    ui->buttonPing->setEnabled(false);
    // 已经断开，删除所有的订阅项目
    mqtt_sub_list.clear();
}

// 历史信息添加项目
void MainWindow::history_listWidget_additem(QString & info)
{
    QString time=QString("(%1) ")
            .arg(QDateTime::currentDateTime().toString("hh:mm:ss.zzz"));
    ui->history_listWidget->addItem(time+info);
    ui->history_listWidget->scrollToBottom();
}

// MQTT客户端状态变化
void MainWindow::client_stateChanged(QMqttClient::ClientState state)
{
    QString info;
    switch(state){
    case QMqttClient::Disconnected:
        info=QString("MQTT客户端断开连接");
        client_disconnected();
        break;
    case QMqttClient::Connecting:
        info=QString("MQTT客户端正在连接");
        break;
    case QMqttClient::Connected:
        info=QString("MQTT客户端连接成功");
        client_connected();
        break;
    }
    ui->statusBar->showMessage(info);
    history_listWidget_additem(info);
}

// 客户端错误信息
void MainWindow::client_errorChanged(QMqttClient::ClientError error)
{
    QString info;
    switch(error){
    case QMqttClient::NoError:
        info=QString("错误：没有错误");
        break;
    case QMqttClient::InvalidProtocolVersion:
        info=QString("错误：无效的协议版本");
        break;
    case QMqttClient::IdRejected:
        info=QString("错误：Id已拒绝");
        break;
    case QMqttClient::ServerUnavailable:
        info=QString("错误：服务器不可用");
        break;
    case QMqttClient::BadUsernameOrPassword:
        info=QString("错误：用户名或密码错误");
        break;
    case QMqttClient::NotAuthorized:
        info=QString("错误：未授权");
        break;
    case QMqttClient::TransportInvalid:
        info=QString("错误：运输无效");
        break;
    case QMqttClient::ProtocolViolation:
        info=QString("错误：协议违反");
        break;
    case QMqttClient::UnknownError:
        info=QString("错误：未知错误");
        break;
    case QMqttClient::Mqtt5SpecificError:
        info=QString("错误：MQTT5特定错误");
        break;
    }
    ui->statusBar->showMessage(info);
    history_listWidget_additem(info);
}

// 客户端ping反馈
void MainWindow::client_pingResponse()
{
    ui->buttonPing->setEnabled(true);
    QString info("连接正常");
    history_listWidget_additem(info);
    ui->statusBar->showMessage(info);
}

// 客户端接收消息
void MainWindow::client_messageReceived(
        const QByteArray &message,
        const QMqttTopicName &topic)
{
    QString info = "接收话题:"
                + topic.name()
                + " 消息:"
                + message;
    history_listWidget_additem(info);
    ui->statusBar->showMessage("接收消息成功");
}

// 客户端订阅列表更新
void MainWindow::client_sub_list_update()
{
    static int last_len=-1;
    if(mqtt_sub_list.length()!=last_len){
        last_len=mqtt_sub_list.length();

        // 更新信息
        ui->sub_list_cbox->clear();
        foreach(auto sub_object,mqtt_sub_list){
            QString topic_name=sub_object->topic().filter();
            QString item=topic_name+QString(" qos%1").arg(sub_object->qos());
            ui->sub_list_cbox->addItem(item);
        }
    }
}

/** UI槽函数 **/
// 连接mqtt服务器
// 不需要用户密码，请设置服务器为匿名登录
void MainWindow::on_buttonConnect_clicked()
{
    m_client->setHostname(ui->host_cbox->currentText());
    m_client->setPort(static_cast<quint16>(ui->spinBoxPort->value()));
    m_client->connectToHost();
}

// 断开mqtt服务器
void MainWindow::on_buttonDisconnect_clicked()
{
    m_client->disconnectFromHost();
}

// 订阅按钮
void MainWindow::on_sub_btn_clicked()
{
    QString topic=ui->sub_topic_cbox->currentText();
    quint8 qos=static_cast<quint8>(ui->sub_Qos_cbox->currentIndex());
    auto subscription = m_client->subscribe(topic,qos);
    qDebug()<< subscription;
    if(subscription!=nullptr){
        if(!mqtt_sub_list.contains(subscription))
            mqtt_sub_list.append(subscription);
    }else{
        QMessageBox::critical(this, "错误","不能订阅.是否有一个有效的连接");
    }
}

// 删除订阅
void MainWindow::on_sub_list_delete_clicked()
{
    int index=ui->sub_list_cbox->currentIndex();
    if(mqtt_sub_list.length()>0){
        QMqttSubscription* sub_object=mqtt_sub_list[index];
        sub_object->unsubscribe();
        mqtt_sub_list.removeOne(sub_object);
    }
}

// 发布消息按钮
void MainWindow::on_pub_btn_clicked()
{
    QString topic=ui->pub_topic_cbox->currentText();
    QByteArray msg=ui->lineEditMessage->text().toUtf8();
    quint8 qos=static_cast<quint8>(ui->pub_Qos_cbox->currentIndex());
    qint32 ret=m_client->publish(topic, msg ,qos);
    if(ret!=-1){
        QString info=QString("发送话题:%1 消息:%2").arg(topic).arg(QString(msg));
        history_listWidget_additem(info);
        ui->statusBar->showMessage("发送消息成功");
    }else{
        QMessageBox::critical(this, "错误","不能发布消息");
    }
}

// ping功能按钮,测试连接是否正常
void MainWindow::on_buttonPing_clicked()
{
    if(m_client->requestPing())
        ui->buttonPing->setEnabled(false);
}

// 清除历史
void MainWindow::on_history_clear_btn_clicked()
{
    ui->history_listWidget->clear();
}
