#include "facerec.h"

const int face_fpn_num = 3;
const int face_anchor_num = 2;
const int face_num_class = 0;
const int face_channels_per_box = 4 + 1;
const float face_anchor[6 * 2] = { 192.0, 240.0, 384.0, 480.0, 48.0, 60.0, 96.0, 120.0, 12.0, 15.0, 24.0, 30.0 };    //feature 从小到大,对应Anchor从大到小
#if defined __ARM_ARCH
float face_confidence_threshold = 0.4f;
#elif defined __x86_64
float face_confidence_threshold = 0.6f;             // 仅仅x86测试QT使用，避免x86运行时很卡
#endif
float face_nms_threshold = 0.5f;

// 人脸识别对象析构函数
Facerec::~Facerec()
{
    face_det.clear();
    face_rec.clear();
}

// 加载人脸检测模型, 加载人脸识别模型
int Facerec::init(std::string model_path)
{
    int ret=0;
    std::string face_param = model_path + "/face_det.param";
    std::string face_bin= model_path + "/face_det.bin";
    std::string rec_param = model_path + "/face_rec.param";
    std::string rec_bin= model_path + "/face_rec.bin";
	// 加载人脸检测模型
    ret=face_det.load_param(face_param.data());
    ret=face_det.load_model(face_bin.data());
	// 加载人脸识别模型
    ret=face_rec.load_param(rec_param.data());
    ret=face_rec.load_model(rec_bin.data());
    return ret;
}


static __inline bool cmpScore(BboxFace lsh, BboxFace rsh)
{
    if (lsh.score < rsh.score)
        return true;
    else
        return false;
}


static void face_nms(std::vector<BboxFace>& boxes, const float overlap_threshold)
{
    if (boxes.empty())
    {
        return;
    }
    sort(boxes.begin(), boxes.end(), cmpScore);
    float IOU = 0;
    int maxX = 0;
    int maxY = 0;
    int minX = 0;
    int minY = 0;
    std::vector<int> vPick;
    int nPick = 0;
    std::multimap<unsigned int, int> vScores;
    const int num_boxes = (int)boxes.size();
    vPick.resize(num_boxes);
    for (int i = 0; i < num_boxes; ++i)
    {
        vScores.insert(std::pair<unsigned int, int>(boxes[i].score, i));
    }
    while (vScores.size() > 0)
    {
        int last = vScores.rbegin()->second;
        vPick[nPick] = last;
        nPick += 1;
        for (std::multimap<unsigned int, int>::iterator it = vScores.begin(); it != vScores.end();)
        {
            int it_idx = it->second;
            maxX = MAX(boxes.at(it_idx).x1, boxes.at(last).x1);
            maxY = MAX(boxes.at(it_idx).y1, boxes.at(last).y1);
            minX = MIN(boxes.at(it_idx).x2, boxes.at(last).x2);
            minY = MIN(boxes.at(it_idx).y2, boxes.at(last).y2);
            //maxX1 and maxY1 reuse
            maxX = ((minX - maxX + 1) > 0) ? (minX - maxX + 1) : 0;
            maxY = ((minY - maxY + 1) > 0) ? (minY - maxY + 1) : 0;
            //IOU reuse for the area of two bbox
            IOU = (float)maxX * maxY;
            IOU = IOU / (boxes.at(it_idx).area + boxes.at(last).area - IOU); // 暂时只支持相加，不支持最小框做分母
            if (IOU > overlap_threshold)
            {
                it = vScores.erase(it);
            }
            else
            {
                it++;
            }
        }
    }

    vPick.resize(nPick);
    std::vector<BboxFace> tmp_;
    tmp_.resize(nPick);
    for (int i = 0; i < nPick; i++)
    {
        tmp_[i] = boxes[vPick[i]];
    }
    boxes = tmp_;
}


static inline float sigmoid(float x)
{
    return 1.f / (1.f + exp(-x));
}


static inline float get_thr(const float x)
{
    float y = -log(1.0f / x - 1);
    return y;
}


//static double total_time = 0.0;
//static int total_det = 0;


float calculate_similarity(const float* feature1, const float* feature2) {
    float inner_product = 0.0f;
    float feature_norm1 = 0.0f;
    float feature_norm2 = 0.0f;
    for(int i = 0; i < FACE_FEATURE_LEN; ++i) {
        inner_product += feature1[i] * feature2[i];
        feature_norm1 += feature1[i] * feature1[i];
        feature_norm2 += feature2[i] * feature2[i];
    }
    return inner_product / sqrt(feature_norm1) / sqrt(feature_norm2);
}


// 人脸检测+人脸识别
std::vector<BboxFace> Facerec::recognize(cv::Mat& image, std::vector<FaceFeature> face_feats)
{
    int img_w = image.cols;
    int img_h = image.rows;

    // 数据预处理
    ncnn::Mat in = ncnn::Mat::from_pixels_resize(image.data, ncnn::Mat::PIXEL_BGR2RGB, \
                                                 img_w, img_h, face_width, face_height);
    // 创建网络执行器
    ncnn::Extractor ex = face_det.create_extractor();
    // 设置人脸检测网络输入
    ex.input("data", in);
    std::vector<BboxFace> boxes;
    float score_thr = get_thr(face_confidence_threshold);

    for (int feature_index = 0; feature_index < face_fpn_num; feature_index++)
    {
        ncnn::Mat out;

        char name[64];
        memset(name, 0, sizeof(name));
        sprintf(name, "face_output%d_out%d_fwd", feature_index, feature_index);
        ex.extract(name, out);

        for (int pp = 0; pp < face_anchor_num; pp++)
        {
            int p = pp * face_channels_per_box;

            //printf("%f %f\n", bias_w, bias_h);
            const float* xptr = out.channel(p + 0);
            const float* yptr = out.channel(p + 1);
            const float* wptr = out.channel(p + 2);
            const float* hptr = out.channel(p + 3);

            const float* box_score_ptr = out.channel(p + 4);

            for (int h = 0; h < out.h; h++)
            {
                for (int w = 0; w < out.w; w++)
                {
                    // box score
                    //float box_score = sigmoid(box_score_ptr[0]);
                    float box_score = box_score_ptr[0];
                    if (box_score > score_thr)
                    {
                        // region box
                        const float bias_w = face_anchor[feature_index * face_anchor_num * 2 + pp * 2 + 0];
                        const float bias_h = face_anchor[feature_index * face_anchor_num * 2 + pp * 2 + 1];
                        float bbox_cx = (w + xptr[0]) / out.w;
                        float bbox_cy = (h + yptr[0]) / out.h;
                        float bbox_w = exp(wptr[0]) * bias_w / face_width;
                        float bbox_h = exp(hptr[0]) * bias_h / face_height;
                        //printf("w:%f,h:%f\n", bbox_w, bbox_h);

                        float bbox_xmin = MID(bbox_cx - bbox_w * 0.5f, 0.0f, 1.0f);
                        float bbox_ymin = MID(bbox_cy - bbox_h * 0.5f, 0.0f, 1.0f);
                        float bbox_xmax = MID(bbox_cx + bbox_w * 0.5f, 0.0f, 1.0f);
                        float bbox_ymax = MID(bbox_cy + bbox_h * 0.5f, 0.0f, 1.0f);

                        int class_index = 0;
                        float class_score = 0.f;
                        for (int q = 0; q < face_num_class; q++)
                        {
                            ncnn::Mat scores = out.channel_range(p + 5, face_num_class);
                            float score = sigmoid(scores.channel(q).row(h)[w]);
                            if (score > class_score)
                            {
                                class_index = q;
                                class_score = score;
                            }
                        }

                        BboxFace bbox;
                        memset(&bbox, 0, sizeof(BboxFace));
                        bbox.id = (unsigned int)class_index;
                        bbox.score = (unsigned int)(sigmoid(box_score) * 100);

                        bbox.x1 = (int)round(bbox_xmin * face_width);
                        bbox.y1 = (int)round(bbox_ymin * face_height);
                        bbox.x2 = (int)round(bbox_xmax * face_width);
                        bbox.y2 = (int)round(bbox_ymax * face_height);

                        bbox.area = (float)(bbox.x2 - bbox.x1 + 1) * (bbox.y2 - bbox.y1 + 1);
                        //memcpy(bbox.face_emb, box_emb_ptr, TRACK_EMB_SIZE);

                        if (bbox.x2 > bbox.x1 && bbox.y2 > bbox.y1)
                        {
                            boxes.push_back(bbox);
                            //printf("w:%f,h:%f\n", (float)(bbox.x2 - bbox.x1), (float)(bbox.y2 - bbox.y1));
                        }
                    }

                    xptr++;
                    yptr++;
                    wptr++;
                    hptr++;

                    box_score_ptr++;
                }
            }
        }
    }

    // nms
    face_nms(boxes, face_nms_threshold);

    cv::Scalar color = cv::Scalar(0, 255, 0);

    for (std::vector<struct BboxFace>::iterator it = boxes.begin(); it != boxes.end(); it++)
    {
        ncnn::Mat tempIm;
        ncnn::copy_cut_border(in, tempIm, it->y1, face_height - it->y2, it->x1, face_width - it->x2);
        int origin_x1 = it->x1 * img_w / face_width;
        int origin_y1 = it->y1 * img_h / face_height;
        int origin_x2 = it->x2 * img_w / face_width;
        int origin_y2 = it->y2 * img_h / face_height;

        float* pData = NULL;
        cv::rectangle(image, cv::Point2d(origin_x1, origin_y1), cv::Point2d(origin_x2, origin_y2), color, 2);
        // 人脸识别
        ncnn::Mat rec_img;
        ncnn::resize_bilinear(tempIm, rec_img, rec_width, rec_height);

        float norm_vals[3] = {1.0f/256.0f, 1.0f/256.0f, 1.0f/256.0f};
        rec_img.substract_mean_normalize(NULL, norm_vals);

        ncnn::Extractor ex_rec = face_rec.create_extractor();
        ex_rec.input("data", rec_img);

        ncnn::Mat out_rec;
        ex_rec.extract("mobileclip0_feature_flatten0_flatten0", out_rec);
        pData = (float*)out_rec.data;
        float mod_sum = 0.0f;
        for (int i = 0; i < out_rec.w; i++)
        {
            it->rec.data[i] = pData[i];
            mod_sum += (pData[i] * pData[i]);
        }
        mod_sum = 1.0f / sqrtf(mod_sum);

        for (int i = 0; i < out_rec.w; i++)
        {
            it->rec.data[i] *= mod_sum;
        }

        float max_sim = 0.f;
        std::string max_name;
        for (unsigned int j = 0; j < face_feats.size(); j++){
            float sim = calculate_similarity(it->rec.data, face_feats[j].face_feature);
            if (sim > max_sim){
                max_sim = sim;
                max_name = face_feats[j].name;
            }
        }

        if (max_sim < 0.5){
            max_name = "unkown";
            max_sim = 0.f;
        }

        cv::putText(image, "person: " + max_name, cv::Point2d(origin_x1, origin_y1 - 5),
                cv::FONT_HERSHEY_PLAIN, 1.5f, cv::Scalar(255, 255, 0), 2);
    }
    return boxes;
}


