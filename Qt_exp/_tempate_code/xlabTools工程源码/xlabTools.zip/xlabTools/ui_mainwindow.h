/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionZigBee;
    QAction *actionLoRa;
    QAction *action4G;
    QAction *actionNB_IoT;
    QAction *actionabout;
    QAction *actionWiFi;
    QAction *actionWiFi2;
    QAction *actionBLE;
    QAction *action_save;
    QAction *actionLoRaWAN;
    QAction *actionCAT1;
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_36;
    QVBoxLayout *verticalLayout_37;
    QHBoxLayout *horizontalLayout_33;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_13;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_Com;
    QComboBox *comboBox_Com;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_Baud;
    QComboBox *comboBox_Baud;
    QVBoxLayout *verticalLayout_10;
    QPushButton *pushButton_OpenCom;
    QPushButton *pushButton_OpenRec;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QHBoxLayout *horizontalLayout_15;
    QGroupBox *groupBox_ZigBee;
    QHBoxLayout *horizontalLayout_14;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_Name_text;
    QLabel *label_Panid_text;
    QVBoxLayout *verticalLayout_6;
    QLineEdit *lineEdit_Add;
    QLineEdit *lineEdit_Panid;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_Type_text;
    QLabel *label_Channel_text;
    QVBoxLayout *verticalLayout_8;
    QComboBox *comboBox_Mold;
    QComboBox *comboBox_Channel;
    QVBoxLayout *verticalLayout_9;
    QPushButton *pushButton_Read;
    QPushButton *pushButton_Write;
    QWidget *page_2;
    QHBoxLayout *horizontalLayout_34;
    QGroupBox *groupBox_LoRa;
    QHBoxLayout *horizontalLayout_32;
    QVBoxLayout *verticalLayout_32;
    QHBoxLayout *horizontalLayout_21;
    QVBoxLayout *verticalLayout_30;
    QLabel *label_17;
    QLabel *label_18;
    QVBoxLayout *verticalLayout_31;
    QLineEdit *LoRa_lineEdit_Add;
    QLineEdit *LoRa_lineEdit_Type;
    QVBoxLayout *verticalLayout_19;
    QLabel *label_12;
    QLabel *label_10;
    QVBoxLayout *verticalLayout_20;
    QLineEdit *LoRa_lineEdit_ID;
    QComboBox *LoRa_comboBox_CR;
    QVBoxLayout *verticalLayout_21;
    QLabel *label_7;
    QLabel *label_9;
    QVBoxLayout *verticalLayout_22;
    QLineEdit *LoRa_lineEdit_PV;
    QComboBox *LoRa_comboBox_SF;
    QVBoxLayout *verticalLayout_23;
    QLabel *label_8;
    QLabel *label_11;
    QVBoxLayout *verticalLayout_24;
    QLineEdit *LoRa_lineEdit_FP;
    QComboBox *LoRa_comboBox_BW;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_6;
    QLabel *label;
    QVBoxLayout *verticalLayout_11;
    QLineEdit *LoRa_lineEdit_PS;
    QComboBox *LoRa_comboBox_HOP;
    QVBoxLayout *verticalLayout_25;
    QPushButton *LoRa_pushButton_Read;
    QPushButton *LoRa_pushButton_Write;
    QHBoxLayout *horizontalLayout_29;
    QLabel *LoRa_label_HOP_List;
    QLineEdit *LoRa_lineEdit_HOP_List;
    QWidget *page_4G;
    QHBoxLayout *horizontalLayout_23;
    QGroupBox *groupBox_LTE;
    QHBoxLayout *horizontalLayout_24;
    QHBoxLayout *horizontalLayout_16;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_14;
    QLabel *label_2;
    QVBoxLayout *verticalLayout_13;
    QLineEdit *G_lineEdit_Add;
    QLineEdit *G_lineEdit_ID;
    QVBoxLayout *verticalLayout_12;
    QLabel *label_13;
    QLabel *label_3;
    QVBoxLayout *verticalLayout_26;
    QLineEdit *G_lineEdit_Sever;
    QLineEdit *G_lineEdit_Key;
    QVBoxLayout *verticalLayout_14;
    QPushButton *G_pushButton_Read;
    QPushButton *G_pushButton_Write;
    QPushButton *G_pushButton_Shore;
    QWidget *page_NB;
    QHBoxLayout *horizontalLayout_31;
    QGroupBox *groupBox_NB;
    QHBoxLayout *horizontalLayout_27;
    QHBoxLayout *horizontalLayout_26;
    QVBoxLayout *verticalLayout_15;
    QLabel *label_16;
    QLabel *label_4;
    QVBoxLayout *verticalLayout_16;
    QLineEdit *NB_lineEdit_Add;
    QLineEdit *NB_lineEdit_ID;
    QVBoxLayout *verticalLayout_17;
    QLabel *label_15;
    QLabel *label_5;
    QVBoxLayout *verticalLayout_27;
    QHBoxLayout *horizontalLayout_25;
    QLineEdit *NB_lineEdit_Sever;
    QLabel *label_26;
    QComboBox *NB_cbx_mode;
    QLineEdit *NB_lineEdit_Key;
    QVBoxLayout *verticalLayout_28;
    QPushButton *NB_pushButton_Read;
    QPushButton *NB_pushButton_Write;
    QPushButton *NB_pushButton_Share;
    QWidget *page_3;
    QHBoxLayout *horizontalLayout_30;
    QGroupBox *groupBox_WiFi;
    QHBoxLayout *horizontalLayout_28;
    QHBoxLayout *horizontalLayout_22;
    QVBoxLayout *verticalLayout_29;
    QLabel *label_25;
    QLabel *label_19;
    QVBoxLayout *verticalLayout_34;
    QLineEdit *WiFi_lineEdit_Add;
    QLineEdit *WiFi_lineEdit_SSID;
    QVBoxLayout *verticalLayout_35;
    QLabel *label_22;
    QLabel *WiFi_label_Pass;
    QVBoxLayout *verticalLayout_36;
    QLineEdit *WiFi_lineEdit_IPAdd;
    QLineEdit *WiFi_lineEdit_PSKPpass;
    QVBoxLayout *verticalLayout_42;
    QLabel *label_21;
    QLabel *label_20;
    QVBoxLayout *verticalLayout_43;
    QLineEdit *WiFi_lineEdit_OwnIp;
    QComboBox *WiFi_comboBox_PassType;
    QVBoxLayout *verticalLayout_38;
    QPushButton *WiFi_pushButton_Read;
    QPushButton *WiFi_pushButton_Write;
    QWidget *page_4;
    QHBoxLayout *horizontalLayout_18;
    QGroupBox *groupBox_BLE;
    QHBoxLayout *horizontalLayout_35;
    QHBoxLayout *horizontalLayout_20;
    QVBoxLayout *verticalLayout_39;
    QLabel *label_23;
    QLabel *label_24;
    QVBoxLayout *verticalLayout_40;
    QLineEdit *BLE_lineEdit_Mac;
    QLineEdit *BLE_lineEdit_Link;
    QVBoxLayout *verticalLayout_41;
    QPushButton *BLE_pushButton_ReadMac;
    QPushButton *BLE_pushButton_TextLink;
    QWidget *page_5;
    QHBoxLayout *horizontalLayout_38;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout_40;
    QHBoxLayout *horizontalLayout_39;
    QGridLayout *gridLayout_3;
    QLabel *label_27;
    QLineEdit *LoRaWAN_le_deveui;
    QLabel *label_30;
    QLineEdit *LoRaWAN_le_key;
    QLabel *label_29;
    QComboBox *LoRaWAN_cmb_zkey;
    QLabel *label_33;
    QComboBox *LoRaWAN_cmb_ddr;
    QLabel *label_28;
    QLineEdit *LoRaWAN_le_joineui;
    QLabel *label_32;
    QHBoxLayout *horizontalLayout_37;
    QLineEdit *LoRaWAN_le_chm;
    QPushButton *LoRaWAN_btn_setChm;
    QLabel *label_31;
    QComboBox *LoRaWAN_cmb_class;
    QLabel *label_34;
    QComboBox *LoRaWAN_cmb_adr;
    QVBoxLayout *verticalLayout_44;
    QPushButton *LoRaWAN_btn_Read;
    QPushButton *LoRaWAN_btn_Write;
    QWidget *page_CAT1;
    QHBoxLayout *horizontalLayout_44;
    QGroupBox *groupBox_CAT1;
    QHBoxLayout *horizontalLayout_41;
    QHBoxLayout *horizontalLayout_42;
    QVBoxLayout *verticalLayout_45;
    QLabel *label_35;
    QLabel *label_36;
    QVBoxLayout *verticalLayout_46;
    QLineEdit *CAT1_lineEdit_Add;
    QLineEdit *CAT1_lineEdit_ID;
    QVBoxLayout *verticalLayout_47;
    QLabel *label_37;
    QLabel *label_38;
    QVBoxLayout *verticalLayout_48;
    QHBoxLayout *horizontalLayout_43;
    QLineEdit *CAT1_lineEdit_Sever;
    QLineEdit *CAT1_lineEdit_Key;
    QVBoxLayout *verticalLayout_49;
    QPushButton *CAT1_pushButton_Read;
    QPushButton *CAT1_pushButton_Write;
    QPushButton *CAT1_pushButton_Share;
    QWidget *page_esp;
    QHBoxLayout *horizontalLayout_302;
    QGroupBox *groupBox_WiFi2;
    QHBoxLayout *horizontalLayout_282;
    QHBoxLayout *horizontalLayout_222;
    QVBoxLayout *verticalLayout_292;
    QLabel *label_252;
    QLabel *label_192;
    QVBoxLayout *verticalLayout_342;
    QLineEdit *ESP8266_lineEdit_Mac;
    QLineEdit *ESP8266_lineEdit_SIP;
    QVBoxLayout *verticalLayout_352;
    QLabel *label_222;
    QLabel *ESP8266_label_Pass;
    QVBoxLayout *verticalLayout_362;
    QLineEdit *ESP8266_lineEdit_SSID;
    QLineEdit *ESP8266_lineEdit_AID;
    QVBoxLayout *verticalLayout_422;
    QLabel *label_212;
    QLabel *label_202;
    QVBoxLayout *verticalLayout_432;
    QLineEdit *ESP8266_lineEdit_Key;
    QLineEdit *ESP8266_lineEdit_AKey;
    QVBoxLayout *verticalLayout_382;
    QPushButton *ESP8266_pushButton_Read;
    QPushButton *ESP8266_pushButton_Write;
    QVBoxLayout *verticalLayout_50;
    QComboBox *ESP8266_comboBox_mode;
    QPushButton *ESP8266_btn_share;
    QGroupBox *groupBox_8;
    QHBoxLayout *horizontalLayout_19;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_Set_Rec;
    QComboBox *comboBox_Set_Rec;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_Set_Send;
    QComboBox *comboBox_Set_Send;
    QGroupBox *groupBox_7;
    QHBoxLayout *horizontalLayout_10;
    QVBoxLayout *verticalLayout_18;
    QPushButton *pushButton_DelRec;
    QPushButton *pushButton_DelSend;
    QHBoxLayout *horizontalLayout_8;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_4;
    QListWidget *listWidget_Rec;
    QVBoxLayout *verticalLayout_33;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout_7;
    QGridLayout *gridLayout_2;
    QLabel *label_RecSop;
    QLineEdit *lineEdit_RecSop;
    QLabel *label_RecLen;
    QLineEdit *lineEdit_RecLen;
    QLabel *label_RecCmd;
    QLineEdit *lineEdit_RecCmd;
    QLabel *label_RecNa;
    QLineEdit *lineEdit_RecNa;
    QLabel *label_RecAppCmd;
    QLineEdit *lineEdit_RecAppCmd;
    QLabel *label_Recrelease;
    QLineEdit *lineEdit_release;
    QLabel *label_RecAppData;
    QLineEdit *lineEdit_RecAppData;
    QLabel *label_RecFcs;
    QLineEdit *lineEdit_RecFcs;
    QGroupBox *groupBox_6;
    QHBoxLayout *horizontalLayout_5;
    QGridLayout *gridLayout;
    QLabel *label_SendSop;
    QLineEdit *lineEdit_SendSop;
    QLabel *label_SendLen;
    QLineEdit *lineEdit_SendLen;
    QLabel *label_Send_Cmd;
    QLineEdit *lineEdit_Send_Cmd;
    QLabel *label_SendNa;
    QLineEdit *lineEdit_SendNa;
    QLabel *label_SendCmd;
    QComboBox *comboBox_Send_AppCmd;
    QLabel *LoRa_label_release;
    QLineEdit *LoRa_lineEdit_release;
    QLabel *label_SendData;
    QHBoxLayout *horizontalLayout_6;
    QLineEdit *lineEdit_SendData;
    QLineEdit *le_sendTime;
    QCheckBox *chk_sendEnd;
    QPushButton *pushButton_Send;
    QLabel *label_SendFcs;
    QLineEdit *lineEdit_SendFcs;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_StateText;
    QLabel *label_State;
    QFrame *line;
    QSpacerItem *horizontalSpacer_3;
    QLabel *lbl_version;
    QSpacerItem *horizontalSpacer_2;
    QFrame *line_2;
    QLabel *label_CountRecv;
    QLabel *label_CountRecvNum;
    QLabel *label_CountSend;
    QLabel *label_CountSendNum;
    QPushButton *pushButton_DelNum;
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1145, 690);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMaximumSize(QSize(16777215, 16777215));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/icon/image/xLabTools.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        actionZigBee = new QAction(MainWindow);
        actionZigBee->setObjectName(QString::fromUtf8("actionZigBee"));
        actionZigBee->setCheckable(true);
        actionLoRa = new QAction(MainWindow);
        actionLoRa->setObjectName(QString::fromUtf8("actionLoRa"));
        actionLoRa->setCheckable(true);
        action4G = new QAction(MainWindow);
        action4G->setObjectName(QString::fromUtf8("action4G"));
        action4G->setCheckable(true);
        actionNB_IoT = new QAction(MainWindow);
        actionNB_IoT->setObjectName(QString::fromUtf8("actionNB_IoT"));
        actionNB_IoT->setCheckable(true);
        actionabout = new QAction(MainWindow);
        actionabout->setObjectName(QString::fromUtf8("actionabout"));
        actionWiFi = new QAction(MainWindow);
        actionWiFi->setObjectName(QString::fromUtf8("actionWiFi"));
        actionWiFi->setCheckable(true);
        actionWiFi2 = new QAction(MainWindow);
        actionWiFi2->setObjectName(QString::fromUtf8("actionWiFi2"));
        actionWiFi2->setCheckable(true);
        actionBLE = new QAction(MainWindow);
        actionBLE->setObjectName(QString::fromUtf8("actionBLE"));
        actionBLE->setCheckable(true);
        action_save = new QAction(MainWindow);
        action_save->setObjectName(QString::fromUtf8("action_save"));
        actionLoRaWAN = new QAction(MainWindow);
        actionLoRaWAN->setObjectName(QString::fromUtf8("actionLoRaWAN"));
        actionLoRaWAN->setCheckable(true);
        actionCAT1 = new QAction(MainWindow);
        actionCAT1->setObjectName(QString::fromUtf8("actionCAT1"));
        actionCAT1->setCheckable(true);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout_36 = new QHBoxLayout(centralWidget);
        horizontalLayout_36->setSpacing(6);
        horizontalLayout_36->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_36->setObjectName(QString::fromUtf8("horizontalLayout_36"));
        verticalLayout_37 = new QVBoxLayout();
        verticalLayout_37->setSpacing(0);
        verticalLayout_37->setObjectName(QString::fromUtf8("verticalLayout_37"));
        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setSpacing(0);
        horizontalLayout_33->setObjectName(QString::fromUtf8("horizontalLayout_33"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy1);
        horizontalLayout_13 = new QHBoxLayout(groupBox);
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetFixedSize);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_Com = new QLabel(groupBox);
        label_Com->setObjectName(QString::fromUtf8("label_Com"));
        sizePolicy1.setHeightForWidth(label_Com->sizePolicy().hasHeightForWidth());
        label_Com->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(label_Com);

        comboBox_Com = new QComboBox(groupBox);
        comboBox_Com->setObjectName(QString::fromUtf8("comboBox_Com"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(comboBox_Com->sizePolicy().hasHeightForWidth());
        comboBox_Com->setSizePolicy(sizePolicy2);
        comboBox_Com->setMouseTracking(false);
        comboBox_Com->setTabletTracking(false);
        comboBox_Com->setFocusPolicy(Qt::WheelFocus);
        comboBox_Com->setInputMethodHints(Qt::ImhNone);

        horizontalLayout->addWidget(comboBox_Com);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_Baud = new QLabel(groupBox);
        label_Baud->setObjectName(QString::fromUtf8("label_Baud"));
        sizePolicy1.setHeightForWidth(label_Baud->sizePolicy().hasHeightForWidth());
        label_Baud->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(label_Baud);

        comboBox_Baud = new QComboBox(groupBox);
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->addItem(QString());
        comboBox_Baud->setObjectName(QString::fromUtf8("comboBox_Baud"));
        sizePolicy2.setHeightForWidth(comboBox_Baud->sizePolicy().hasHeightForWidth());
        comboBox_Baud->setSizePolicy(sizePolicy2);

        horizontalLayout_2->addWidget(comboBox_Baud);


        verticalLayout->addLayout(horizontalLayout_2);


        horizontalLayout_3->addLayout(verticalLayout);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        pushButton_OpenCom = new QPushButton(groupBox);
        pushButton_OpenCom->setObjectName(QString::fromUtf8("pushButton_OpenCom"));
        sizePolicy1.setHeightForWidth(pushButton_OpenCom->sizePolicy().hasHeightForWidth());
        pushButton_OpenCom->setSizePolicy(sizePolicy1);

        verticalLayout_10->addWidget(pushButton_OpenCom);

        pushButton_OpenRec = new QPushButton(groupBox);
        pushButton_OpenRec->setObjectName(QString::fromUtf8("pushButton_OpenRec"));
        sizePolicy1.setHeightForWidth(pushButton_OpenRec->sizePolicy().hasHeightForWidth());
        pushButton_OpenRec->setSizePolicy(sizePolicy1);

        verticalLayout_10->addWidget(pushButton_OpenRec);


        horizontalLayout_3->addLayout(verticalLayout_10);


        horizontalLayout_13->addLayout(horizontalLayout_3);


        horizontalLayout_33->addWidget(groupBox);

        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Maximum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy3);
        stackedWidget->setFocusPolicy(Qt::NoFocus);
        stackedWidget->setAcceptDrops(false);
        stackedWidget->setFrameShape(QFrame::NoFrame);
        stackedWidget->setFrameShadow(QFrame::Plain);
        stackedWidget->setLineWidth(0);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        horizontalLayout_15 = new QHBoxLayout(page);
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        groupBox_ZigBee = new QGroupBox(page);
        groupBox_ZigBee->setObjectName(QString::fromUtf8("groupBox_ZigBee"));
        sizePolicy2.setHeightForWidth(groupBox_ZigBee->sizePolicy().hasHeightForWidth());
        groupBox_ZigBee->setSizePolicy(sizePolicy2);
        groupBox_ZigBee->setMinimumSize(QSize(0, 88));
        horizontalLayout_14 = new QHBoxLayout(groupBox_ZigBee);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(9, 9, -1, -1);
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label_Name_text = new QLabel(groupBox_ZigBee);
        label_Name_text->setObjectName(QString::fromUtf8("label_Name_text"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(label_Name_text->sizePolicy().hasHeightForWidth());
        label_Name_text->setSizePolicy(sizePolicy4);

        verticalLayout_5->addWidget(label_Name_text);

        label_Panid_text = new QLabel(groupBox_ZigBee);
        label_Panid_text->setObjectName(QString::fromUtf8("label_Panid_text"));

        verticalLayout_5->addWidget(label_Panid_text);


        horizontalLayout_9->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        lineEdit_Add = new QLineEdit(groupBox_ZigBee);
        lineEdit_Add->setObjectName(QString::fromUtf8("lineEdit_Add"));
        sizePolicy2.setHeightForWidth(lineEdit_Add->sizePolicy().hasHeightForWidth());
        lineEdit_Add->setSizePolicy(sizePolicy2);
        lineEdit_Add->setMinimumSize(QSize(0, 0));
        lineEdit_Add->setReadOnly(true);

        verticalLayout_6->addWidget(lineEdit_Add);

        lineEdit_Panid = new QLineEdit(groupBox_ZigBee);
        lineEdit_Panid->setObjectName(QString::fromUtf8("lineEdit_Panid"));
        sizePolicy2.setHeightForWidth(lineEdit_Panid->sizePolicy().hasHeightForWidth());
        lineEdit_Panid->setSizePolicy(sizePolicy2);
        lineEdit_Panid->setMinimumSize(QSize(0, 0));

        verticalLayout_6->addWidget(lineEdit_Panid);


        horizontalLayout_9->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        label_Type_text = new QLabel(groupBox_ZigBee);
        label_Type_text->setObjectName(QString::fromUtf8("label_Type_text"));
        sizePolicy4.setHeightForWidth(label_Type_text->sizePolicy().hasHeightForWidth());
        label_Type_text->setSizePolicy(sizePolicy4);

        verticalLayout_7->addWidget(label_Type_text);

        label_Channel_text = new QLabel(groupBox_ZigBee);
        label_Channel_text->setObjectName(QString::fromUtf8("label_Channel_text"));

        verticalLayout_7->addWidget(label_Channel_text);


        horizontalLayout_9->addLayout(verticalLayout_7);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setSizeConstraint(QLayout::SetDefaultConstraint);
        comboBox_Mold = new QComboBox(groupBox_ZigBee);
        comboBox_Mold->addItem(QString());
        comboBox_Mold->addItem(QString());
        comboBox_Mold->addItem(QString());
        comboBox_Mold->setObjectName(QString::fromUtf8("comboBox_Mold"));
        sizePolicy2.setHeightForWidth(comboBox_Mold->sizePolicy().hasHeightForWidth());
        comboBox_Mold->setSizePolicy(sizePolicy2);
        comboBox_Mold->setMinimumSize(QSize(0, 0));

        verticalLayout_8->addWidget(comboBox_Mold);

        comboBox_Channel = new QComboBox(groupBox_ZigBee);
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->addItem(QString());
        comboBox_Channel->setObjectName(QString::fromUtf8("comboBox_Channel"));
        sizePolicy2.setHeightForWidth(comboBox_Channel->sizePolicy().hasHeightForWidth());
        comboBox_Channel->setSizePolicy(sizePolicy2);
        comboBox_Channel->setMinimumSize(QSize(0, 0));

        verticalLayout_8->addWidget(comboBox_Channel);


        horizontalLayout_9->addLayout(verticalLayout_8);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        pushButton_Read = new QPushButton(groupBox_ZigBee);
        pushButton_Read->setObjectName(QString::fromUtf8("pushButton_Read"));
        QSizePolicy sizePolicy5(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(pushButton_Read->sizePolicy().hasHeightForWidth());
        pushButton_Read->setSizePolicy(sizePolicy5);

        verticalLayout_9->addWidget(pushButton_Read);

        pushButton_Write = new QPushButton(groupBox_ZigBee);
        pushButton_Write->setObjectName(QString::fromUtf8("pushButton_Write"));
        sizePolicy5.setHeightForWidth(pushButton_Write->sizePolicy().hasHeightForWidth());
        pushButton_Write->setSizePolicy(sizePolicy5);

        verticalLayout_9->addWidget(pushButton_Write);


        horizontalLayout_9->addLayout(verticalLayout_9);


        horizontalLayout_14->addLayout(horizontalLayout_9);


        horizontalLayout_15->addWidget(groupBox_ZigBee);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        horizontalLayout_34 = new QHBoxLayout(page_2);
        horizontalLayout_34->setSpacing(6);
        horizontalLayout_34->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_34->setObjectName(QString::fromUtf8("horizontalLayout_34"));
        groupBox_LoRa = new QGroupBox(page_2);
        groupBox_LoRa->setObjectName(QString::fromUtf8("groupBox_LoRa"));
        QSizePolicy sizePolicy6(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(groupBox_LoRa->sizePolicy().hasHeightForWidth());
        groupBox_LoRa->setSizePolicy(sizePolicy6);
        horizontalLayout_32 = new QHBoxLayout(groupBox_LoRa);
        horizontalLayout_32->setSpacing(6);
        horizontalLayout_32->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_32->setObjectName(QString::fromUtf8("horizontalLayout_32"));
        horizontalLayout_32->setContentsMargins(9, 9, 9, 9);
        verticalLayout_32 = new QVBoxLayout();
        verticalLayout_32->setSpacing(6);
        verticalLayout_32->setObjectName(QString::fromUtf8("verticalLayout_32"));
        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        horizontalLayout_21->setContentsMargins(0, 0, -1, -1);
        verticalLayout_30 = new QVBoxLayout();
        verticalLayout_30->setSpacing(6);
        verticalLayout_30->setObjectName(QString::fromUtf8("verticalLayout_30"));
        label_17 = new QLabel(groupBox_LoRa);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout_30->addWidget(label_17);

        label_18 = new QLabel(groupBox_LoRa);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        verticalLayout_30->addWidget(label_18);


        horizontalLayout_21->addLayout(verticalLayout_30);

        verticalLayout_31 = new QVBoxLayout();
        verticalLayout_31->setSpacing(6);
        verticalLayout_31->setObjectName(QString::fromUtf8("verticalLayout_31"));
        LoRa_lineEdit_Add = new QLineEdit(groupBox_LoRa);
        LoRa_lineEdit_Add->setObjectName(QString::fromUtf8("LoRa_lineEdit_Add"));
        sizePolicy2.setHeightForWidth(LoRa_lineEdit_Add->sizePolicy().hasHeightForWidth());
        LoRa_lineEdit_Add->setSizePolicy(sizePolicy2);
        LoRa_lineEdit_Add->setMinimumSize(QSize(0, 0));
        LoRa_lineEdit_Add->setMaximumSize(QSize(16777215, 16777215));
        LoRa_lineEdit_Add->setReadOnly(true);

        verticalLayout_31->addWidget(LoRa_lineEdit_Add);

        LoRa_lineEdit_Type = new QLineEdit(groupBox_LoRa);
        LoRa_lineEdit_Type->setObjectName(QString::fromUtf8("LoRa_lineEdit_Type"));
        sizePolicy2.setHeightForWidth(LoRa_lineEdit_Type->sizePolicy().hasHeightForWidth());
        LoRa_lineEdit_Type->setSizePolicy(sizePolicy2);
        LoRa_lineEdit_Type->setMinimumSize(QSize(0, 0));
        LoRa_lineEdit_Type->setMaximumSize(QSize(16777215, 16777215));
        LoRa_lineEdit_Type->setReadOnly(true);

        verticalLayout_31->addWidget(LoRa_lineEdit_Type);


        horizontalLayout_21->addLayout(verticalLayout_31);

        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setSpacing(6);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        label_12 = new QLabel(groupBox_LoRa);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout_19->addWidget(label_12);

        label_10 = new QLabel(groupBox_LoRa);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout_19->addWidget(label_10);


        horizontalLayout_21->addLayout(verticalLayout_19);

        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setSpacing(6);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        LoRa_lineEdit_ID = new QLineEdit(groupBox_LoRa);
        LoRa_lineEdit_ID->setObjectName(QString::fromUtf8("LoRa_lineEdit_ID"));
        sizePolicy2.setHeightForWidth(LoRa_lineEdit_ID->sizePolicy().hasHeightForWidth());
        LoRa_lineEdit_ID->setSizePolicy(sizePolicy2);
        LoRa_lineEdit_ID->setMinimumSize(QSize(0, 0));

        verticalLayout_20->addWidget(LoRa_lineEdit_ID);

        LoRa_comboBox_CR = new QComboBox(groupBox_LoRa);
        LoRa_comboBox_CR->addItem(QString());
        LoRa_comboBox_CR->addItem(QString());
        LoRa_comboBox_CR->addItem(QString());
        LoRa_comboBox_CR->addItem(QString());
        LoRa_comboBox_CR->setObjectName(QString::fromUtf8("LoRa_comboBox_CR"));
        sizePolicy2.setHeightForWidth(LoRa_comboBox_CR->sizePolicy().hasHeightForWidth());
        LoRa_comboBox_CR->setSizePolicy(sizePolicy2);
        LoRa_comboBox_CR->setMinimumSize(QSize(0, 0));

        verticalLayout_20->addWidget(LoRa_comboBox_CR);


        horizontalLayout_21->addLayout(verticalLayout_20);

        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setSpacing(6);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        label_7 = new QLabel(groupBox_LoRa);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_21->addWidget(label_7);

        label_9 = new QLabel(groupBox_LoRa);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout_21->addWidget(label_9);


        horizontalLayout_21->addLayout(verticalLayout_21);

        verticalLayout_22 = new QVBoxLayout();
        verticalLayout_22->setSpacing(6);
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        LoRa_lineEdit_PV = new QLineEdit(groupBox_LoRa);
        LoRa_lineEdit_PV->setObjectName(QString::fromUtf8("LoRa_lineEdit_PV"));
        sizePolicy2.setHeightForWidth(LoRa_lineEdit_PV->sizePolicy().hasHeightForWidth());
        LoRa_lineEdit_PV->setSizePolicy(sizePolicy2);
        LoRa_lineEdit_PV->setMinimumSize(QSize(0, 0));

        verticalLayout_22->addWidget(LoRa_lineEdit_PV);

        LoRa_comboBox_SF = new QComboBox(groupBox_LoRa);
        LoRa_comboBox_SF->addItem(QString());
        LoRa_comboBox_SF->addItem(QString());
        LoRa_comboBox_SF->addItem(QString());
        LoRa_comboBox_SF->addItem(QString());
        LoRa_comboBox_SF->addItem(QString());
        LoRa_comboBox_SF->addItem(QString());
        LoRa_comboBox_SF->addItem(QString());
        LoRa_comboBox_SF->setObjectName(QString::fromUtf8("LoRa_comboBox_SF"));
        sizePolicy2.setHeightForWidth(LoRa_comboBox_SF->sizePolicy().hasHeightForWidth());
        LoRa_comboBox_SF->setSizePolicy(sizePolicy2);
        LoRa_comboBox_SF->setMinimumSize(QSize(0, 0));

        verticalLayout_22->addWidget(LoRa_comboBox_SF);


        horizontalLayout_21->addLayout(verticalLayout_22);

        verticalLayout_23 = new QVBoxLayout();
        verticalLayout_23->setSpacing(6);
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        label_8 = new QLabel(groupBox_LoRa);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_23->addWidget(label_8);

        label_11 = new QLabel(groupBox_LoRa);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        verticalLayout_23->addWidget(label_11);


        horizontalLayout_21->addLayout(verticalLayout_23);

        verticalLayout_24 = new QVBoxLayout();
        verticalLayout_24->setSpacing(6);
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        LoRa_lineEdit_FP = new QLineEdit(groupBox_LoRa);
        LoRa_lineEdit_FP->setObjectName(QString::fromUtf8("LoRa_lineEdit_FP"));
        sizePolicy2.setHeightForWidth(LoRa_lineEdit_FP->sizePolicy().hasHeightForWidth());
        LoRa_lineEdit_FP->setSizePolicy(sizePolicy2);
        LoRa_lineEdit_FP->setMinimumSize(QSize(0, 0));

        verticalLayout_24->addWidget(LoRa_lineEdit_FP);

        LoRa_comboBox_BW = new QComboBox(groupBox_LoRa);
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->addItem(QString());
        LoRa_comboBox_BW->setObjectName(QString::fromUtf8("LoRa_comboBox_BW"));
        sizePolicy2.setHeightForWidth(LoRa_comboBox_BW->sizePolicy().hasHeightForWidth());
        LoRa_comboBox_BW->setSizePolicy(sizePolicy2);
        LoRa_comboBox_BW->setMinimumSize(QSize(0, 0));

        verticalLayout_24->addWidget(LoRa_comboBox_BW);


        horizontalLayout_21->addLayout(verticalLayout_24);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_6 = new QLabel(groupBox_LoRa);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_2->addWidget(label_6);

        label = new QLabel(groupBox_LoRa);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_2->addWidget(label);


        horizontalLayout_21->addLayout(verticalLayout_2);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        LoRa_lineEdit_PS = new QLineEdit(groupBox_LoRa);
        LoRa_lineEdit_PS->setObjectName(QString::fromUtf8("LoRa_lineEdit_PS"));
        sizePolicy2.setHeightForWidth(LoRa_lineEdit_PS->sizePolicy().hasHeightForWidth());
        LoRa_lineEdit_PS->setSizePolicy(sizePolicy2);
        LoRa_lineEdit_PS->setMinimumSize(QSize(0, 0));

        verticalLayout_11->addWidget(LoRa_lineEdit_PS);

        LoRa_comboBox_HOP = new QComboBox(groupBox_LoRa);
        LoRa_comboBox_HOP->addItem(QString());
        LoRa_comboBox_HOP->addItem(QString());
        LoRa_comboBox_HOP->setObjectName(QString::fromUtf8("LoRa_comboBox_HOP"));
        sizePolicy2.setHeightForWidth(LoRa_comboBox_HOP->sizePolicy().hasHeightForWidth());
        LoRa_comboBox_HOP->setSizePolicy(sizePolicy2);
        LoRa_comboBox_HOP->setMinimumSize(QSize(0, 0));

        verticalLayout_11->addWidget(LoRa_comboBox_HOP);


        horizontalLayout_21->addLayout(verticalLayout_11);

        verticalLayout_25 = new QVBoxLayout();
        verticalLayout_25->setSpacing(6);
        verticalLayout_25->setObjectName(QString::fromUtf8("verticalLayout_25"));
        LoRa_pushButton_Read = new QPushButton(groupBox_LoRa);
        LoRa_pushButton_Read->setObjectName(QString::fromUtf8("LoRa_pushButton_Read"));

        verticalLayout_25->addWidget(LoRa_pushButton_Read);

        LoRa_pushButton_Write = new QPushButton(groupBox_LoRa);
        LoRa_pushButton_Write->setObjectName(QString::fromUtf8("LoRa_pushButton_Write"));

        verticalLayout_25->addWidget(LoRa_pushButton_Write);


        horizontalLayout_21->addLayout(verticalLayout_25);


        verticalLayout_32->addLayout(horizontalLayout_21);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setSpacing(6);
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));
        LoRa_label_HOP_List = new QLabel(groupBox_LoRa);
        LoRa_label_HOP_List->setObjectName(QString::fromUtf8("LoRa_label_HOP_List"));
        QSizePolicy sizePolicy7(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(LoRa_label_HOP_List->sizePolicy().hasHeightForWidth());
        LoRa_label_HOP_List->setSizePolicy(sizePolicy7);

        horizontalLayout_29->addWidget(LoRa_label_HOP_List);

        LoRa_lineEdit_HOP_List = new QLineEdit(groupBox_LoRa);
        LoRa_lineEdit_HOP_List->setObjectName(QString::fromUtf8("LoRa_lineEdit_HOP_List"));
        sizePolicy2.setHeightForWidth(LoRa_lineEdit_HOP_List->sizePolicy().hasHeightForWidth());
        LoRa_lineEdit_HOP_List->setSizePolicy(sizePolicy2);
        LoRa_lineEdit_HOP_List->setMinimumSize(QSize(0, 0));

        horizontalLayout_29->addWidget(LoRa_lineEdit_HOP_List);


        verticalLayout_32->addLayout(horizontalLayout_29);


        horizontalLayout_32->addLayout(verticalLayout_32);


        horizontalLayout_34->addWidget(groupBox_LoRa);

        stackedWidget->addWidget(page_2);
        page_4G = new QWidget();
        page_4G->setObjectName(QString::fromUtf8("page_4G"));
        horizontalLayout_23 = new QHBoxLayout(page_4G);
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        groupBox_LTE = new QGroupBox(page_4G);
        groupBox_LTE->setObjectName(QString::fromUtf8("groupBox_LTE"));
        sizePolicy6.setHeightForWidth(groupBox_LTE->sizePolicy().hasHeightForWidth());
        groupBox_LTE->setSizePolicy(sizePolicy6);
        horizontalLayout_24 = new QHBoxLayout(groupBox_LTE);
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_14 = new QLabel(groupBox_LTE);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        verticalLayout_3->addWidget(label_14);

        label_2 = new QLabel(groupBox_LTE);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        sizePolicy4.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy4);

        verticalLayout_3->addWidget(label_2);


        horizontalLayout_16->addLayout(verticalLayout_3);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        G_lineEdit_Add = new QLineEdit(groupBox_LTE);
        G_lineEdit_Add->setObjectName(QString::fromUtf8("G_lineEdit_Add"));
        sizePolicy2.setHeightForWidth(G_lineEdit_Add->sizePolicy().hasHeightForWidth());
        G_lineEdit_Add->setSizePolicy(sizePolicy2);
        G_lineEdit_Add->setMinimumSize(QSize(0, 0));
        G_lineEdit_Add->setReadOnly(true);

        verticalLayout_13->addWidget(G_lineEdit_Add);

        G_lineEdit_ID = new QLineEdit(groupBox_LTE);
        G_lineEdit_ID->setObjectName(QString::fromUtf8("G_lineEdit_ID"));
        sizePolicy2.setHeightForWidth(G_lineEdit_ID->sizePolicy().hasHeightForWidth());
        G_lineEdit_ID->setSizePolicy(sizePolicy2);
        G_lineEdit_ID->setMinimumSize(QSize(0, 0));

        verticalLayout_13->addWidget(G_lineEdit_ID);


        horizontalLayout_16->addLayout(verticalLayout_13);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        label_13 = new QLabel(groupBox_LTE);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        sizePolicy4.setHeightForWidth(label_13->sizePolicy().hasHeightForWidth());
        label_13->setSizePolicy(sizePolicy4);

        verticalLayout_12->addWidget(label_13);

        label_3 = new QLabel(groupBox_LTE);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_12->addWidget(label_3);


        horizontalLayout_16->addLayout(verticalLayout_12);

        verticalLayout_26 = new QVBoxLayout();
        verticalLayout_26->setSpacing(6);
        verticalLayout_26->setObjectName(QString::fromUtf8("verticalLayout_26"));
        G_lineEdit_Sever = new QLineEdit(groupBox_LTE);
        G_lineEdit_Sever->setObjectName(QString::fromUtf8("G_lineEdit_Sever"));
        sizePolicy2.setHeightForWidth(G_lineEdit_Sever->sizePolicy().hasHeightForWidth());
        G_lineEdit_Sever->setSizePolicy(sizePolicy2);
        G_lineEdit_Sever->setMinimumSize(QSize(0, 0));

        verticalLayout_26->addWidget(G_lineEdit_Sever);

        G_lineEdit_Key = new QLineEdit(groupBox_LTE);
        G_lineEdit_Key->setObjectName(QString::fromUtf8("G_lineEdit_Key"));
        sizePolicy2.setHeightForWidth(G_lineEdit_Key->sizePolicy().hasHeightForWidth());
        G_lineEdit_Key->setSizePolicy(sizePolicy2);
        G_lineEdit_Key->setMinimumSize(QSize(0, 0));

        verticalLayout_26->addWidget(G_lineEdit_Key);


        horizontalLayout_16->addLayout(verticalLayout_26);

        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        G_pushButton_Read = new QPushButton(groupBox_LTE);
        G_pushButton_Read->setObjectName(QString::fromUtf8("G_pushButton_Read"));

        verticalLayout_14->addWidget(G_pushButton_Read);

        G_pushButton_Write = new QPushButton(groupBox_LTE);
        G_pushButton_Write->setObjectName(QString::fromUtf8("G_pushButton_Write"));

        verticalLayout_14->addWidget(G_pushButton_Write);


        horizontalLayout_16->addLayout(verticalLayout_14);

        G_pushButton_Shore = new QPushButton(groupBox_LTE);
        G_pushButton_Shore->setObjectName(QString::fromUtf8("G_pushButton_Shore"));
        sizePolicy7.setHeightForWidth(G_pushButton_Shore->sizePolicy().hasHeightForWidth());
        G_pushButton_Shore->setSizePolicy(sizePolicy7);
        G_pushButton_Shore->setMinimumSize(QSize(0, 0));

        horizontalLayout_16->addWidget(G_pushButton_Shore);


        horizontalLayout_24->addLayout(horizontalLayout_16);


        horizontalLayout_23->addWidget(groupBox_LTE);

        stackedWidget->addWidget(page_4G);
        page_NB = new QWidget();
        page_NB->setObjectName(QString::fromUtf8("page_NB"));
        horizontalLayout_31 = new QHBoxLayout(page_NB);
        horizontalLayout_31->setSpacing(6);
        horizontalLayout_31->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_31->setObjectName(QString::fromUtf8("horizontalLayout_31"));
        groupBox_NB = new QGroupBox(page_NB);
        groupBox_NB->setObjectName(QString::fromUtf8("groupBox_NB"));
        sizePolicy6.setHeightForWidth(groupBox_NB->sizePolicy().hasHeightForWidth());
        groupBox_NB->setSizePolicy(sizePolicy6);
        horizontalLayout_27 = new QHBoxLayout(groupBox_NB);
        horizontalLayout_27->setSpacing(6);
        horizontalLayout_27->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setSpacing(6);
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        label_16 = new QLabel(groupBox_NB);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        verticalLayout_15->addWidget(label_16);

        label_4 = new QLabel(groupBox_NB);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_15->addWidget(label_4);


        horizontalLayout_26->addLayout(verticalLayout_15);

        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        NB_lineEdit_Add = new QLineEdit(groupBox_NB);
        NB_lineEdit_Add->setObjectName(QString::fromUtf8("NB_lineEdit_Add"));
        sizePolicy2.setHeightForWidth(NB_lineEdit_Add->sizePolicy().hasHeightForWidth());
        NB_lineEdit_Add->setSizePolicy(sizePolicy2);
        NB_lineEdit_Add->setMinimumSize(QSize(0, 0));
        NB_lineEdit_Add->setReadOnly(true);

        verticalLayout_16->addWidget(NB_lineEdit_Add);

        NB_lineEdit_ID = new QLineEdit(groupBox_NB);
        NB_lineEdit_ID->setObjectName(QString::fromUtf8("NB_lineEdit_ID"));
        sizePolicy2.setHeightForWidth(NB_lineEdit_ID->sizePolicy().hasHeightForWidth());
        NB_lineEdit_ID->setSizePolicy(sizePolicy2);
        NB_lineEdit_ID->setMinimumSize(QSize(0, 0));

        verticalLayout_16->addWidget(NB_lineEdit_ID);


        horizontalLayout_26->addLayout(verticalLayout_16);

        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setSpacing(6);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        label_15 = new QLabel(groupBox_NB);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        verticalLayout_17->addWidget(label_15);

        label_5 = new QLabel(groupBox_NB);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_17->addWidget(label_5);


        horizontalLayout_26->addLayout(verticalLayout_17);

        verticalLayout_27 = new QVBoxLayout();
        verticalLayout_27->setSpacing(6);
        verticalLayout_27->setObjectName(QString::fromUtf8("verticalLayout_27"));
        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        NB_lineEdit_Sever = new QLineEdit(groupBox_NB);
        NB_lineEdit_Sever->setObjectName(QString::fromUtf8("NB_lineEdit_Sever"));
        sizePolicy2.setHeightForWidth(NB_lineEdit_Sever->sizePolicy().hasHeightForWidth());
        NB_lineEdit_Sever->setSizePolicy(sizePolicy2);
        NB_lineEdit_Sever->setMinimumSize(QSize(0, 0));

        horizontalLayout_25->addWidget(NB_lineEdit_Sever);

        label_26 = new QLabel(groupBox_NB);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        sizePolicy7.setHeightForWidth(label_26->sizePolicy().hasHeightForWidth());
        label_26->setSizePolicy(sizePolicy7);

        horizontalLayout_25->addWidget(label_26);

        NB_cbx_mode = new QComboBox(groupBox_NB);
        NB_cbx_mode->addItem(QString());
        NB_cbx_mode->addItem(QString());
        NB_cbx_mode->setObjectName(QString::fromUtf8("NB_cbx_mode"));
        QSizePolicy sizePolicy8(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy8.setHorizontalStretch(0);
        sizePolicy8.setVerticalStretch(0);
        sizePolicy8.setHeightForWidth(NB_cbx_mode->sizePolicy().hasHeightForWidth());
        NB_cbx_mode->setSizePolicy(sizePolicy8);
        NB_cbx_mode->setMinimumSize(QSize(60, 0));
        NB_cbx_mode->setMaximumSize(QSize(60, 16777215));

        horizontalLayout_25->addWidget(NB_cbx_mode);


        verticalLayout_27->addLayout(horizontalLayout_25);

        NB_lineEdit_Key = new QLineEdit(groupBox_NB);
        NB_lineEdit_Key->setObjectName(QString::fromUtf8("NB_lineEdit_Key"));
        sizePolicy2.setHeightForWidth(NB_lineEdit_Key->sizePolicy().hasHeightForWidth());
        NB_lineEdit_Key->setSizePolicy(sizePolicy2);
        NB_lineEdit_Key->setMinimumSize(QSize(0, 0));

        verticalLayout_27->addWidget(NB_lineEdit_Key);


        horizontalLayout_26->addLayout(verticalLayout_27);

        verticalLayout_28 = new QVBoxLayout();
        verticalLayout_28->setSpacing(6);
        verticalLayout_28->setObjectName(QString::fromUtf8("verticalLayout_28"));
        NB_pushButton_Read = new QPushButton(groupBox_NB);
        NB_pushButton_Read->setObjectName(QString::fromUtf8("NB_pushButton_Read"));

        verticalLayout_28->addWidget(NB_pushButton_Read);

        NB_pushButton_Write = new QPushButton(groupBox_NB);
        NB_pushButton_Write->setObjectName(QString::fromUtf8("NB_pushButton_Write"));

        verticalLayout_28->addWidget(NB_pushButton_Write);


        horizontalLayout_26->addLayout(verticalLayout_28);

        NB_pushButton_Share = new QPushButton(groupBox_NB);
        NB_pushButton_Share->setObjectName(QString::fromUtf8("NB_pushButton_Share"));
        sizePolicy7.setHeightForWidth(NB_pushButton_Share->sizePolicy().hasHeightForWidth());
        NB_pushButton_Share->setSizePolicy(sizePolicy7);

        horizontalLayout_26->addWidget(NB_pushButton_Share);


        horizontalLayout_27->addLayout(horizontalLayout_26);


        horizontalLayout_31->addWidget(groupBox_NB);

        stackedWidget->addWidget(page_NB);
        page_3 = new QWidget();
        page_3->setObjectName(QString::fromUtf8("page_3"));
        horizontalLayout_30 = new QHBoxLayout(page_3);
        horizontalLayout_30->setSpacing(6);
        horizontalLayout_30->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        groupBox_WiFi = new QGroupBox(page_3);
        groupBox_WiFi->setObjectName(QString::fromUtf8("groupBox_WiFi"));
        sizePolicy6.setHeightForWidth(groupBox_WiFi->sizePolicy().hasHeightForWidth());
        groupBox_WiFi->setSizePolicy(sizePolicy6);
        horizontalLayout_28 = new QHBoxLayout(groupBox_WiFi);
        horizontalLayout_28->setSpacing(6);
        horizontalLayout_28->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        verticalLayout_29 = new QVBoxLayout();
        verticalLayout_29->setSpacing(6);
        verticalLayout_29->setObjectName(QString::fromUtf8("verticalLayout_29"));
        label_25 = new QLabel(groupBox_WiFi);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        verticalLayout_29->addWidget(label_25);

        label_19 = new QLabel(groupBox_WiFi);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        verticalLayout_29->addWidget(label_19);


        horizontalLayout_22->addLayout(verticalLayout_29);

        verticalLayout_34 = new QVBoxLayout();
        verticalLayout_34->setSpacing(6);
        verticalLayout_34->setObjectName(QString::fromUtf8("verticalLayout_34"));
        WiFi_lineEdit_Add = new QLineEdit(groupBox_WiFi);
        WiFi_lineEdit_Add->setObjectName(QString::fromUtf8("WiFi_lineEdit_Add"));
        WiFi_lineEdit_Add->setReadOnly(true);

        verticalLayout_34->addWidget(WiFi_lineEdit_Add);

        WiFi_lineEdit_SSID = new QLineEdit(groupBox_WiFi);
        WiFi_lineEdit_SSID->setObjectName(QString::fromUtf8("WiFi_lineEdit_SSID"));

        verticalLayout_34->addWidget(WiFi_lineEdit_SSID);


        horizontalLayout_22->addLayout(verticalLayout_34);

        verticalLayout_35 = new QVBoxLayout();
        verticalLayout_35->setSpacing(6);
        verticalLayout_35->setObjectName(QString::fromUtf8("verticalLayout_35"));
        label_22 = new QLabel(groupBox_WiFi);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        verticalLayout_35->addWidget(label_22);

        WiFi_label_Pass = new QLabel(groupBox_WiFi);
        WiFi_label_Pass->setObjectName(QString::fromUtf8("WiFi_label_Pass"));

        verticalLayout_35->addWidget(WiFi_label_Pass);


        horizontalLayout_22->addLayout(verticalLayout_35);

        verticalLayout_36 = new QVBoxLayout();
        verticalLayout_36->setSpacing(6);
        verticalLayout_36->setObjectName(QString::fromUtf8("verticalLayout_36"));
        WiFi_lineEdit_IPAdd = new QLineEdit(groupBox_WiFi);
        WiFi_lineEdit_IPAdd->setObjectName(QString::fromUtf8("WiFi_lineEdit_IPAdd"));

        verticalLayout_36->addWidget(WiFi_lineEdit_IPAdd);

        WiFi_lineEdit_PSKPpass = new QLineEdit(groupBox_WiFi);
        WiFi_lineEdit_PSKPpass->setObjectName(QString::fromUtf8("WiFi_lineEdit_PSKPpass"));

        verticalLayout_36->addWidget(WiFi_lineEdit_PSKPpass);


        horizontalLayout_22->addLayout(verticalLayout_36);

        verticalLayout_42 = new QVBoxLayout();
        verticalLayout_42->setSpacing(6);
        verticalLayout_42->setObjectName(QString::fromUtf8("verticalLayout_42"));
        label_21 = new QLabel(groupBox_WiFi);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        verticalLayout_42->addWidget(label_21);

        label_20 = new QLabel(groupBox_WiFi);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        verticalLayout_42->addWidget(label_20);


        horizontalLayout_22->addLayout(verticalLayout_42);

        verticalLayout_43 = new QVBoxLayout();
        verticalLayout_43->setSpacing(6);
        verticalLayout_43->setObjectName(QString::fromUtf8("verticalLayout_43"));
        WiFi_lineEdit_OwnIp = new QLineEdit(groupBox_WiFi);
        WiFi_lineEdit_OwnIp->setObjectName(QString::fromUtf8("WiFi_lineEdit_OwnIp"));
        WiFi_lineEdit_OwnIp->setReadOnly(true);

        verticalLayout_43->addWidget(WiFi_lineEdit_OwnIp);

        WiFi_comboBox_PassType = new QComboBox(groupBox_WiFi);
        WiFi_comboBox_PassType->addItem(QString());
        WiFi_comboBox_PassType->addItem(QString());
        WiFi_comboBox_PassType->addItem(QString());
        WiFi_comboBox_PassType->setObjectName(QString::fromUtf8("WiFi_comboBox_PassType"));
        sizePolicy2.setHeightForWidth(WiFi_comboBox_PassType->sizePolicy().hasHeightForWidth());
        WiFi_comboBox_PassType->setSizePolicy(sizePolicy2);

        verticalLayout_43->addWidget(WiFi_comboBox_PassType);


        horizontalLayout_22->addLayout(verticalLayout_43);

        verticalLayout_38 = new QVBoxLayout();
        verticalLayout_38->setSpacing(6);
        verticalLayout_38->setObjectName(QString::fromUtf8("verticalLayout_38"));
        WiFi_pushButton_Read = new QPushButton(groupBox_WiFi);
        WiFi_pushButton_Read->setObjectName(QString::fromUtf8("WiFi_pushButton_Read"));

        verticalLayout_38->addWidget(WiFi_pushButton_Read);

        WiFi_pushButton_Write = new QPushButton(groupBox_WiFi);
        WiFi_pushButton_Write->setObjectName(QString::fromUtf8("WiFi_pushButton_Write"));

        verticalLayout_38->addWidget(WiFi_pushButton_Write);


        horizontalLayout_22->addLayout(verticalLayout_38);


        horizontalLayout_28->addLayout(horizontalLayout_22);


        horizontalLayout_30->addWidget(groupBox_WiFi);

        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QString::fromUtf8("page_4"));
        horizontalLayout_18 = new QHBoxLayout(page_4);
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        groupBox_BLE = new QGroupBox(page_4);
        groupBox_BLE->setObjectName(QString::fromUtf8("groupBox_BLE"));
        sizePolicy6.setHeightForWidth(groupBox_BLE->sizePolicy().hasHeightForWidth());
        groupBox_BLE->setSizePolicy(sizePolicy6);
        horizontalLayout_35 = new QHBoxLayout(groupBox_BLE);
        horizontalLayout_35->setSpacing(6);
        horizontalLayout_35->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_35->setObjectName(QString::fromUtf8("horizontalLayout_35"));
        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));
        verticalLayout_39 = new QVBoxLayout();
        verticalLayout_39->setSpacing(6);
        verticalLayout_39->setObjectName(QString::fromUtf8("verticalLayout_39"));
        label_23 = new QLabel(groupBox_BLE);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        verticalLayout_39->addWidget(label_23);

        label_24 = new QLabel(groupBox_BLE);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        verticalLayout_39->addWidget(label_24);


        horizontalLayout_20->addLayout(verticalLayout_39);

        verticalLayout_40 = new QVBoxLayout();
        verticalLayout_40->setSpacing(6);
        verticalLayout_40->setObjectName(QString::fromUtf8("verticalLayout_40"));
        BLE_lineEdit_Mac = new QLineEdit(groupBox_BLE);
        BLE_lineEdit_Mac->setObjectName(QString::fromUtf8("BLE_lineEdit_Mac"));
        BLE_lineEdit_Mac->setReadOnly(true);

        verticalLayout_40->addWidget(BLE_lineEdit_Mac);

        BLE_lineEdit_Link = new QLineEdit(groupBox_BLE);
        BLE_lineEdit_Link->setObjectName(QString::fromUtf8("BLE_lineEdit_Link"));
        BLE_lineEdit_Link->setReadOnly(true);

        verticalLayout_40->addWidget(BLE_lineEdit_Link);


        horizontalLayout_20->addLayout(verticalLayout_40);

        verticalLayout_41 = new QVBoxLayout();
        verticalLayout_41->setSpacing(6);
        verticalLayout_41->setObjectName(QString::fromUtf8("verticalLayout_41"));
        BLE_pushButton_ReadMac = new QPushButton(groupBox_BLE);
        BLE_pushButton_ReadMac->setObjectName(QString::fromUtf8("BLE_pushButton_ReadMac"));

        verticalLayout_41->addWidget(BLE_pushButton_ReadMac);

        BLE_pushButton_TextLink = new QPushButton(groupBox_BLE);
        BLE_pushButton_TextLink->setObjectName(QString::fromUtf8("BLE_pushButton_TextLink"));

        verticalLayout_41->addWidget(BLE_pushButton_TextLink);


        horizontalLayout_20->addLayout(verticalLayout_41);


        horizontalLayout_35->addLayout(horizontalLayout_20);


        horizontalLayout_18->addWidget(groupBox_BLE);

        stackedWidget->addWidget(page_4);
        page_5 = new QWidget();
        page_5->setObjectName(QString::fromUtf8("page_5"));
        horizontalLayout_38 = new QHBoxLayout(page_5);
        horizontalLayout_38->setSpacing(6);
        horizontalLayout_38->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_38->setObjectName(QString::fromUtf8("horizontalLayout_38"));
        groupBox_2 = new QGroupBox(page_5);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setMinimumSize(QSize(0, 88));
        groupBox_2->setMaximumSize(QSize(16777215, 88));
        horizontalLayout_40 = new QHBoxLayout(groupBox_2);
        horizontalLayout_40->setSpacing(6);
        horizontalLayout_40->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_40->setObjectName(QString::fromUtf8("horizontalLayout_40"));
        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setSpacing(6);
        horizontalLayout_39->setObjectName(QString::fromUtf8("horizontalLayout_39"));
        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(6);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_27 = new QLabel(groupBox_2);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setLayoutDirection(Qt::LeftToRight);
        label_27->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_27, 0, 0, 1, 1);

        LoRaWAN_le_deveui = new QLineEdit(groupBox_2);
        LoRaWAN_le_deveui->setObjectName(QString::fromUtf8("LoRaWAN_le_deveui"));
        LoRaWAN_le_deveui->setMaximumSize(QSize(16777215, 16777215));
        LoRaWAN_le_deveui->setReadOnly(true);

        gridLayout_3->addWidget(LoRaWAN_le_deveui, 0, 1, 1, 1);

        label_30 = new QLabel(groupBox_2);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_30, 0, 2, 1, 1);

        LoRaWAN_le_key = new QLineEdit(groupBox_2);
        LoRaWAN_le_key->setObjectName(QString::fromUtf8("LoRaWAN_le_key"));
        LoRaWAN_le_key->setMaximumSize(QSize(16777215, 16777215));

        gridLayout_3->addWidget(LoRaWAN_le_key, 0, 3, 1, 1);

        label_29 = new QLabel(groupBox_2);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_29, 0, 4, 1, 1);

        LoRaWAN_cmb_zkey = new QComboBox(groupBox_2);
        LoRaWAN_cmb_zkey->addItem(QString());
        LoRaWAN_cmb_zkey->addItem(QString());
        LoRaWAN_cmb_zkey->setObjectName(QString::fromUtf8("LoRaWAN_cmb_zkey"));
        sizePolicy8.setHeightForWidth(LoRaWAN_cmb_zkey->sizePolicy().hasHeightForWidth());
        LoRaWAN_cmb_zkey->setSizePolicy(sizePolicy8);
        LoRaWAN_cmb_zkey->setMinimumSize(QSize(50, 0));
        LoRaWAN_cmb_zkey->setMaximumSize(QSize(50, 16777215));

        gridLayout_3->addWidget(LoRaWAN_cmb_zkey, 0, 5, 1, 1);

        label_33 = new QLabel(groupBox_2);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_33, 0, 6, 1, 1);

        LoRaWAN_cmb_ddr = new QComboBox(groupBox_2);
        LoRaWAN_cmb_ddr->addItem(QString());
        LoRaWAN_cmb_ddr->addItem(QString());
        LoRaWAN_cmb_ddr->addItem(QString());
        LoRaWAN_cmb_ddr->addItem(QString());
        LoRaWAN_cmb_ddr->addItem(QString());
        LoRaWAN_cmb_ddr->addItem(QString());
        LoRaWAN_cmb_ddr->setObjectName(QString::fromUtf8("LoRaWAN_cmb_ddr"));
        sizePolicy8.setHeightForWidth(LoRaWAN_cmb_ddr->sizePolicy().hasHeightForWidth());
        LoRaWAN_cmb_ddr->setSizePolicy(sizePolicy8);
        LoRaWAN_cmb_ddr->setMinimumSize(QSize(50, 0));
        LoRaWAN_cmb_ddr->setMaximumSize(QSize(50, 16777215));

        gridLayout_3->addWidget(LoRaWAN_cmb_ddr, 0, 7, 1, 1);

        label_28 = new QLabel(groupBox_2);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_28, 1, 0, 1, 1);

        LoRaWAN_le_joineui = new QLineEdit(groupBox_2);
        LoRaWAN_le_joineui->setObjectName(QString::fromUtf8("LoRaWAN_le_joineui"));
        LoRaWAN_le_joineui->setMaximumSize(QSize(16777215, 16777215));

        gridLayout_3->addWidget(LoRaWAN_le_joineui, 1, 1, 1, 1);

        label_32 = new QLabel(groupBox_2);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_32, 1, 2, 1, 1);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setSpacing(0);
        horizontalLayout_37->setObjectName(QString::fromUtf8("horizontalLayout_37"));
        LoRaWAN_le_chm = new QLineEdit(groupBox_2);
        LoRaWAN_le_chm->setObjectName(QString::fromUtf8("LoRaWAN_le_chm"));
        LoRaWAN_le_chm->setMaximumSize(QSize(16777215, 16777215));
        LoRaWAN_le_chm->setReadOnly(true);

        horizontalLayout_37->addWidget(LoRaWAN_le_chm);

        LoRaWAN_btn_setChm = new QPushButton(groupBox_2);
        LoRaWAN_btn_setChm->setObjectName(QString::fromUtf8("LoRaWAN_btn_setChm"));
        sizePolicy4.setHeightForWidth(LoRaWAN_btn_setChm->sizePolicy().hasHeightForWidth());
        LoRaWAN_btn_setChm->setSizePolicy(sizePolicy4);
        LoRaWAN_btn_setChm->setMaximumSize(QSize(35, 16777215));

        horizontalLayout_37->addWidget(LoRaWAN_btn_setChm);


        gridLayout_3->addLayout(horizontalLayout_37, 1, 3, 1, 1);

        label_31 = new QLabel(groupBox_2);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_31, 1, 4, 1, 1);

        LoRaWAN_cmb_class = new QComboBox(groupBox_2);
        LoRaWAN_cmb_class->addItem(QString());
        LoRaWAN_cmb_class->addItem(QString());
        LoRaWAN_cmb_class->setObjectName(QString::fromUtf8("LoRaWAN_cmb_class"));
        sizePolicy8.setHeightForWidth(LoRaWAN_cmb_class->sizePolicy().hasHeightForWidth());
        LoRaWAN_cmb_class->setSizePolicy(sizePolicy8);
        LoRaWAN_cmb_class->setMinimumSize(QSize(50, 0));
        LoRaWAN_cmb_class->setMaximumSize(QSize(50, 16777215));

        gridLayout_3->addWidget(LoRaWAN_cmb_class, 1, 5, 1, 1);

        label_34 = new QLabel(groupBox_2);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label_34, 1, 6, 1, 1);

        LoRaWAN_cmb_adr = new QComboBox(groupBox_2);
        LoRaWAN_cmb_adr->addItem(QString());
        LoRaWAN_cmb_adr->addItem(QString());
        LoRaWAN_cmb_adr->setObjectName(QString::fromUtf8("LoRaWAN_cmb_adr"));
        sizePolicy8.setHeightForWidth(LoRaWAN_cmb_adr->sizePolicy().hasHeightForWidth());
        LoRaWAN_cmb_adr->setSizePolicy(sizePolicy8);
        LoRaWAN_cmb_adr->setMinimumSize(QSize(50, 0));
        LoRaWAN_cmb_adr->setMaximumSize(QSize(50, 16777215));

        gridLayout_3->addWidget(LoRaWAN_cmb_adr, 1, 7, 1, 1);


        horizontalLayout_39->addLayout(gridLayout_3);

        verticalLayout_44 = new QVBoxLayout();
        verticalLayout_44->setSpacing(6);
        verticalLayout_44->setObjectName(QString::fromUtf8("verticalLayout_44"));
        LoRaWAN_btn_Read = new QPushButton(groupBox_2);
        LoRaWAN_btn_Read->setObjectName(QString::fromUtf8("LoRaWAN_btn_Read"));

        verticalLayout_44->addWidget(LoRaWAN_btn_Read);

        LoRaWAN_btn_Write = new QPushButton(groupBox_2);
        LoRaWAN_btn_Write->setObjectName(QString::fromUtf8("LoRaWAN_btn_Write"));

        verticalLayout_44->addWidget(LoRaWAN_btn_Write);


        horizontalLayout_39->addLayout(verticalLayout_44);


        horizontalLayout_40->addLayout(horizontalLayout_39);


        horizontalLayout_38->addWidget(groupBox_2);

        stackedWidget->addWidget(page_5);
        page_CAT1 = new QWidget();
        page_CAT1->setObjectName(QString::fromUtf8("page_CAT1"));
        horizontalLayout_44 = new QHBoxLayout(page_CAT1);
        horizontalLayout_44->setSpacing(6);
        horizontalLayout_44->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_44->setObjectName(QString::fromUtf8("horizontalLayout_44"));
        groupBox_CAT1 = new QGroupBox(page_CAT1);
        groupBox_CAT1->setObjectName(QString::fromUtf8("groupBox_CAT1"));
        sizePolicy6.setHeightForWidth(groupBox_CAT1->sizePolicy().hasHeightForWidth());
        groupBox_CAT1->setSizePolicy(sizePolicy6);
        horizontalLayout_41 = new QHBoxLayout(groupBox_CAT1);
        horizontalLayout_41->setSpacing(6);
        horizontalLayout_41->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_41->setObjectName(QString::fromUtf8("horizontalLayout_41"));
        horizontalLayout_42 = new QHBoxLayout();
        horizontalLayout_42->setSpacing(6);
        horizontalLayout_42->setObjectName(QString::fromUtf8("horizontalLayout_42"));
        verticalLayout_45 = new QVBoxLayout();
        verticalLayout_45->setSpacing(6);
        verticalLayout_45->setObjectName(QString::fromUtf8("verticalLayout_45"));
        label_35 = new QLabel(groupBox_CAT1);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        verticalLayout_45->addWidget(label_35);

        label_36 = new QLabel(groupBox_CAT1);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        verticalLayout_45->addWidget(label_36);


        horizontalLayout_42->addLayout(verticalLayout_45);

        verticalLayout_46 = new QVBoxLayout();
        verticalLayout_46->setSpacing(6);
        verticalLayout_46->setObjectName(QString::fromUtf8("verticalLayout_46"));
        CAT1_lineEdit_Add = new QLineEdit(groupBox_CAT1);
        CAT1_lineEdit_Add->setObjectName(QString::fromUtf8("CAT1_lineEdit_Add"));
        sizePolicy2.setHeightForWidth(CAT1_lineEdit_Add->sizePolicy().hasHeightForWidth());
        CAT1_lineEdit_Add->setSizePolicy(sizePolicy2);
        CAT1_lineEdit_Add->setMinimumSize(QSize(0, 0));
        CAT1_lineEdit_Add->setReadOnly(true);

        verticalLayout_46->addWidget(CAT1_lineEdit_Add);

        CAT1_lineEdit_ID = new QLineEdit(groupBox_CAT1);
        CAT1_lineEdit_ID->setObjectName(QString::fromUtf8("CAT1_lineEdit_ID"));
        sizePolicy2.setHeightForWidth(CAT1_lineEdit_ID->sizePolicy().hasHeightForWidth());
        CAT1_lineEdit_ID->setSizePolicy(sizePolicy2);
        CAT1_lineEdit_ID->setMinimumSize(QSize(0, 0));

        verticalLayout_46->addWidget(CAT1_lineEdit_ID);


        horizontalLayout_42->addLayout(verticalLayout_46);

        verticalLayout_47 = new QVBoxLayout();
        verticalLayout_47->setSpacing(6);
        verticalLayout_47->setObjectName(QString::fromUtf8("verticalLayout_47"));
        label_37 = new QLabel(groupBox_CAT1);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        verticalLayout_47->addWidget(label_37);

        label_38 = new QLabel(groupBox_CAT1);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        verticalLayout_47->addWidget(label_38);


        horizontalLayout_42->addLayout(verticalLayout_47);

        verticalLayout_48 = new QVBoxLayout();
        verticalLayout_48->setSpacing(6);
        verticalLayout_48->setObjectName(QString::fromUtf8("verticalLayout_48"));
        horizontalLayout_43 = new QHBoxLayout();
        horizontalLayout_43->setSpacing(6);
        horizontalLayout_43->setObjectName(QString::fromUtf8("horizontalLayout_43"));
        CAT1_lineEdit_Sever = new QLineEdit(groupBox_CAT1);
        CAT1_lineEdit_Sever->setObjectName(QString::fromUtf8("CAT1_lineEdit_Sever"));
        sizePolicy2.setHeightForWidth(CAT1_lineEdit_Sever->sizePolicy().hasHeightForWidth());
        CAT1_lineEdit_Sever->setSizePolicy(sizePolicy2);
        CAT1_lineEdit_Sever->setMinimumSize(QSize(0, 0));

        horizontalLayout_43->addWidget(CAT1_lineEdit_Sever);


        verticalLayout_48->addLayout(horizontalLayout_43);

        CAT1_lineEdit_Key = new QLineEdit(groupBox_CAT1);
        CAT1_lineEdit_Key->setObjectName(QString::fromUtf8("CAT1_lineEdit_Key"));
        sizePolicy2.setHeightForWidth(CAT1_lineEdit_Key->sizePolicy().hasHeightForWidth());
        CAT1_lineEdit_Key->setSizePolicy(sizePolicy2);
        CAT1_lineEdit_Key->setMinimumSize(QSize(0, 0));

        verticalLayout_48->addWidget(CAT1_lineEdit_Key);


        horizontalLayout_42->addLayout(verticalLayout_48);

        verticalLayout_49 = new QVBoxLayout();
        verticalLayout_49->setSpacing(6);
        verticalLayout_49->setObjectName(QString::fromUtf8("verticalLayout_49"));
        CAT1_pushButton_Read = new QPushButton(groupBox_CAT1);
        CAT1_pushButton_Read->setObjectName(QString::fromUtf8("CAT1_pushButton_Read"));

        verticalLayout_49->addWidget(CAT1_pushButton_Read);

        CAT1_pushButton_Write = new QPushButton(groupBox_CAT1);
        CAT1_pushButton_Write->setObjectName(QString::fromUtf8("CAT1_pushButton_Write"));

        verticalLayout_49->addWidget(CAT1_pushButton_Write);


        horizontalLayout_42->addLayout(verticalLayout_49);

        CAT1_pushButton_Share = new QPushButton(groupBox_CAT1);
        CAT1_pushButton_Share->setObjectName(QString::fromUtf8("CAT1_pushButton_Share"));
        sizePolicy7.setHeightForWidth(CAT1_pushButton_Share->sizePolicy().hasHeightForWidth());
        CAT1_pushButton_Share->setSizePolicy(sizePolicy7);

        horizontalLayout_42->addWidget(CAT1_pushButton_Share);


        horizontalLayout_41->addLayout(horizontalLayout_42);


        horizontalLayout_44->addWidget(groupBox_CAT1);

        stackedWidget->addWidget(page_CAT1);
        page_esp = new QWidget();
        page_esp->setObjectName(QString::fromUtf8("page_esp"));
        horizontalLayout_302 = new QHBoxLayout(page_esp);
        horizontalLayout_302->setSpacing(6);
        horizontalLayout_302->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_302->setObjectName(QString::fromUtf8("horizontalLayout_302"));
        groupBox_WiFi2 = new QGroupBox(page_esp);
        groupBox_WiFi2->setObjectName(QString::fromUtf8("groupBox_WiFi2"));
        sizePolicy6.setHeightForWidth(groupBox_WiFi2->sizePolicy().hasHeightForWidth());
        groupBox_WiFi2->setSizePolicy(sizePolicy6);
        horizontalLayout_282 = new QHBoxLayout(groupBox_WiFi2);
        horizontalLayout_282->setSpacing(6);
        horizontalLayout_282->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_282->setObjectName(QString::fromUtf8("horizontalLayout_282"));
        horizontalLayout_222 = new QHBoxLayout();
        horizontalLayout_222->setSpacing(6);
        horizontalLayout_222->setObjectName(QString::fromUtf8("horizontalLayout_222"));
        verticalLayout_292 = new QVBoxLayout();
        verticalLayout_292->setSpacing(6);
        verticalLayout_292->setObjectName(QString::fromUtf8("verticalLayout_292"));
        label_252 = new QLabel(groupBox_WiFi2);
        label_252->setObjectName(QString::fromUtf8("label_252"));

        verticalLayout_292->addWidget(label_252);

        label_192 = new QLabel(groupBox_WiFi2);
        label_192->setObjectName(QString::fromUtf8("label_192"));

        verticalLayout_292->addWidget(label_192);


        horizontalLayout_222->addLayout(verticalLayout_292);

        verticalLayout_342 = new QVBoxLayout();
        verticalLayout_342->setSpacing(6);
        verticalLayout_342->setObjectName(QString::fromUtf8("verticalLayout_342"));
        ESP8266_lineEdit_Mac = new QLineEdit(groupBox_WiFi2);
        ESP8266_lineEdit_Mac->setObjectName(QString::fromUtf8("ESP8266_lineEdit_Mac"));
        ESP8266_lineEdit_Mac->setReadOnly(true);

        verticalLayout_342->addWidget(ESP8266_lineEdit_Mac);

        ESP8266_lineEdit_SIP = new QLineEdit(groupBox_WiFi2);
        ESP8266_lineEdit_SIP->setObjectName(QString::fromUtf8("ESP8266_lineEdit_SIP"));

        verticalLayout_342->addWidget(ESP8266_lineEdit_SIP);


        horizontalLayout_222->addLayout(verticalLayout_342);

        verticalLayout_352 = new QVBoxLayout();
        verticalLayout_352->setSpacing(6);
        verticalLayout_352->setObjectName(QString::fromUtf8("verticalLayout_352"));
        label_222 = new QLabel(groupBox_WiFi2);
        label_222->setObjectName(QString::fromUtf8("label_222"));

        verticalLayout_352->addWidget(label_222);

        ESP8266_label_Pass = new QLabel(groupBox_WiFi2);
        ESP8266_label_Pass->setObjectName(QString::fromUtf8("ESP8266_label_Pass"));

        verticalLayout_352->addWidget(ESP8266_label_Pass);


        horizontalLayout_222->addLayout(verticalLayout_352);

        verticalLayout_362 = new QVBoxLayout();
        verticalLayout_362->setSpacing(6);
        verticalLayout_362->setObjectName(QString::fromUtf8("verticalLayout_362"));
        ESP8266_lineEdit_SSID = new QLineEdit(groupBox_WiFi2);
        ESP8266_lineEdit_SSID->setObjectName(QString::fromUtf8("ESP8266_lineEdit_SSID"));

        verticalLayout_362->addWidget(ESP8266_lineEdit_SSID);

        ESP8266_lineEdit_AID = new QLineEdit(groupBox_WiFi2);
        ESP8266_lineEdit_AID->setObjectName(QString::fromUtf8("ESP8266_lineEdit_AID"));

        verticalLayout_362->addWidget(ESP8266_lineEdit_AID);


        horizontalLayout_222->addLayout(verticalLayout_362);

        verticalLayout_422 = new QVBoxLayout();
        verticalLayout_422->setSpacing(6);
        verticalLayout_422->setObjectName(QString::fromUtf8("verticalLayout_422"));
        label_212 = new QLabel(groupBox_WiFi2);
        label_212->setObjectName(QString::fromUtf8("label_212"));

        verticalLayout_422->addWidget(label_212);

        label_202 = new QLabel(groupBox_WiFi2);
        label_202->setObjectName(QString::fromUtf8("label_202"));

        verticalLayout_422->addWidget(label_202);


        horizontalLayout_222->addLayout(verticalLayout_422);

        verticalLayout_432 = new QVBoxLayout();
        verticalLayout_432->setSpacing(6);
        verticalLayout_432->setObjectName(QString::fromUtf8("verticalLayout_432"));
        ESP8266_lineEdit_Key = new QLineEdit(groupBox_WiFi2);
        ESP8266_lineEdit_Key->setObjectName(QString::fromUtf8("ESP8266_lineEdit_Key"));

        verticalLayout_432->addWidget(ESP8266_lineEdit_Key);

        ESP8266_lineEdit_AKey = new QLineEdit(groupBox_WiFi2);
        ESP8266_lineEdit_AKey->setObjectName(QString::fromUtf8("ESP8266_lineEdit_AKey"));

        verticalLayout_432->addWidget(ESP8266_lineEdit_AKey);


        horizontalLayout_222->addLayout(verticalLayout_432);

        verticalLayout_382 = new QVBoxLayout();
        verticalLayout_382->setSpacing(6);
        verticalLayout_382->setObjectName(QString::fromUtf8("verticalLayout_382"));
        ESP8266_pushButton_Read = new QPushButton(groupBox_WiFi2);
        ESP8266_pushButton_Read->setObjectName(QString::fromUtf8("ESP8266_pushButton_Read"));

        verticalLayout_382->addWidget(ESP8266_pushButton_Read);

        ESP8266_pushButton_Write = new QPushButton(groupBox_WiFi2);
        ESP8266_pushButton_Write->setObjectName(QString::fromUtf8("ESP8266_pushButton_Write"));

        verticalLayout_382->addWidget(ESP8266_pushButton_Write);


        horizontalLayout_222->addLayout(verticalLayout_382);

        verticalLayout_50 = new QVBoxLayout();
        verticalLayout_50->setSpacing(6);
        verticalLayout_50->setObjectName(QString::fromUtf8("verticalLayout_50"));
        ESP8266_comboBox_mode = new QComboBox(groupBox_WiFi2);
        ESP8266_comboBox_mode->addItem(QString());
        ESP8266_comboBox_mode->addItem(QString());
        ESP8266_comboBox_mode->addItem(QString());
        ESP8266_comboBox_mode->addItem(QString());
        ESP8266_comboBox_mode->addItem(QString());
        ESP8266_comboBox_mode->addItem(QString());
        ESP8266_comboBox_mode->addItem(QString());
        ESP8266_comboBox_mode->setObjectName(QString::fromUtf8("ESP8266_comboBox_mode"));

        verticalLayout_50->addWidget(ESP8266_comboBox_mode);

        ESP8266_btn_share = new QPushButton(groupBox_WiFi2);
        ESP8266_btn_share->setObjectName(QString::fromUtf8("ESP8266_btn_share"));
        sizePolicy6.setHeightForWidth(ESP8266_btn_share->sizePolicy().hasHeightForWidth());
        ESP8266_btn_share->setSizePolicy(sizePolicy6);

        verticalLayout_50->addWidget(ESP8266_btn_share);


        horizontalLayout_222->addLayout(verticalLayout_50);


        horizontalLayout_282->addLayout(horizontalLayout_222);


        horizontalLayout_302->addWidget(groupBox_WiFi2);

        stackedWidget->addWidget(page_esp);

        horizontalLayout_33->addWidget(stackedWidget);

        groupBox_8 = new QGroupBox(centralWidget);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        QSizePolicy sizePolicy9(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy9.setHorizontalStretch(0);
        sizePolicy9.setVerticalStretch(0);
        sizePolicy9.setHeightForWidth(groupBox_8->sizePolicy().hasHeightForWidth());
        groupBox_8->setSizePolicy(sizePolicy9);
        groupBox_8->setMinimumSize(QSize(0, 88));
        horizontalLayout_19 = new QHBoxLayout(groupBox_8);
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        label_Set_Rec = new QLabel(groupBox_8);
        label_Set_Rec->setObjectName(QString::fromUtf8("label_Set_Rec"));
        sizePolicy1.setHeightForWidth(label_Set_Rec->sizePolicy().hasHeightForWidth());
        label_Set_Rec->setSizePolicy(sizePolicy1);

        horizontalLayout_12->addWidget(label_Set_Rec);

        comboBox_Set_Rec = new QComboBox(groupBox_8);
        comboBox_Set_Rec->addItem(QString());
        comboBox_Set_Rec->addItem(QString());
        comboBox_Set_Rec->setObjectName(QString::fromUtf8("comboBox_Set_Rec"));
        sizePolicy6.setHeightForWidth(comboBox_Set_Rec->sizePolicy().hasHeightForWidth());
        comboBox_Set_Rec->setSizePolicy(sizePolicy6);

        horizontalLayout_12->addWidget(comboBox_Set_Rec);


        verticalLayout_4->addLayout(horizontalLayout_12);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        label_Set_Send = new QLabel(groupBox_8);
        label_Set_Send->setObjectName(QString::fromUtf8("label_Set_Send"));
        sizePolicy1.setHeightForWidth(label_Set_Send->sizePolicy().hasHeightForWidth());
        label_Set_Send->setSizePolicy(sizePolicy1);

        horizontalLayout_11->addWidget(label_Set_Send);

        comboBox_Set_Send = new QComboBox(groupBox_8);
        comboBox_Set_Send->addItem(QString());
        comboBox_Set_Send->addItem(QString());
        comboBox_Set_Send->setObjectName(QString::fromUtf8("comboBox_Set_Send"));
        sizePolicy6.setHeightForWidth(comboBox_Set_Send->sizePolicy().hasHeightForWidth());
        comboBox_Set_Send->setSizePolicy(sizePolicy6);

        horizontalLayout_11->addWidget(comboBox_Set_Send);


        verticalLayout_4->addLayout(horizontalLayout_11);


        horizontalLayout_19->addLayout(verticalLayout_4);


        horizontalLayout_33->addWidget(groupBox_8);

        groupBox_7 = new QGroupBox(centralWidget);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        sizePolicy8.setHeightForWidth(groupBox_7->sizePolicy().hasHeightForWidth());
        groupBox_7->setSizePolicy(sizePolicy8);
        groupBox_7->setMinimumSize(QSize(0, 88));
        horizontalLayout_10 = new QHBoxLayout(groupBox_7);
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setSpacing(6);
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        pushButton_DelRec = new QPushButton(groupBox_7);
        pushButton_DelRec->setObjectName(QString::fromUtf8("pushButton_DelRec"));
        sizePolicy8.setHeightForWidth(pushButton_DelRec->sizePolicy().hasHeightForWidth());
        pushButton_DelRec->setSizePolicy(sizePolicy8);

        verticalLayout_18->addWidget(pushButton_DelRec);

        pushButton_DelSend = new QPushButton(groupBox_7);
        pushButton_DelSend->setObjectName(QString::fromUtf8("pushButton_DelSend"));
        sizePolicy8.setHeightForWidth(pushButton_DelSend->sizePolicy().hasHeightForWidth());
        pushButton_DelSend->setSizePolicy(sizePolicy8);

        verticalLayout_18->addWidget(pushButton_DelSend);


        horizontalLayout_10->addLayout(verticalLayout_18);


        horizontalLayout_33->addWidget(groupBox_7);


        verticalLayout_37->addLayout(horizontalLayout_33);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        sizePolicy.setHeightForWidth(groupBox_3->sizePolicy().hasHeightForWidth());
        groupBox_3->setSizePolicy(sizePolicy);
        horizontalLayout_4 = new QHBoxLayout(groupBox_3);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        listWidget_Rec = new QListWidget(groupBox_3);
        listWidget_Rec->setObjectName(QString::fromUtf8("listWidget_Rec"));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setPointSize(9);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        listWidget_Rec->setFont(font);
        listWidget_Rec->setFocusPolicy(Qt::WheelFocus);
        listWidget_Rec->setAcceptDrops(false);
        listWidget_Rec->setStyleSheet(QString::fromUtf8("font: 9pt \"\351\273\221\344\275\223\";"));

        horizontalLayout_4->addWidget(listWidget_Rec);


        horizontalLayout_8->addWidget(groupBox_3);

        verticalLayout_33 = new QVBoxLayout();
        verticalLayout_33->setSpacing(6);
        verticalLayout_33->setObjectName(QString::fromUtf8("verticalLayout_33"));
        groupBox_4 = new QGroupBox(centralWidget);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        sizePolicy.setHeightForWidth(groupBox_4->sizePolicy().hasHeightForWidth());
        groupBox_4->setSizePolicy(sizePolicy);
        horizontalLayout_7 = new QHBoxLayout(groupBox_4);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_RecSop = new QLabel(groupBox_4);
        label_RecSop->setObjectName(QString::fromUtf8("label_RecSop"));
        label_RecSop->setEnabled(true);
        sizePolicy4.setHeightForWidth(label_RecSop->sizePolicy().hasHeightForWidth());
        label_RecSop->setSizePolicy(sizePolicy4);

        gridLayout_2->addWidget(label_RecSop, 0, 0, 1, 1);

        lineEdit_RecSop = new QLineEdit(groupBox_4);
        lineEdit_RecSop->setObjectName(QString::fromUtf8("lineEdit_RecSop"));
        sizePolicy2.setHeightForWidth(lineEdit_RecSop->sizePolicy().hasHeightForWidth());
        lineEdit_RecSop->setSizePolicy(sizePolicy2);
        lineEdit_RecSop->setReadOnly(true);

        gridLayout_2->addWidget(lineEdit_RecSop, 0, 1, 1, 1);

        label_RecLen = new QLabel(groupBox_4);
        label_RecLen->setObjectName(QString::fromUtf8("label_RecLen"));
        sizePolicy4.setHeightForWidth(label_RecLen->sizePolicy().hasHeightForWidth());
        label_RecLen->setSizePolicy(sizePolicy4);

        gridLayout_2->addWidget(label_RecLen, 1, 0, 1, 1);

        lineEdit_RecLen = new QLineEdit(groupBox_4);
        lineEdit_RecLen->setObjectName(QString::fromUtf8("lineEdit_RecLen"));
        sizePolicy2.setHeightForWidth(lineEdit_RecLen->sizePolicy().hasHeightForWidth());
        lineEdit_RecLen->setSizePolicy(sizePolicy2);
        lineEdit_RecLen->setReadOnly(true);

        gridLayout_2->addWidget(lineEdit_RecLen, 1, 1, 1, 1);

        label_RecCmd = new QLabel(groupBox_4);
        label_RecCmd->setObjectName(QString::fromUtf8("label_RecCmd"));
        sizePolicy4.setHeightForWidth(label_RecCmd->sizePolicy().hasHeightForWidth());
        label_RecCmd->setSizePolicy(sizePolicy4);

        gridLayout_2->addWidget(label_RecCmd, 2, 0, 1, 1);

        lineEdit_RecCmd = new QLineEdit(groupBox_4);
        lineEdit_RecCmd->setObjectName(QString::fromUtf8("lineEdit_RecCmd"));
        sizePolicy3.setHeightForWidth(lineEdit_RecCmd->sizePolicy().hasHeightForWidth());
        lineEdit_RecCmd->setSizePolicy(sizePolicy3);
        lineEdit_RecCmd->setReadOnly(true);

        gridLayout_2->addWidget(lineEdit_RecCmd, 2, 1, 1, 1);

        label_RecNa = new QLabel(groupBox_4);
        label_RecNa->setObjectName(QString::fromUtf8("label_RecNa"));
        sizePolicy4.setHeightForWidth(label_RecNa->sizePolicy().hasHeightForWidth());
        label_RecNa->setSizePolicy(sizePolicy4);

        gridLayout_2->addWidget(label_RecNa, 3, 0, 1, 1);

        lineEdit_RecNa = new QLineEdit(groupBox_4);
        lineEdit_RecNa->setObjectName(QString::fromUtf8("lineEdit_RecNa"));
        sizePolicy2.setHeightForWidth(lineEdit_RecNa->sizePolicy().hasHeightForWidth());
        lineEdit_RecNa->setSizePolicy(sizePolicy2);
        lineEdit_RecNa->setReadOnly(true);

        gridLayout_2->addWidget(lineEdit_RecNa, 3, 1, 1, 1);

        label_RecAppCmd = new QLabel(groupBox_4);
        label_RecAppCmd->setObjectName(QString::fromUtf8("label_RecAppCmd"));
        QSizePolicy sizePolicy10(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy10.setHorizontalStretch(0);
        sizePolicy10.setVerticalStretch(0);
        sizePolicy10.setHeightForWidth(label_RecAppCmd->sizePolicy().hasHeightForWidth());
        label_RecAppCmd->setSizePolicy(sizePolicy10);

        gridLayout_2->addWidget(label_RecAppCmd, 4, 0, 1, 1);

        lineEdit_RecAppCmd = new QLineEdit(groupBox_4);
        lineEdit_RecAppCmd->setObjectName(QString::fromUtf8("lineEdit_RecAppCmd"));
        sizePolicy2.setHeightForWidth(lineEdit_RecAppCmd->sizePolicy().hasHeightForWidth());
        lineEdit_RecAppCmd->setSizePolicy(sizePolicy2);
        lineEdit_RecAppCmd->setReadOnly(true);

        gridLayout_2->addWidget(lineEdit_RecAppCmd, 4, 1, 1, 1);

        label_Recrelease = new QLabel(groupBox_4);
        label_Recrelease->setObjectName(QString::fromUtf8("label_Recrelease"));

        gridLayout_2->addWidget(label_Recrelease, 5, 0, 1, 1);

        lineEdit_release = new QLineEdit(groupBox_4);
        lineEdit_release->setObjectName(QString::fromUtf8("lineEdit_release"));

        gridLayout_2->addWidget(lineEdit_release, 5, 1, 1, 1);

        label_RecAppData = new QLabel(groupBox_4);
        label_RecAppData->setObjectName(QString::fromUtf8("label_RecAppData"));
        sizePolicy10.setHeightForWidth(label_RecAppData->sizePolicy().hasHeightForWidth());
        label_RecAppData->setSizePolicy(sizePolicy10);

        gridLayout_2->addWidget(label_RecAppData, 6, 0, 1, 1);

        lineEdit_RecAppData = new QLineEdit(groupBox_4);
        lineEdit_RecAppData->setObjectName(QString::fromUtf8("lineEdit_RecAppData"));
        sizePolicy2.setHeightForWidth(lineEdit_RecAppData->sizePolicy().hasHeightForWidth());
        lineEdit_RecAppData->setSizePolicy(sizePolicy2);
        lineEdit_RecAppData->setReadOnly(true);

        gridLayout_2->addWidget(lineEdit_RecAppData, 6, 1, 1, 1);

        label_RecFcs = new QLabel(groupBox_4);
        label_RecFcs->setObjectName(QString::fromUtf8("label_RecFcs"));
        sizePolicy6.setHeightForWidth(label_RecFcs->sizePolicy().hasHeightForWidth());
        label_RecFcs->setSizePolicy(sizePolicy6);

        gridLayout_2->addWidget(label_RecFcs, 7, 0, 1, 1);

        lineEdit_RecFcs = new QLineEdit(groupBox_4);
        lineEdit_RecFcs->setObjectName(QString::fromUtf8("lineEdit_RecFcs"));
        sizePolicy2.setHeightForWidth(lineEdit_RecFcs->sizePolicy().hasHeightForWidth());
        lineEdit_RecFcs->setSizePolicy(sizePolicy2);
        lineEdit_RecFcs->setReadOnly(true);

        gridLayout_2->addWidget(lineEdit_RecFcs, 7, 1, 1, 1);


        horizontalLayout_7->addLayout(gridLayout_2);


        verticalLayout_33->addWidget(groupBox_4);

        groupBox_6 = new QGroupBox(centralWidget);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        QSizePolicy sizePolicy11(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy11.setHorizontalStretch(0);
        sizePolicy11.setVerticalStretch(0);
        sizePolicy11.setHeightForWidth(groupBox_6->sizePolicy().hasHeightForWidth());
        groupBox_6->setSizePolicy(sizePolicy11);
        horizontalLayout_5 = new QHBoxLayout(groupBox_6);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_SendSop = new QLabel(groupBox_6);
        label_SendSop->setObjectName(QString::fromUtf8("label_SendSop"));
        label_SendSop->setEnabled(true);
        sizePolicy4.setHeightForWidth(label_SendSop->sizePolicy().hasHeightForWidth());
        label_SendSop->setSizePolicy(sizePolicy4);

        gridLayout->addWidget(label_SendSop, 0, 0, 1, 1);

        lineEdit_SendSop = new QLineEdit(groupBox_6);
        lineEdit_SendSop->setObjectName(QString::fromUtf8("lineEdit_SendSop"));
        sizePolicy2.setHeightForWidth(lineEdit_SendSop->sizePolicy().hasHeightForWidth());
        lineEdit_SendSop->setSizePolicy(sizePolicy2);
        lineEdit_SendSop->setReadOnly(true);

        gridLayout->addWidget(lineEdit_SendSop, 0, 1, 1, 1);

        label_SendLen = new QLabel(groupBox_6);
        label_SendLen->setObjectName(QString::fromUtf8("label_SendLen"));
        sizePolicy4.setHeightForWidth(label_SendLen->sizePolicy().hasHeightForWidth());
        label_SendLen->setSizePolicy(sizePolicy4);

        gridLayout->addWidget(label_SendLen, 1, 0, 1, 1);

        lineEdit_SendLen = new QLineEdit(groupBox_6);
        lineEdit_SendLen->setObjectName(QString::fromUtf8("lineEdit_SendLen"));
        sizePolicy2.setHeightForWidth(lineEdit_SendLen->sizePolicy().hasHeightForWidth());
        lineEdit_SendLen->setSizePolicy(sizePolicy2);
        lineEdit_SendLen->setReadOnly(true);

        gridLayout->addWidget(lineEdit_SendLen, 1, 1, 1, 1);

        label_Send_Cmd = new QLabel(groupBox_6);
        label_Send_Cmd->setObjectName(QString::fromUtf8("label_Send_Cmd"));

        gridLayout->addWidget(label_Send_Cmd, 2, 0, 1, 1);

        lineEdit_Send_Cmd = new QLineEdit(groupBox_6);
        lineEdit_Send_Cmd->setObjectName(QString::fromUtf8("lineEdit_Send_Cmd"));
        lineEdit_Send_Cmd->setReadOnly(true);

        gridLayout->addWidget(lineEdit_Send_Cmd, 2, 1, 1, 1);

        label_SendNa = new QLabel(groupBox_6);
        label_SendNa->setObjectName(QString::fromUtf8("label_SendNa"));
        sizePolicy4.setHeightForWidth(label_SendNa->sizePolicy().hasHeightForWidth());
        label_SendNa->setSizePolicy(sizePolicy4);

        gridLayout->addWidget(label_SendNa, 3, 0, 1, 1);

        lineEdit_SendNa = new QLineEdit(groupBox_6);
        lineEdit_SendNa->setObjectName(QString::fromUtf8("lineEdit_SendNa"));
        sizePolicy2.setHeightForWidth(lineEdit_SendNa->sizePolicy().hasHeightForWidth());
        lineEdit_SendNa->setSizePolicy(sizePolicy2);
        lineEdit_SendNa->setReadOnly(false);

        gridLayout->addWidget(lineEdit_SendNa, 3, 1, 1, 1);

        label_SendCmd = new QLabel(groupBox_6);
        label_SendCmd->setObjectName(QString::fromUtf8("label_SendCmd"));
        sizePolicy10.setHeightForWidth(label_SendCmd->sizePolicy().hasHeightForWidth());
        label_SendCmd->setSizePolicy(sizePolicy10);

        gridLayout->addWidget(label_SendCmd, 4, 0, 1, 1);

        comboBox_Send_AppCmd = new QComboBox(groupBox_6);
        comboBox_Send_AppCmd->addItem(QString());
        comboBox_Send_AppCmd->addItem(QString());
        comboBox_Send_AppCmd->addItem(QString());
        comboBox_Send_AppCmd->addItem(QString());
        comboBox_Send_AppCmd->setObjectName(QString::fromUtf8("comboBox_Send_AppCmd"));
        sizePolicy2.setHeightForWidth(comboBox_Send_AppCmd->sizePolicy().hasHeightForWidth());
        comboBox_Send_AppCmd->setSizePolicy(sizePolicy2);

        gridLayout->addWidget(comboBox_Send_AppCmd, 4, 1, 1, 1);

        LoRa_label_release = new QLabel(groupBox_6);
        LoRa_label_release->setObjectName(QString::fromUtf8("LoRa_label_release"));

        gridLayout->addWidget(LoRa_label_release, 5, 0, 1, 1);

        LoRa_lineEdit_release = new QLineEdit(groupBox_6);
        LoRa_lineEdit_release->setObjectName(QString::fromUtf8("LoRa_lineEdit_release"));

        gridLayout->addWidget(LoRa_lineEdit_release, 5, 1, 1, 1);

        label_SendData = new QLabel(groupBox_6);
        label_SendData->setObjectName(QString::fromUtf8("label_SendData"));
        sizePolicy1.setHeightForWidth(label_SendData->sizePolicy().hasHeightForWidth());
        label_SendData->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(label_SendData, 6, 0, 1, 1);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(3);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        lineEdit_SendData = new QLineEdit(groupBox_6);
        lineEdit_SendData->setObjectName(QString::fromUtf8("lineEdit_SendData"));
        sizePolicy2.setHeightForWidth(lineEdit_SendData->sizePolicy().hasHeightForWidth());
        lineEdit_SendData->setSizePolicy(sizePolicy2);
        lineEdit_SendData->setLayoutDirection(Qt::LeftToRight);
        lineEdit_SendData->setReadOnly(false);

        horizontalLayout_6->addWidget(lineEdit_SendData);

        le_sendTime = new QLineEdit(groupBox_6);
        le_sendTime->setObjectName(QString::fromUtf8("le_sendTime"));
        sizePolicy8.setHeightForWidth(le_sendTime->sizePolicy().hasHeightForWidth());
        le_sendTime->setSizePolicy(sizePolicy8);
        le_sendTime->setMinimumSize(QSize(50, 0));
        le_sendTime->setMaximumSize(QSize(50, 16777215));

        horizontalLayout_6->addWidget(le_sendTime);

        chk_sendEnd = new QCheckBox(groupBox_6);
        chk_sendEnd->setObjectName(QString::fromUtf8("chk_sendEnd"));

        horizontalLayout_6->addWidget(chk_sendEnd);

        pushButton_Send = new QPushButton(groupBox_6);
        pushButton_Send->setObjectName(QString::fromUtf8("pushButton_Send"));
        sizePolicy8.setHeightForWidth(pushButton_Send->sizePolicy().hasHeightForWidth());
        pushButton_Send->setSizePolicy(sizePolicy8);

        horizontalLayout_6->addWidget(pushButton_Send);


        gridLayout->addLayout(horizontalLayout_6, 6, 1, 1, 1);

        label_SendFcs = new QLabel(groupBox_6);
        label_SendFcs->setObjectName(QString::fromUtf8("label_SendFcs"));
        sizePolicy6.setHeightForWidth(label_SendFcs->sizePolicy().hasHeightForWidth());
        label_SendFcs->setSizePolicy(sizePolicy6);

        gridLayout->addWidget(label_SendFcs, 7, 0, 1, 1);

        lineEdit_SendFcs = new QLineEdit(groupBox_6);
        lineEdit_SendFcs->setObjectName(QString::fromUtf8("lineEdit_SendFcs"));
        sizePolicy2.setHeightForWidth(lineEdit_SendFcs->sizePolicy().hasHeightForWidth());
        lineEdit_SendFcs->setSizePolicy(sizePolicy2);
        lineEdit_SendFcs->setReadOnly(true);

        gridLayout->addWidget(lineEdit_SendFcs, 7, 1, 1, 1);


        horizontalLayout_5->addLayout(gridLayout);


        verticalLayout_33->addWidget(groupBox_6);

        verticalLayout_33->setStretch(0, 1);
        verticalLayout_33->setStretch(1, 1);

        horizontalLayout_8->addLayout(verticalLayout_33);

        horizontalLayout_8->setStretch(0, 7);
        horizontalLayout_8->setStretch(1, 5);

        verticalLayout_37->addLayout(horizontalLayout_8);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        horizontalLayout_17->setSizeConstraint(QLayout::SetFixedSize);
        label_StateText = new QLabel(centralWidget);
        label_StateText->setObjectName(QString::fromUtf8("label_StateText"));
        sizePolicy1.setHeightForWidth(label_StateText->sizePolicy().hasHeightForWidth());
        label_StateText->setSizePolicy(sizePolicy1);

        horizontalLayout_17->addWidget(label_StateText);

        label_State = new QLabel(centralWidget);
        label_State->setObjectName(QString::fromUtf8("label_State"));
        sizePolicy1.setHeightForWidth(label_State->sizePolicy().hasHeightForWidth());
        label_State->setSizePolicy(sizePolicy1);

        horizontalLayout_17->addWidget(label_State);

        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        QSizePolicy sizePolicy12(QSizePolicy::Fixed, QSizePolicy::Minimum);
        sizePolicy12.setHorizontalStretch(0);
        sizePolicy12.setVerticalStretch(0);
        sizePolicy12.setHeightForWidth(line->sizePolicy().hasHeightForWidth());
        line->setSizePolicy(sizePolicy12);
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);

        horizontalLayout_17->addWidget(line);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_3);

        lbl_version = new QLabel(centralWidget);
        lbl_version->setObjectName(QString::fromUtf8("lbl_version"));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        font1.setKerning(true);
        lbl_version->setFont(font1);
        lbl_version->setLayoutDirection(Qt::LeftToRight);

        horizontalLayout_17->addWidget(lbl_version);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_2);

        line_2 = new QFrame(centralWidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        sizePolicy12.setHeightForWidth(line_2->sizePolicy().hasHeightForWidth());
        line_2->setSizePolicy(sizePolicy12);
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        horizontalLayout_17->addWidget(line_2);

        label_CountRecv = new QLabel(centralWidget);
        label_CountRecv->setObjectName(QString::fromUtf8("label_CountRecv"));
        sizePolicy1.setHeightForWidth(label_CountRecv->sizePolicy().hasHeightForWidth());
        label_CountRecv->setSizePolicy(sizePolicy1);

        horizontalLayout_17->addWidget(label_CountRecv);

        label_CountRecvNum = new QLabel(centralWidget);
        label_CountRecvNum->setObjectName(QString::fromUtf8("label_CountRecvNum"));
        sizePolicy1.setHeightForWidth(label_CountRecvNum->sizePolicy().hasHeightForWidth());
        label_CountRecvNum->setSizePolicy(sizePolicy1);

        horizontalLayout_17->addWidget(label_CountRecvNum);

        label_CountSend = new QLabel(centralWidget);
        label_CountSend->setObjectName(QString::fromUtf8("label_CountSend"));
        sizePolicy1.setHeightForWidth(label_CountSend->sizePolicy().hasHeightForWidth());
        label_CountSend->setSizePolicy(sizePolicy1);

        horizontalLayout_17->addWidget(label_CountSend);

        label_CountSendNum = new QLabel(centralWidget);
        label_CountSendNum->setObjectName(QString::fromUtf8("label_CountSendNum"));
        sizePolicy1.setHeightForWidth(label_CountSendNum->sizePolicy().hasHeightForWidth());
        label_CountSendNum->setSizePolicy(sizePolicy1);

        horizontalLayout_17->addWidget(label_CountSendNum);

        pushButton_DelNum = new QPushButton(centralWidget);
        pushButton_DelNum->setObjectName(QString::fromUtf8("pushButton_DelNum"));
        sizePolicy1.setHeightForWidth(pushButton_DelNum->sizePolicy().hasHeightForWidth());
        pushButton_DelNum->setSizePolicy(sizePolicy1);

        horizontalLayout_17->addWidget(pushButton_DelNum);


        verticalLayout_37->addLayout(horizontalLayout_17);


        horizontalLayout_36->addLayout(verticalLayout_37);

        MainWindow->setCentralWidget(centralWidget);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        sizePolicy4.setHeightForWidth(toolBar->sizePolicy().hasHeightForWidth());
        toolBar->setSizePolicy(sizePolicy4);
        toolBar->setMaximumSize(QSize(16777215, 16777215));
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        toolBar->addAction(actionZigBee);
        toolBar->addAction(actionLoRa);
        toolBar->addAction(actionBLE);
        toolBar->addAction(actionWiFi);
        toolBar->addAction(actionWiFi2);
        toolBar->addAction(actionNB_IoT);
        toolBar->addAction(actionCAT1);
        toolBar->addAction(action4G);
        toolBar->addAction(actionLoRaWAN);
        toolBar->addSeparator();
        toolBar->addAction(action_save);
        toolBar->addSeparator();
        toolBar->addAction(actionabout);

        retranslateUi(MainWindow);
        QObject::connect(pushButton_DelNum, SIGNAL(clicked()), MainWindow, SLOT(Del_Num()));
        QObject::connect(lineEdit_SendData, SIGNAL(textChanged(QString)), MainWindow, SLOT(Mode_Group()));
        QObject::connect(pushButton_OpenCom, SIGNAL(clicked()), MainWindow, SLOT(OpenUart_Clicked()));
        QObject::connect(pushButton_OpenRec, SIGNAL(clicked()), MainWindow, SLOT(OpenRecv_Clicked()));
        QObject::connect(pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(Write_NetWord()));
        QObject::connect(pushButton_DelRec, SIGNAL(clicked()), MainWindow, SLOT(Del_RecData()));
        QObject::connect(pushButton_DelSend, SIGNAL(clicked()), MainWindow, SLOT(Del_SendData()));
        QObject::connect(lineEdit_SendNa, SIGNAL(textChanged(QString)), MainWindow, SLOT(Mode_Group()));
        QObject::connect(comboBox_Send_AppCmd, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(Mode_Group()));
        QObject::connect(lineEdit_SendNa, SIGNAL(textChanged(QString)), MainWindow, SLOT(SendNa_Add_Space()));
        QObject::connect(comboBox_Set_Rec, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(Set_RecMode()));
        QObject::connect(comboBox_Set_Send, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(Set_SendMode()));
        QObject::connect(G_pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(Write_IDK()));
        QObject::connect(NB_pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(Write_IDK()));
        QObject::connect(listWidget_Rec, SIGNAL(itemClicked(QListWidgetItem*)), MainWindow, SLOT(Analysis()));
        QObject::connect(LoRa_pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(Write_LoRa()));
        QObject::connect(lineEdit_Send_Cmd, SIGNAL(textChanged(QString)), MainWindow, SLOT(Mode_Group()));
        QObject::connect(G_pushButton_Shore, SIGNAL(clicked()), MainWindow, SLOT(Out_Code()));
        QObject::connect(NB_pushButton_Share, SIGNAL(clicked()), MainWindow, SLOT(Out_Code()));
        QObject::connect(LoRa_comboBox_HOP, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(LoRa_Show_HOP()));
        QObject::connect(lineEdit_SendLen, SIGNAL(textChanged(QString)), MainWindow, SLOT(Mode_Group()));
        QObject::connect(lineEdit_Send_Cmd, SIGNAL(textChanged(QString)), MainWindow, SLOT(SendCmd_Add_Space()));
        QObject::connect(WiFi_pushButton_Read, SIGNAL(clicked(bool)), MainWindow, SLOT(WiFi_AT_Test()));
        QObject::connect(WiFi_pushButton_Write, SIGNAL(clicked(bool)), MainWindow, SLOT(WiFi_Write_Net()));
        QObject::connect(pushButton_Read, SIGNAL(clicked(bool)), MainWindow, SLOT(ZigBee_AT_Test()));
        QObject::connect(LoRa_pushButton_Read, SIGNAL(clicked(bool)), MainWindow, SLOT(LoRa_AT_Test()));
        QObject::connect(lineEdit_SendData, SIGNAL(textChanged(QString)), MainWindow, SLOT(SendData_Add_Space()));
        QObject::connect(G_pushButton_Read, SIGNAL(clicked(bool)), MainWindow, SLOT(NB_AT_Test()));
        QObject::connect(NB_pushButton_Read, SIGNAL(clicked(bool)), MainWindow, SLOT(NB_AT_Test()));
        QObject::connect(LoRa_lineEdit_release, SIGNAL(textChanged(QString)), MainWindow, SLOT(Mode_Group()));
        QObject::connect(BLE_pushButton_TextLink, SIGNAL(clicked(bool)), MainWindow, SLOT(BLE_TestLink()));
        QObject::connect(BLE_pushButton_ReadMac, SIGNAL(clicked(bool)), MainWindow, SLOT(NB_AT_Test()));
        QObject::connect(CAT1_pushButton_Share, SIGNAL(clicked()), MainWindow, SLOT(Out_Code()));
        QObject::connect(CAT1_pushButton_Read, SIGNAL(clicked(bool)), MainWindow, SLOT(CAT1_AT_Test()));
        QObject::connect(CAT1_pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(CAT1_Write_Cfg()));
        QObject::connect(ESP8266_btn_share, SIGNAL(clicked()), MainWindow, SLOT(Out_Code()));
        QObject::connect(ESP8266_pushButton_Read, SIGNAL(clicked(bool)), MainWindow, SLOT(ESP8266_AT_Test()));
        QObject::connect(ESP8266_pushButton_Write, SIGNAL(clicked()), MainWindow, SLOT(ESP8266_Write_Cfg()));
        QObject::connect(ESP8266_comboBox_mode, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(ESP8266_Mode_Select(int)));

        stackedWidget->setCurrentIndex(0);
        LoRa_comboBox_SF->setCurrentIndex(2);
        LoRa_comboBox_BW->setCurrentIndex(5);
        LoRa_comboBox_HOP->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "xLabTools", nullptr));
        actionZigBee->setText(QApplication::translate("MainWindow", "ZigBee(&Z)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionZigBee->setToolTip(QApplication::translate("MainWindow", "ZigBee", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionZigBee->setShortcut(QApplication::translate("MainWindow", "Alt+Z", nullptr));
#endif // QT_NO_SHORTCUT
        actionLoRa->setText(QApplication::translate("MainWindow", "LoRa(&L)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionLoRa->setToolTip(QApplication::translate("MainWindow", "LoRa", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionLoRa->setShortcut(QApplication::translate("MainWindow", "Alt+L", nullptr));
#endif // QT_NO_SHORTCUT
        action4G->setText(QApplication::translate("MainWindow", "LTE(&G)", nullptr));
#ifndef QT_NO_TOOLTIP
        action4G->setToolTip(QApplication::translate("MainWindow", "LTE", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        action4G->setShortcut(QApplication::translate("MainWindow", "Alt+G", nullptr));
#endif // QT_NO_SHORTCUT
        actionNB_IoT->setText(QApplication::translate("MainWindow", "NB_IoT(&N)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionNB_IoT->setToolTip(QApplication::translate("MainWindow", "NB_IoT", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionNB_IoT->setShortcut(QApplication::translate("MainWindow", "Alt+N", nullptr));
#endif // QT_NO_SHORTCUT
        actionabout->setText(QApplication::translate("MainWindow", "\347\211\210\346\234\254\346\233\264\346\226\260(&U)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionabout->setToolTip(QApplication::translate("MainWindow", "\347\211\210\346\234\254\346\233\264\346\226\260", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionabout->setShortcut(QApplication::translate("MainWindow", "Alt+U", nullptr));
#endif // QT_NO_SHORTCUT
        actionWiFi->setText(QApplication::translate("MainWindow", "WiFi(CC3200)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionWiFi->setToolTip(QApplication::translate("MainWindow", "WiFi(CC3200)", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionWiFi->setShortcut(QApplication::translate("MainWindow", "Alt+W", nullptr));
#endif // QT_NO_SHORTCUT
        actionWiFi2->setText(QApplication::translate("MainWindow", "WiFi(ESP8266)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionWiFi2->setToolTip(QApplication::translate("MainWindow", "WiFi(ESP8266)", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionWiFi2->setShortcut(QApplication::translate("MainWindow", "Alt+E", nullptr));
#endif // QT_NO_SHORTCUT
        actionBLE->setText(QApplication::translate("MainWindow", "BLE(&B)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionBLE->setToolTip(QApplication::translate("MainWindow", "BLE", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionBLE->setShortcut(QApplication::translate("MainWindow", "Alt+B", nullptr));
#endif // QT_NO_SHORTCUT
        action_save->setText(QApplication::translate("MainWindow", "\344\277\235\345\255\230\346\225\260\346\215\256(&S)", nullptr));
#ifndef QT_NO_TOOLTIP
        action_save->setToolTip(QApplication::translate("MainWindow", "\344\277\235\345\255\230\346\225\260\346\215\256\350\256\260\345\275\225\350\207\263\346\226\207\346\234\254", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        action_save->setShortcut(QApplication::translate("MainWindow", "Alt+S", nullptr));
#endif // QT_NO_SHORTCUT
        actionLoRaWAN->setText(QApplication::translate("MainWindow", "LoRaWAN(&R)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionLoRaWAN->setToolTip(QApplication::translate("MainWindow", "LoRaWAN", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionLoRaWAN->setShortcut(QApplication::translate("MainWindow", "Alt+R", nullptr));
#endif // QT_NO_SHORTCUT
        actionCAT1->setText(QApplication::translate("MainWindow", "CAT1(&C)", nullptr));
#ifndef QT_NO_TOOLTIP
        actionCAT1->setToolTip(QApplication::translate("MainWindow", "CAT1", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_SHORTCUT
        actionCAT1->setShortcut(QApplication::translate("MainWindow", "Alt+C", nullptr));
#endif // QT_NO_SHORTCUT
        groupBox->setTitle(QApplication::translate("MainWindow", "\350\275\257\344\273\266\350\256\276\347\275\256", nullptr));
        label_Com->setText(QApplication::translate("MainWindow", "<html><head/><body><p>\344\270\262\345\217\243\345\217\267:</p></body></html>", nullptr));
        label_Baud->setText(QApplication::translate("MainWindow", "<html><head/><body><p>\346\263\242\347\211\271\347\216\207:</p></body></html>", nullptr));
        comboBox_Baud->setItemText(0, QApplication::translate("MainWindow", "1200", nullptr));
        comboBox_Baud->setItemText(1, QApplication::translate("MainWindow", "2400", nullptr));
        comboBox_Baud->setItemText(2, QApplication::translate("MainWindow", "4800", nullptr));
        comboBox_Baud->setItemText(3, QApplication::translate("MainWindow", "9600", nullptr));
        comboBox_Baud->setItemText(4, QApplication::translate("MainWindow", "19200", nullptr));
        comboBox_Baud->setItemText(5, QApplication::translate("MainWindow", "38400", nullptr));
        comboBox_Baud->setItemText(6, QApplication::translate("MainWindow", "57600", nullptr));
        comboBox_Baud->setItemText(7, QApplication::translate("MainWindow", "115200", nullptr));

#ifndef QT_NO_TOOLTIP
        pushButton_OpenCom->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        pushButton_OpenCom->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\243", nullptr));
        pushButton_OpenRec->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213\346\216\245\346\224\266", nullptr));
        groupBox_ZigBee->setTitle(QApplication::translate("MainWindow", "ZigBee\351\205\215\347\275\256", nullptr));
        label_Name_text->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_Panid_text->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">PANID\357\274\232</p></body></html>", nullptr));
        lineEdit_Add->setPlaceholderText(QApplication::translate("MainWindow", "MAC\345\234\260\345\235\200", nullptr));
        lineEdit_Panid->setText(QString());
        lineEdit_Panid->setPlaceholderText(QApplication::translate("MainWindow", "1--16383", nullptr));
        label_Type_text->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\347\261\273\345\236\213\357\274\232</p></body></html>", nullptr));
        label_Channel_text->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">CHANNEL\357\274\232</p></body></html>", nullptr));
        comboBox_Mold->setItemText(0, QApplication::translate("MainWindow", "\345\215\217\350\260\203\345\231\250", nullptr));
        comboBox_Mold->setItemText(1, QApplication::translate("MainWindow", "\350\267\257\347\224\261\350\212\202\347\202\271", nullptr));
        comboBox_Mold->setItemText(2, QApplication::translate("MainWindow", "\347\273\210\347\253\257\350\212\202\347\202\271", nullptr));

        comboBox_Channel->setItemText(0, QApplication::translate("MainWindow", "11", nullptr));
        comboBox_Channel->setItemText(1, QApplication::translate("MainWindow", "12", nullptr));
        comboBox_Channel->setItemText(2, QApplication::translate("MainWindow", "13", nullptr));
        comboBox_Channel->setItemText(3, QApplication::translate("MainWindow", "14", nullptr));
        comboBox_Channel->setItemText(4, QApplication::translate("MainWindow", "15", nullptr));
        comboBox_Channel->setItemText(5, QApplication::translate("MainWindow", "16", nullptr));
        comboBox_Channel->setItemText(6, QApplication::translate("MainWindow", "17", nullptr));
        comboBox_Channel->setItemText(7, QApplication::translate("MainWindow", "18", nullptr));
        comboBox_Channel->setItemText(8, QApplication::translate("MainWindow", "19", nullptr));
        comboBox_Channel->setItemText(9, QApplication::translate("MainWindow", "20", nullptr));
        comboBox_Channel->setItemText(10, QApplication::translate("MainWindow", "21", nullptr));
        comboBox_Channel->setItemText(11, QApplication::translate("MainWindow", "22", nullptr));
        comboBox_Channel->setItemText(12, QApplication::translate("MainWindow", "23", nullptr));
        comboBox_Channel->setItemText(13, QApplication::translate("MainWindow", "24", nullptr));
        comboBox_Channel->setItemText(14, QApplication::translate("MainWindow", "25", nullptr));
        comboBox_Channel->setItemText(15, QApplication::translate("MainWindow", "26", nullptr));

        pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        groupBox_LoRa->setTitle(QApplication::translate("MainWindow", "LoRa\351\205\215\347\275\256", nullptr));
        label_17->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_18->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\347\261\273\345\236\213\357\274\232</p></body></html>", nullptr));
        label_12->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\347\275\221\347\273\234ID\357\274\232</p></body></html>", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\347\274\226\347\240\201\347\216\207\357\274\232</p></body></html>", nullptr));
        LoRa_lineEdit_ID->setPlaceholderText(QApplication::translate("MainWindow", "1-254", nullptr));
        LoRa_comboBox_CR->setItemText(0, QApplication::translate("MainWindow", "4/5", nullptr));
        LoRa_comboBox_CR->setItemText(1, QApplication::translate("MainWindow", "4/6", nullptr));
        LoRa_comboBox_CR->setItemText(2, QApplication::translate("MainWindow", "4/7", nullptr));
        LoRa_comboBox_CR->setItemText(3, QApplication::translate("MainWindow", "4/8", nullptr));

        label_7->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\227\240\347\272\277\345\212\237\347\216\207\357\274\232</p></body></html>", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\211\251\351\242\221\345\233\240\345\255\220\357\274\232</p></body></html>", nullptr));
#ifndef QT_NO_TOOLTIP
        LoRa_lineEdit_PV->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        LoRa_lineEdit_PV->setText(QString());
        LoRa_lineEdit_PV->setPlaceholderText(QApplication::translate("MainWindow", "0-20", nullptr));
        LoRa_comboBox_SF->setItemText(0, QApplication::translate("MainWindow", "6", nullptr));
        LoRa_comboBox_SF->setItemText(1, QApplication::translate("MainWindow", "7", nullptr));
        LoRa_comboBox_SF->setItemText(2, QApplication::translate("MainWindow", "8", nullptr));
        LoRa_comboBox_SF->setItemText(3, QApplication::translate("MainWindow", "9", nullptr));
        LoRa_comboBox_SF->setItemText(4, QApplication::translate("MainWindow", "10", nullptr));
        LoRa_comboBox_SF->setItemText(5, QApplication::translate("MainWindow", "11", nullptr));
        LoRa_comboBox_SF->setItemText(6, QApplication::translate("MainWindow", "12", nullptr));

        label_8->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\237\272\351\242\221\357\274\232</p></body></html>", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\270\246\345\256\275\357\274\232</p></body></html>", nullptr));
#ifndef QT_NO_TOOLTIP
        LoRa_lineEdit_FP->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        LoRa_lineEdit_FP->setText(QString());
        LoRa_lineEdit_FP->setPlaceholderText(QApplication::translate("MainWindow", "410-525", nullptr));
        LoRa_comboBox_BW->setItemText(0, QApplication::translate("MainWindow", "7.8KHz", nullptr));
        LoRa_comboBox_BW->setItemText(1, QApplication::translate("MainWindow", "10.4KHz", nullptr));
        LoRa_comboBox_BW->setItemText(2, QApplication::translate("MainWindow", "15.6KHz", nullptr));
        LoRa_comboBox_BW->setItemText(3, QApplication::translate("MainWindow", "20.8KHz", nullptr));
        LoRa_comboBox_BW->setItemText(4, QApplication::translate("MainWindow", "31.25KHz", nullptr));
        LoRa_comboBox_BW->setItemText(5, QApplication::translate("MainWindow", "41.7KHz", nullptr));
        LoRa_comboBox_BW->setItemText(6, QApplication::translate("MainWindow", "62.58KHz", nullptr));
        LoRa_comboBox_BW->setItemText(7, QApplication::translate("MainWindow", "125KHz", nullptr));
        LoRa_comboBox_BW->setItemText(8, QApplication::translate("MainWindow", "250KHz", nullptr));
        LoRa_comboBox_BW->setItemText(9, QApplication::translate("MainWindow", "500KHz", nullptr));

        label_6->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\211\215\345\257\274\347\240\201\351\225\277\345\272\246\357\274\232</p></body></html>", nullptr));
        label->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\230\257\345\220\246\350\267\263\351\242\221\357\274\232</p></body></html>", nullptr));
#ifndef QT_NO_TOOLTIP
        LoRa_lineEdit_PS->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        LoRa_lineEdit_PS->setText(QString());
        LoRa_lineEdit_PS->setPlaceholderText(QApplication::translate("MainWindow", "4-512", nullptr));
        LoRa_comboBox_HOP->setItemText(0, QApplication::translate("MainWindow", "\345\220\246", nullptr));
        LoRa_comboBox_HOP->setItemText(1, QApplication::translate("MainWindow", "\346\230\257", nullptr));

        LoRa_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        LoRa_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        LoRa_label_HOP_List->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\350\267\263\351\242\221\350\241\250\357\274\232</p></body></html>", nullptr));
        LoRa_lineEdit_HOP_List->setText(QString());
        LoRa_lineEdit_HOP_List->setPlaceholderText(QApplication::translate("MainWindow", "\345\277\205\351\241\273\344\270\27210\351\241\271", nullptr));
        groupBox_LTE->setTitle(QApplication::translate("MainWindow", "LTE\351\205\215\347\275\256", nullptr));
        label_14->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">ID\357\274\232</p></body></html>", nullptr));
        G_lineEdit_Add->setText(QString());
        label_13->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\234\215\345\212\241\345\231\250\357\274\232</p></body></html>", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">KEY\357\274\232</p></body></html>", nullptr));
        G_lineEdit_Sever->setText(QApplication::translate("MainWindow", "api.zhiyun360.com", nullptr));
        G_lineEdit_Sever->setPlaceholderText(QApplication::translate("MainWindow", "\346\234\215\345\212\241\345\231\250\345\234\260\345\235\200", nullptr));
        G_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        G_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        G_pushButton_Shore->setText(QApplication::translate("MainWindow", "\345\210\206\344\272\253", nullptr));
        groupBox_NB->setTitle(QApplication::translate("MainWindow", "NB_IoT\351\205\215\347\275\256", nullptr));
        label_16->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">ID\357\274\232</p></body></html>", nullptr));
        NB_lineEdit_Add->setText(QString());
        label_15->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\234\215\345\212\241\345\231\250\357\274\232</p></body></html>", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">KEY\357\274\232</p></body></html>", nullptr));
        NB_lineEdit_Sever->setText(QApplication::translate("MainWindow", "119.23.162.168", nullptr));
        NB_lineEdit_Sever->setPlaceholderText(QApplication::translate("MainWindow", "\346\234\215\345\212\241\345\231\250\345\234\260\345\235\200", nullptr));
        label_26->setText(QApplication::translate("MainWindow", "\346\250\241\345\274\217\357\274\232", nullptr));
        NB_cbx_mode->setItemText(0, QApplication::translate("MainWindow", "UDP", nullptr));
        NB_cbx_mode->setItemText(1, QApplication::translate("MainWindow", "COAP", nullptr));

        NB_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        NB_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        NB_pushButton_Share->setText(QApplication::translate("MainWindow", "\345\210\206\344\272\253", nullptr));
        groupBox_WiFi->setTitle(QApplication::translate("MainWindow", "WiFi\351\205\215\347\275\256\357\274\210CC3200\357\274\211", nullptr));
        label_25->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_19->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">SSID\357\274\232</p></body></html>", nullptr));
        WiFi_lineEdit_SSID->setText(QString());
        WiFi_lineEdit_SSID->setPlaceholderText(QApplication::translate("MainWindow", "\351\235\236\344\270\255\346\226\207\345\217\212\347\211\271\346\256\212\345\255\227\347\254\246(1--63)", nullptr));
        label_22->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\347\275\221\345\205\263IP\357\274\232</p></body></html>", nullptr));
        WiFi_label_Pass->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">WiFi\345\257\206\347\240\201\357\274\232</p></body></html>", nullptr));
        WiFi_lineEdit_IPAdd->setText(QString());
        WiFi_lineEdit_PSKPpass->setText(QString());
        WiFi_lineEdit_PSKPpass->setPlaceholderText(QApplication::translate("MainWindow", "\350\213\261\346\226\207\346\210\226\346\225\260\345\255\227\345\255\227\347\254\246(1--31)", nullptr));
        label_21->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\250\241\345\235\227IP\357\274\232</p></body></html>", nullptr));
        label_20->setText(QApplication::translate("MainWindow", "\345\212\240\345\257\206\347\261\273\345\236\213\357\274\232", nullptr));
        WiFi_comboBox_PassType->setItemText(0, QApplication::translate("MainWindow", "\346\227\240\345\212\240\345\257\206", nullptr));
        WiFi_comboBox_PassType->setItemText(1, QApplication::translate("MainWindow", "WEP", nullptr));
        WiFi_comboBox_PassType->setItemText(2, QApplication::translate("MainWindow", "WPA2", nullptr));

        WiFi_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        WiFi_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        groupBox_BLE->setTitle(QApplication::translate("MainWindow", "BLE\351\205\215\347\275\256", nullptr));
        label_23->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_24->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\205\245\347\275\221\347\212\266\346\200\201\357\274\232</p></body></html>", nullptr));
        BLE_lineEdit_Mac->setPlaceholderText(QApplication::translate("MainWindow", "MAC\345\234\260\345\235\200", nullptr));
        BLE_lineEdit_Link->setPlaceholderText(QApplication::translate("MainWindow", "\345\275\223\345\211\215\345\205\245\347\275\221\347\212\266\346\200\201", nullptr));
        BLE_pushButton_ReadMac->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        BLE_pushButton_TextLink->setText(QApplication::translate("MainWindow", "\346\243\200\346\265\213", nullptr));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "LoRaWan\351\205\215\347\275\256", nullptr));
        label_27->setText(QApplication::translate("MainWindow", "\345\234\260\345\235\200\357\274\232", nullptr));
        LoRaWAN_le_deveui->setText(QString());
        label_30->setText(QApplication::translate("MainWindow", "\345\257\206\351\222\245\357\274\232", nullptr));
#ifndef QT_NO_TOOLTIP
        LoRaWAN_le_key->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        LoRaWAN_le_key->setText(QString());
        LoRaWAN_le_key->setPlaceholderText(QApplication::translate("MainWindow", "\351\225\277\345\272\246\345\277\205\351\241\273\344\270\27232", nullptr));
        label_29->setText(QApplication::translate("MainWindow", "\350\207\252\345\212\250\345\257\206\351\222\245\357\274\232", nullptr));
        LoRaWAN_cmb_zkey->setItemText(0, QApplication::translate("MainWindow", "\345\220\246", nullptr));
        LoRaWAN_cmb_zkey->setItemText(1, QApplication::translate("MainWindow", "\346\230\257", nullptr));

        label_33->setText(QApplication::translate("MainWindow", "\351\273\230\350\256\244\351\200\237\347\216\207\357\274\232", nullptr));
        LoRaWAN_cmb_ddr->setItemText(0, QApplication::translate("MainWindow", "0", nullptr));
        LoRaWAN_cmb_ddr->setItemText(1, QApplication::translate("MainWindow", "1", nullptr));
        LoRaWAN_cmb_ddr->setItemText(2, QApplication::translate("MainWindow", "2", nullptr));
        LoRaWAN_cmb_ddr->setItemText(3, QApplication::translate("MainWindow", "3", nullptr));
        LoRaWAN_cmb_ddr->setItemText(4, QApplication::translate("MainWindow", "4", nullptr));
        LoRaWAN_cmb_ddr->setItemText(5, QApplication::translate("MainWindow", "5", nullptr));

        label_28->setText(QApplication::translate("MainWindow", "\347\275\221\347\273\234\346\240\207\350\257\206\357\274\232", nullptr));
        LoRaWAN_le_joineui->setPlaceholderText(QApplication::translate("MainWindow", "\351\225\277\345\272\246\345\277\205\351\241\273\344\270\27216", nullptr));
        label_32->setText(QApplication::translate("MainWindow", "\344\277\241\351\201\223\346\216\251\347\240\201\357\274\232", nullptr));
        LoRaWAN_le_chm->setText(QApplication::translate("MainWindow", "FFFFFFFFFFFFFFFFFFFFFFFF", nullptr));
        LoRaWAN_btn_setChm->setText(QApplication::translate("MainWindow", "\350\256\276\347\275\256", nullptr));
        label_31->setText(QApplication::translate("MainWindow", "\347\261\273\345\236\213\357\274\232", nullptr));
        LoRaWAN_cmb_class->setItemText(0, QApplication::translate("MainWindow", "A", nullptr));
        LoRaWAN_cmb_class->setItemText(1, QApplication::translate("MainWindow", "C", nullptr));

        label_34->setText(QApplication::translate("MainWindow", "\350\207\252\345\212\250\351\200\237\347\216\207\357\274\232", nullptr));
        LoRaWAN_cmb_adr->setItemText(0, QApplication::translate("MainWindow", "\345\220\246", nullptr));
        LoRaWAN_cmb_adr->setItemText(1, QApplication::translate("MainWindow", "\346\230\257", nullptr));

        LoRaWAN_btn_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        LoRaWAN_btn_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        groupBox_CAT1->setTitle(QApplication::translate("MainWindow", "CAT1\351\205\215\347\275\256", nullptr));
        label_35->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_36->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">ID\357\274\232</p></body></html>", nullptr));
        CAT1_lineEdit_Add->setText(QString());
        label_37->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\234\215\345\212\241\345\231\250\357\274\232</p></body></html>", nullptr));
        label_38->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">KEY\357\274\232</p></body></html>", nullptr));
        CAT1_lineEdit_Sever->setText(QApplication::translate("MainWindow", "api.zhiyun360.com", nullptr));
        CAT1_lineEdit_Sever->setPlaceholderText(QApplication::translate("MainWindow", "\346\234\215\345\212\241\345\231\250\345\234\260\345\235\200", nullptr));
        CAT1_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        CAT1_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        CAT1_pushButton_Share->setText(QApplication::translate("MainWindow", "\345\210\206\344\272\253", nullptr));
        groupBox_WiFi2->setTitle(QApplication::translate("MainWindow", "WiFi\351\205\215\347\275\256\357\274\210ESP8266\357\274\211", nullptr));
        label_252->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Mac\345\234\260\345\235\200\357\274\232</p></body></html>", nullptr));
        label_192->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\234\215\345\212\241\345\231\250\357\274\232</p></body></html>", nullptr));
        ESP8266_lineEdit_SIP->setText(QApplication::translate("MainWindow", "api.zhiyun360.com", nullptr));
        label_222->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">WiFi\345\220\215\347\247\260\357\274\232</p></body></html>", nullptr));
        ESP8266_label_Pass->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\231\272\344\272\221ID\357\274\232</p></body></html>", nullptr));
        ESP8266_lineEdit_SSID->setText(QString());
        ESP8266_lineEdit_AID->setText(QString());
        label_212->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">WiFi\345\257\206\347\240\201\357\274\232</p></body></html>", nullptr));
        label_202->setText(QApplication::translate("MainWindow", "\346\231\272\344\272\221Key\357\274\232", nullptr));
        ESP8266_pushButton_Read->setText(QApplication::translate("MainWindow", "\350\257\273\345\217\226", nullptr));
        ESP8266_pushButton_Write->setText(QApplication::translate("MainWindow", "\345\206\231\345\205\245", nullptr));
        ESP8266_comboBox_mode->setItemText(0, QApplication::translate("MainWindow", "sensor-a", nullptr));
        ESP8266_comboBox_mode->setItemText(1, QApplication::translate("MainWindow", "sensor-b", nullptr));
        ESP8266_comboBox_mode->setItemText(2, QApplication::translate("MainWindow", "sensor-c", nullptr));
        ESP8266_comboBox_mode->setItemText(3, QApplication::translate("MainWindow", "sensor-d", nullptr));
        ESP8266_comboBox_mode->setItemText(4, QApplication::translate("MainWindow", "sensor-el", nullptr));
        ESP8266_comboBox_mode->setItemText(5, QApplication::translate("MainWindow", "sensor-eh", nullptr));
        ESP8266_comboBox_mode->setItemText(6, QApplication::translate("MainWindow", "sensor-f", nullptr));

        ESP8266_btn_share->setText(QApplication::translate("MainWindow", "\345\210\206\344\272\253", nullptr));
        groupBox_8->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\346\230\276\347\244\272\350\256\276\347\275\256", nullptr));
        label_Set_Rec->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\346\216\245\346\224\266</p></body></html>", nullptr));
        comboBox_Set_Rec->setItemText(0, QApplication::translate("MainWindow", "Hex", nullptr));
        comboBox_Set_Rec->setItemText(1, QApplication::translate("MainWindow", "Ascii", nullptr));

        label_Set_Send->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">\345\217\221\351\200\201</p></body></html>", nullptr));
        comboBox_Set_Send->setItemText(0, QApplication::translate("MainWindow", "Hex", nullptr));
        comboBox_Set_Send->setItemText(1, QApplication::translate("MainWindow", "Ascii", nullptr));

        groupBox_7->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\346\270\205\351\231\244", nullptr));
        pushButton_DelRec->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244\346\225\260\346\215\256\350\256\260\345\275\225", nullptr));
        pushButton_DelSend->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244\346\225\260\346\215\256\346\250\241\346\213\237", nullptr));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\350\256\260\345\275\225", nullptr));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\350\247\243\346\236\220", nullptr));
        label_RecSop->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">SOP</p></body></html>", nullptr));
        lineEdit_RecSop->setPlaceholderText(QApplication::translate("MainWindow", " \346\225\260\346\215\256\345\244\264", nullptr));
        label_RecLen->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">LEN</p></body></html>", nullptr));
        lineEdit_RecLen->setPlaceholderText(QApplication::translate("MainWindow", " \346\225\260\346\215\256\351\225\277\345\272\246", nullptr));
        label_RecCmd->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">CMD</p></body></html>", nullptr));
        lineEdit_RecCmd->setPlaceholderText(QApplication::translate("MainWindow", " \346\240\207\347\244\272\347\240\201", nullptr));
        label_RecNa->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">NA</p></body></html>", nullptr));
        lineEdit_RecNa->setPlaceholderText(QApplication::translate("MainWindow", " \347\275\221\347\273\234\345\234\260\345\235\200", nullptr));
        label_RecAppCmd->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">APP_CMD</p></body></html>", nullptr));
        lineEdit_RecAppCmd->setPlaceholderText(QApplication::translate("MainWindow", " \346\225\260\346\215\256\346\240\207\347\244\272", nullptr));
        label_Recrelease->setText(QApplication::translate("MainWindow", "\345\215\217\350\256\256\347\211\210\346\234\254", nullptr));
        lineEdit_release->setText(QString());
        lineEdit_release->setPlaceholderText(QApplication::translate("MainWindow", " \345\215\217\350\256\256\347\211\210\346\234\254", nullptr));
        label_RecAppData->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">APP_DATA</p></body></html>", nullptr));
        lineEdit_RecAppData->setPlaceholderText(QApplication::translate("MainWindow", " \346\225\260\346\215\256", nullptr));
        label_RecFcs->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">FCS</p></body></html>", nullptr));
        lineEdit_RecFcs->setPlaceholderText(QApplication::translate("MainWindow", " \346\240\241\351\252\214\344\275\215", nullptr));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "\346\225\260\346\215\256\346\250\241\346\213\237", nullptr));
        label_SendSop->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">SOP</p></body></html>", nullptr));
        lineEdit_SendSop->setPlaceholderText(QString());
        label_SendLen->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">LEN</p></body></html>", nullptr));
        lineEdit_SendLen->setPlaceholderText(QApplication::translate("MainWindow", " \346\225\260\346\215\256\351\225\277\345\272\246(\350\207\252\345\212\250\350\256\241\347\256\227)", nullptr));
        label_Send_Cmd->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">CMD</p></body></html>", nullptr));
        lineEdit_Send_Cmd->setPlaceholderText(QString());
        label_SendNa->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">NA</p></body></html>", nullptr));
        lineEdit_SendNa->setText(QString());
        lineEdit_SendNa->setPlaceholderText(QApplication::translate("MainWindow", " \347\275\221\347\273\234\345\234\260\345\235\200", nullptr));
        label_SendCmd->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">APP_CMD</p></body></html>", nullptr));
        comboBox_Send_AppCmd->setItemText(0, QApplication::translate("MainWindow", "00 00", nullptr));
        comboBox_Send_AppCmd->setItemText(1, QApplication::translate("MainWindow", "00 02", nullptr));
        comboBox_Send_AppCmd->setItemText(2, QApplication::translate("MainWindow", "01 01", nullptr));
        comboBox_Send_AppCmd->setItemText(3, QApplication::translate("MainWindow", "01 02", nullptr));

#ifndef QT_NO_TOOLTIP
        comboBox_Send_AppCmd->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>00 00 <span style=\" font-family:'\345\256\213\344\275\223';\">\346\214\207\347\244\272\345\215\217\350\260\203\345\231\250\346\255\244\346\225\260\346\215\256\351\234\200\350\246\201\350\275\254\345\217\221\347\273\231\350\212\202\347\202\271\347\232\204\345\272\224\347\224\250\347\250\213\345\272\217\346\225\260\346\215\256</span></p><p>00 02 \347\273\231\350\212\202\347\202\271\345\217\221\351\200\201\346\225\260\346\215\256</p><p>01 01 <span style=\" font-family:'\345\256\213\344\275\223';\">\346\214\207\347\244\272\345\215\217\350\260\203\345\231\250\346\240\271\346\215\256\347\273\231\345\256\232</span><span style=\" font-family:'Arial';\">mac</span><span style=\" font-family:'\345\256\213\344\275\223';\">\345\234\260\345\235\200\346\237\245\346\211\276\347\275\221\347\273\234\345\234\260\345\235\200</span></p><p>01 02 <span style=\" font-family:'\345\256\213\344\275\223';\">\346\214\207\347\244\272\345\215\217\350\260\203\345\231\250\346\240\271\346\215\256\347\273\231\345\256\232\347"
                        "\232\204\347\275\221\347\273\234\345\234\260\345\235\200\346\237\245\346\211\276</span><span style=\" font-family:'Arial';\">mac</span><span style=\" font-family:'\345\256\213\344\275\223';\">\345\234\260\345\235\200</span></p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        LoRa_label_release->setText(QApplication::translate("MainWindow", "\345\215\217\350\256\256\347\211\210\346\234\254", nullptr));
        LoRa_lineEdit_release->setText(QApplication::translate("MainWindow", "81", nullptr));
        LoRa_lineEdit_release->setPlaceholderText(QApplication::translate("MainWindow", " \345\215\217\350\256\256\347\211\210\346\234\254", nullptr));
        label_SendData->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">APP_DATA</p></body></html>", nullptr));
        lineEdit_SendData->setPlaceholderText(QApplication::translate("MainWindow", " \346\225\260\346\215\256", nullptr));
#ifndef QT_NO_TOOLTIP
        le_sendTime->setToolTip(QApplication::translate("MainWindow", "\350\207\252\345\212\250\345\217\221\351\200\201\351\227\264\351\232\224\346\227\266\351\227\264ms", nullptr));
#endif // QT_NO_TOOLTIP
        le_sendTime->setPlaceholderText(QApplication::translate("MainWindow", " ms", nullptr));
#ifndef QT_NO_TOOLTIP
        chk_sendEnd->setToolTip(QApplication::translate("MainWindow", "\350\207\252\345\212\250\345\217\221\351\200\201", nullptr));
#endif // QT_NO_TOOLTIP
        chk_sendEnd->setText(QString());
        pushButton_Send->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", nullptr));
        label_SendFcs->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">FCS</p></body></html>", nullptr));
        lineEdit_SendFcs->setPlaceholderText(QApplication::translate("MainWindow", " \346\240\241\351\252\214\344\275\215(\350\207\252\345\212\250\350\256\241\347\256\227)", nullptr));
        label_StateText->setText(QApplication::translate("MainWindow", "\345\275\223\345\211\215\347\212\266\346\200\201\357\274\232", nullptr));
        label_State->setText(QApplication::translate("MainWindow", "\350\277\236\346\216\245\346\226\255\345\274\200", nullptr));
        lbl_version->setText(QApplication::translate("MainWindow", "v1.1.220601", nullptr));
        label_CountRecv->setText(QApplication::translate("MainWindow", "\346\216\245\346\224\266\357\274\232", nullptr));
        label_CountRecvNum->setText(QApplication::translate("MainWindow", "0", nullptr));
        label_CountSend->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201\357\274\232", nullptr));
        label_CountSendNum->setText(QApplication::translate("MainWindow", "0", nullptr));
        pushButton_DelNum->setText(QApplication::translate("MainWindow", "\350\256\241\346\225\260\346\270\205\351\233\266", nullptr));
        toolBar->setWindowTitle(QApplication::translate("MainWindow", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
