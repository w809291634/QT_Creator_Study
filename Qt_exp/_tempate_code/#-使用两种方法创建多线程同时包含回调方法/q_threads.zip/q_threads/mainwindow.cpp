﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    thread_1 = new Q_Thread();
    auto Fun = bind(&MainWindow::callBackFun,
                    this, placeholders::_1);
    // 传入 参数
    char* data=new char[10];
    memcpy(data,"sfdwer",10);
    thread_1->RegeditCallBack(Fun,data);
    thread_1->start();

    thread_2 = new Q_Thread();
    auto Fun2 = bind(&MainWindow::callBackFun,
                    this, placeholders::_1);
    // 传入 参数
    char* data2=new char[10];
    memcpy(data,"sfdwer",10);
    thread_2->RegeditCallBack(Fun2,data2);
    thread_2->start();

    ui->listWidget->addItem(QString("23234"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::callBackFun1(void* data)
{
    if(data!=nullptr){
        QString _data=QString((static_cast<char*>(data)));
        qDebug()<<_data;

    }

    int count=0;
    while(1){
//        qDebug()<<__LINE__<<QThread::currentThread();
        count++;
        ui->lineEdit->setText(QString("%1").arg(count));
        ui->listWidget->addItem(QString("%1").arg(count));
//        qDebug()<<"here";
        thread_2->sleep(1);
    }
}

void MainWindow::callBackFun(void* data)
{
    if(data!=nullptr){
        QString _data=QString((static_cast<char*>(data)));
        qDebug()<<_data;

    }

    int count=0;
    while(1){
//        qDebug()<<__LINE__<<QThread::currentThread();
        count++;
        ui->lineEdit->setText(QString("%1").arg(count));
        ui->listWidget->addItem(QString("%1").arg(count));
//        qDebug()<<"here";
        thread_1->sleep(1);
    }
}

void MainWindow::on_pushButton_clicked()
{
    qDebug()<<__LINE__<<QThread::currentThread();
}
