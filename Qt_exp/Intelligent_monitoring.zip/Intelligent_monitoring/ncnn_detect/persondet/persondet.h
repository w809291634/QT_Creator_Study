#pragma once
#include <vector>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <map>
#include <string>
// ncnn
#include "net.h"
// opencv
#include <opencv2/opencv.hpp>

//#include <stack>
//#include <chrono>

// 行人检测类
class Persondet 
{
public:
    Persondet(): person_width(320), person_height(320){}
    ~Persondet();

    int init(std::string model_path);
    int detect(cv::Mat &image);

    int person_width;
    int person_height;

private:
    ncnn::Net person_det;
};
